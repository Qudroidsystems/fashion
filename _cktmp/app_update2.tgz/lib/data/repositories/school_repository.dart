import '../../core/network/api_client.dart';
import '../../core/network/api_exception.dart';
import '../../core/offline/outbox.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/json.dart';
import '../models/common.dart';
import '../models/parent_extras.dart';
import '../models/results_admin.dart';
import '../models/user.dart';
import '../models/staff.dart';
import '../models/student.dart';

/// Parent / student data: children, results, fees, payments, attendance,
/// timetable and leave of absence.
class StudentRepository {
  StudentRepository._();

  static Future<List<StudentCard>> myStudents() async =>
      (await ApiClient.get('/students')).list.map((e) => StudentCard.fromJson(asMap(e))).toList();

  static Future<StudentCard> student(int id) async => StudentCard.fromJson((await ApiClient.get('/students/$id')).map);

  static Future<ResultsPage> results(int id, {int? termId, int? sessionId}) async => ResultsPage.fromJson(
      (await ApiClient.get('/students/$id/results', query: {'term_id': termId, 'session_id': sessionId})).map);

  static Future<FeeStatement> fees(int id, {int? termId, int? sessionId}) async => FeeStatement.fromJson(
      (await ApiClient.get('/students/$id/fees', query: {'term_id': termId, 'session_id': sessionId})).map);

  static Future<PaymentQuote> quote(int id, {int? termId, int? sessionId}) async => PaymentQuote.fromJson(
      (await ApiClient.get('/students/$id/payment-quote', query: {'term_id': termId, 'session_id': sessionId})).map);

  /// Returns {reference, authorization_url, callback_url, amount}.
  static Future<Map<String, dynamic>> checkout({
    required int studentId,
    required int termId,
    required int sessionId,
    required Map<String, double> items,
  }) async {
    final res = await ApiClient.post('/payments/checkout', body: {
      'student_id': studentId,
      'term_id': termId,
      'session_id': sessionId,
      'items': items.map((k, v) => MapEntry(k, v.toStringAsFixed(2))),
    });
    return res.map;
  }

  static Future<OnlinePayment> payment(String reference) async =>
      OnlinePayment.fromJson((await ApiClient.get('/payments/${Uri.encodeComponent(reference)}')).map);

  static Future<AttendancePage> attendance(int id, {int? termId, int? sessionId}) async => AttendancePage.fromJson(
      (await ApiClient.get('/students/$id/attendance', query: {'term_id': termId, 'session_id': sessionId})).map);

  static Future<ClassTimetable> timetable(int id) async =>
      ClassTimetable.fromJson((await ApiClient.get('/students/$id/timetable')).map);

  static Future<TeachersPage> teachers(int id) async => TeachersPage.fromJson((await ApiClient.get('/students/$id/teachers')).map);

  static Future<PerformancePage> performance(int id) async =>
      PerformancePage.fromJson((await ApiClient.get('/students/$id/performance')).map);

  /// AI learning & career guidance (or the built-in version) for a student.
  static Future<Map<String, dynamic>> guidance(int id, {bool refresh = false}) async => refresh
      ? (await ApiClient.post('/students/$id/guidance/refresh')).map
      : (await ApiClient.get('/students/$id/guidance')).map;

  static Future<LearningPage> learning(int id) async => LearningPage.fromJson((await ApiClient.get('/students/$id/learning')).map);

  /// Payment statement PDF (path for [FileOpener]).
  static String statementUrl(int id, {int? termId, int? sessionId}) {
    final q = [if (termId != null) 'term_id=$termId', if (sessionId != null) 'session_id=$sessionId'].join('&');
    return '/students/$id/payment-statement${q.isEmpty ? '' : '?$q'}';
  }

  // Leave of absence ------------------------------------------------------

  static Future<(List<StudentLeave>, Map<String, String>)> leaves() async {
    final res = await ApiClient.get('/student-leave');
    final reasons = asMap(res.meta['reasons']).map((k, v) => MapEntry(k, '$v'));
    return (res.list.map((e) => StudentLeave.fromJson(asMap(e))).toList(), reasons);
  }

  static Future<String> requestLeave({
    required int studentId,
    required String reasonType,
    required String reason,
    required DateTime start,
    required DateTime end,
    String? phone,
  }) async {
    final res = await ApiClient.post('/student-leave', body: {
      'student_id': studentId,
      'reason_type': reasonType,
      'reason': reason,
      'start_date': Fmt.apiDate(start),
      'end_date': Fmt.apiDate(end),
      if (phone != null && phone.isNotEmpty) 'contact_phone': phone,
    });
    return res.message ?? 'Leave request sent.';
  }

  static Future<void> cancelLeave(int id) => ApiClient.post('/student-leave/$id/cancel');
}

/// Staff self-service and class / subject work.
class StaffRepository {
  StaffRepository._();

  static Future<Map<String, dynamic>> home() async {
    final res = await ApiClient.get('/staff/home');
    if (!res.fromCache) warmOfflineCache();
    return res.map;
  }

  static bool _warmed = false;

  /// Once per app start, quietly opens this term's score sheets, timetable and
  /// classes so they are on the phone if the connection drops later.
  static Future<void> warmOfflineCache() async {
    if (_warmed) return;
    _warmed = true;
    try {
      final subjects = await StaffRepository.subjects();
      for (final a in subjects.where((a) => a.canOpen).take(25)) {
        await ApiClient.get('/staff/scoresheets/${a.subjectclassId}', query: {'term_id': a.termId, 'session_id': a.sessionId});
      }
      await ApiClient.get('/staff/timetable');
      await ApiClient.get('/staff/classes');
    } catch (_) {
      // best effort
    }
  }

  static Future<List<SubjectAssignment>> subjects({int? sessionId, int? termId}) async =>
      (await ApiClient.get('/staff/subjects', query: {'session_id': sessionId, 'term_id': termId}))
          .list
          .map((e) => SubjectAssignment.fromJson(asMap(e)))
          .toList();

  /// Subjects for one period plus the sessions/terms the teacher has taught in.
  static Future<(List<SubjectAssignment>, List<TeachingPeriod>)> subjectsWithPeriods({int? sessionId, int? termId}) async {
    final res = await ApiClient.get('/staff/subjects', query: {'session_id': sessionId, 'term_id': termId});
    return (
      res.list.map((e) => SubjectAssignment.fromJson(asMap(e))).toList(),
      asMapList(res.meta['periods']).map(TeachingPeriod.fromJson).toList(),
    );
  }

  static String scoresheetExcelUrl(Scoresheet s) => '/staff/scoresheets/${s.subjectclassId}/excel?term_id=${s.termId}&session_id=${s.sessionId}';

  static String marksheetUrl(Scoresheet s) => '/staff/scoresheets/${s.subjectclassId}/marksheet?term_id=${s.termId}&session_id=${s.sessionId}';

  /// Uploads a filled spreadsheet; returns the refreshed sheet, message and row warnings.
  static Future<(Scoresheet, String?, List<String>)> importScoresheet(Scoresheet s, String filePath) async {
    final res = await ApiClient.postMultipart('/staff/scoresheets/${s.subjectclassId}/excel',
        fields: {'term_id': '${s.termId}', 'session_id': '${s.sessionId}'}, fileField: 'file', filePath: filePath);
    final warnings = asMapList(res.meta['warnings']).map((w) {
      final row = asInt(w['row']);
      final errs = asStringList(w['errors']);
      final msg = errs.isNotEmpty ? errs.join('; ') : (asString(w['message']) ?? '');
      return row == null ? msg : 'Row $row: $msg';
    }).toList();
    return (Scoresheet.fromJson(res.map), res.message, warnings);
  }

  /// True when the last [scoresheet] came from the phone's offline copy.
  static bool lastFromCache = false;

  static Future<Scoresheet> scoresheet(int subjectclassId, {required int termId, required int sessionId, bool recalculate = false}) async {
    final res = await ApiClient.get('/staff/scoresheets/$subjectclassId', query: {
      'term_id': termId,
      'session_id': sessionId,
      if (recalculate) 'recalculate': 1,
    }, cache: !recalculate);
    lastFromCache = res.fromCache;
    return Scoresheet.fromJson(res.map);
  }

  /// Saves rows built by the score sheet: `[{id, assessments: {key: score}, base: {key: seen}}]`.
  /// With [subOf] the keys are parts of that assessment. Scores changed on the
  /// school since the teacher saw them come back in `conflicts`.
  static Future<({Scoresheet sheet, String? message, List<Map<String, dynamic>> conflicts})> saveScoreRows(
      Scoresheet sheet, List<Map<String, dynamic>> rows, {int? subOf}) async {
    final res = await ApiClient.post('/staff/scoresheets/${sheet.subjectclassId}/bulk', body: {
      'term_id': sheet.termId,
      'session_id': sheet.sessionId,
      if (subOf != null) 'is_sub': true,
      if (subOf != null) 'assessment_id': subOf,
      'scores': rows,
    });
    return (sheet: Scoresheet.fromJson(res.map), message: res.message, conflicts: asMapList(res.meta['conflicts']));
  }

  /// Saves every changed score at once and returns the refreshed sheet.
  /// [changes] maps broadsheet id → (assessment id → score).
  /// With [subOf], [changes] holds sub-assessment scores (e.g. Theory /
  /// Objective) of that assessment, keyed by sub-assessment id.
  static Future<(Scoresheet, String?)> saveScores(Scoresheet sheet, Map<int, Map<int, double>> changes, {int? subOf}) async {
    final res = await ApiClient.post('/staff/scoresheets/${sheet.subjectclassId}/bulk', body: {
      'term_id': sheet.termId,
      'session_id': sheet.sessionId,
      if (subOf != null) 'is_sub': true,
      if (subOf != null) 'assessment_id': subOf,
      'scores': changes.entries
          .map((e) => {
                'id': e.key,
                'assessments': e.value.map((k, v) => MapEntry('$k', v)),
              })
          .toList(),
    });
    return (Scoresheet.fromJson(res.map), res.message);
  }

  static Future<List<TeacherClass>> classes({int? sessionId}) async =>
      (await ApiClient.get('/staff/classes', query: {'session_id': sessionId}))
          .list
          .map((e) => TeacherClass.fromJson(asMap(e)))
          .toList();

  static Future<AttendanceRegister> register(TeacherClass c, {String? date, String? period}) async =>
      AttendanceRegister.fromJson((await ApiClient.get('/staff/attendance/register', query: {
        'class_id': c.classId,
        'term_id': c.termId,
        'session_id': c.sessionId,
        'date': date,
        'period': period,
      }))
          .map);

  /// Saves the register. Offline, it is kept on the phone and sent later
  /// (the message says so); marks changed elsewhere meanwhile are not overwritten.
  static Future<String> saveRegister(AttendanceRegister r, {String? className}) async {
    final body = {
      'schoolclass_id': r.classId,
      'term_id': r.termId,
      'session_id': r.sessionId,
      'attendance_date': r.date,
      'period': r.period,
      'records': r.students
          .where((s) => s.status != null && s.status != s.savedStatus)
          .map((s) => {'student_id': s.id, 'status': s.status, 'base': s.savedStatus})
          .toList(),
    };
    if ((body['records'] as List).isEmpty) return 'Nothing new to save.';
    try {
      final res = await ApiClient.post('/staff/attendance', body: body);
      return res.message ?? 'Attendance saved.';
    } on ApiException catch (e) {
      if (!e.isOffline) rethrow;
      await Outbox.add(
        kind: 'attendance',
        path: '/staff/attendance',
        body: body,
        label: 'Attendance · ${className ?? 'class'} · ${r.date} (${r.period})',
        group: 'register:${r.classId}:${r.date}:${r.period}',
      );
      return 'You are offline. The register is saved on this phone and will upload automatically.';
    }
  }

  static List<Lesson> todayLessons(Map<String, dynamic> home) =>
      asMapList(home['today_lessons']).map(Lesson.fromJson).toList();

  static Future<List<(String, List<Lesson>)>> timetable() async {
    final res = await ApiClient.get('/staff/timetable');
    return res.list
        .map((d) => asMap(d))
        .map((d) => (asString(d['day']) ?? '', asMapList(d['lessons']).map(Lesson.fromJson).toList()))
        .toList();
  }

  // Leave -------------------------------------------------------------------

  static Future<(List<LeaveBalance>, List<StaffLeave>)> leave() async {
    final m = (await ApiClient.get('/staff/leave')).map;
    return (
      asMapList(m['balances']).map(LeaveBalance.fromJson).toList(),
      asMapList(m['requests']).map(StaffLeave.fromJson).toList(),
    );
  }

  static Future<String> applyLeave({
    required int typeId,
    required DateTime start,
    required DateTime end,
    required String reason,
    bool halfDay = false,
    String? phone,
    String? attachmentPath,
  }) async {
    final res = await ApiClient.postMultipart('/staff/leave', fields: {
      'leave_type_id': '$typeId',
      'start_date': Fmt.apiDate(start),
      'end_date': Fmt.apiDate(end),
      'reason': reason,
      'half_day': halfDay ? '1' : '0',
      if (phone != null && phone.isNotEmpty) 'contact_phone': phone,
    }, fileField: attachmentPath == null ? null : 'attachment', filePath: attachmentPath);
    return res.message ?? 'Leave request sent.';
  }

  static Future<void> cancelLeave(int id) => ApiClient.post('/staff/leave/$id/cancel');

  // Pay ---------------------------------------------------------------------

  static Future<(List<Payslip>, Map<String, dynamic>)> payslips({int? year}) async {
    final m = (await ApiClient.get('/staff/payslips', query: {'year': year})).map;
    return (asMapList(m['payslips']).map(Payslip.fromJson).toList(), asMap(m['ytd']));
  }

  static Future<Payslip> payslip(int id) async => Payslip.fromJson((await ApiClient.get('/staff/payslips/$id')).map);
}

/// Management: dashboard, approvals, student look-up.
class AdminRepository {
  AdminRepository._();

  static Future<Map<String, dynamic>> dashboard({bool refresh = false}) async =>
      (await ApiClient.get('/admin/dashboard', query: {if (refresh) 'refresh': 1})).map;

  static Future<List<StaffLeave>> pendingStaffLeave() async =>
      (await ApiClient.get('/admin/leave/pending')).list.map((e) => StaffLeave.fromJson(asMap(e))).toList();

  static Future<String> decideStaffLeave(int id, bool approve, String? note) async =>
      (await ApiClient.post('/admin/leave/$id/decide', body: {'decision': approve ? 'yes' : 'no', if (note != null && note.isNotEmpty) 'note': note})).message ??
      'Done.';

  static Future<List<StudentLeave>> pendingStudentLeave() async =>
      (await ApiClient.get('/admin/student-leave/pending')).list.map((e) => StudentLeave.fromJson(asMap(e))).toList();

  static Future<String> decideStudentLeave(int id, bool approve, String? note) async =>
      (await ApiClient.post('/admin/student-leave/$id/decide', body: {'decision': approve ? 'yes' : 'no', if (note != null && note.isNotEmpty) 'note': note}))
          .message ??
      'Done.';

  static Future<List<Map<String, dynamic>>> searchStudents(String q) async =>
      asMapList((await ApiClient.get('/admin/students/search', query: {'q': q})).data);
}

/// Inbox and calendar.
class CommonRepository {
  CommonRepository._();

  static Future<(List<AppNotification>, int unread, int lastPage)> notifications({int page = 1}) async {
    final res = await ApiClient.get('/notifications', query: {'page': page});
    return (
      res.list.map((e) => AppNotification.fromJson(asMap(e))).toList(),
      asInt(res.meta['unread']) ?? 0,
      asInt(res.meta['last_page']) ?? 1,
    );
  }

  static Future<void> markRead(String id) => ApiClient.post('/notifications/$id/read');
  static Future<void> markAllRead() => ApiClient.post('/notifications/read-all');

  static Future<int> unreadCount() async => asInt((await ApiClient.get('/notifications/unread-count')).map['unread']) ?? 0;

  static Future<List<CalendarItem>> calendar(DateTime from, DateTime to) async =>
      (await ApiClient.get('/calendar', query: {'from': Fmt.apiDate(from), 'to': Fmt.apiDate(to)}))
          .list
          .map((e) => CalendarItem.fromJson(asMap(e)))
          .toList();
}

/// Broadsheets and report-card approval (class teachers and principal).
class ResultsRepository {
  ResultsRepository._();

  static Future<ResultsBoard> board({int? termId, int? sessionId}) async {
    final res = await ApiClient.get('/results/board', query: {'term_id': termId, 'session_id': sessionId});
    return ResultsBoard(
      classes: res.list.map((e) => BoardClass.fromJson(asMap(e))).toList(),
      termId: asInt(res.meta['term_id']) ?? 0,
      sessionId: asInt(res.meta['session_id']) ?? 0,
      terms: IdName.terms(res.meta['terms']),
      sessions: IdName.sessions(res.meta['sessions']),
      canApprove: asBool(res.meta['can_approve']),
      enforced: asBool(res.meta['enforced']),
      approvals: asBool(res.meta['approvals'], true),
    );
  }

  static Future<Broadsheet> broadsheet(int classId, {required int termId, required int sessionId, String basis = 'cum_ave'}) async =>
      Broadsheet.fromJson((await ApiClient.get('/results/classes/$classId/broadsheet',
              query: {'term_id': termId, 'session_id': sessionId, 'basis': basis}))
          .map);

  static Future<ReportApproval> approval(int classId, {required int termId, required int sessionId}) async =>
      ReportApproval.fromJson(
          (await ApiClient.get('/results/classes/$classId/approval', query: {'term_id': termId, 'session_id': sessionId})).map);

  /// action: submit | approve | return | reopen
  static Future<(ReportApproval, String?)> act(int approvalId, String action, {String? note, bool force = false}) async {
    final res = await ApiClient.post('/results/approvals/$approvalId/$action', body: {
      if (note != null && note.isNotEmpty) 'note': note,
      if (force) 'force': true,
    });
    return (ReportApproval.fromJson(res.map), res.message);
  }

  static Future<String> approveAll({required int termId, required int sessionId}) async =>
      (await ApiClient.post('/results/approve-all', body: {'term_id': termId, 'session_id': sessionId})).message ?? 'Done.';

  static String previewUrl(int approvalId, int studentId) => '/results/approvals/$approvalId/preview/$studentId';
}

class PreferenceRepository {
  PreferenceRepository._();

  static Future<NotificationPrefs> get() async => NotificationPrefs.fromJson((await ApiClient.get('/me/preferences')).map);

  static Future<NotificationPrefs> save(NotificationPrefs p) async => NotificationPrefs.fromJson((await ApiClient.put('/me/preferences', body: {
        'push_enabled': p.pushEnabled,
        'lesson_reminders': p.lessonReminders,
        'reminder_minutes': p.reminderMinutes,
      }))
          .map);
}
