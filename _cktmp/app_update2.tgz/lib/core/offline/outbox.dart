import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../network/api_client.dart';
import '../network/api_exception.dart';
import '../storage/session_store.dart';

/// One change made while offline, waiting to be sent to the school.
class OutboxItem {
  OutboxItem({
    required this.id,
    required this.kind,
    required this.path,
    required this.body,
    required this.label,
    required this.createdAt,
    required this.owner,
    this.group,
    this.error,
  });

  final String id;

  /// 'scores' or 'attendance'.
  final String kind;
  final String path;
  final Map<String, dynamic> body;

  /// What the user sees, e.g. "Mathematics · JSS 1A — 12 scores".
  final String label;
  final DateTime createdAt;

  /// school url + user id: only sent by the same user on the same school.
  final String owner;

  /// Groups items of one screen (e.g. one score sheet) so it can show them.
  final String? group;

  /// Set when the school refused the change (not a network problem).
  String? error;

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind,
        'path': path,
        'body': body,
        'label': label,
        'created_at': createdAt.toIso8601String(),
        'owner': owner,
        'group': group,
        'error': error,
      };

  factory OutboxItem.fromJson(Map<String, dynamic> j) => OutboxItem(
        id: '${j['id']}',
        kind: '${j['kind']}',
        path: '${j['path']}',
        body: j['body'] is Map ? Map<String, dynamic>.from(j['body'] as Map) : <String, dynamic>{},
        label: '${j['label'] ?? ''}',
        createdAt: DateTime.tryParse('${j['created_at']}') ?? DateTime.now(),
        owner: '${j['owner'] ?? ''}',
        group: j['group']?.toString(),
        error: j['error']?.toString(),
      );
}

/// Changes saved on the phone while offline (scores, attendance) and sent in
/// order as soon as the school can be reached again.
///
/// Every change carries the values the user saw when they made it, so the
/// school never overwrites something that was changed elsewhere in the
/// meantime — those come back as conflicts for the user to look at.
class Outbox {
  Outbox._();

  static final GetStorage _box = GetStorage('outbox');
  static const _kItems = 'items';
  static const _kNotes = 'notes';

  /// Waiting changes for the signed-in user (for badges and banners).
  static final RxList<OutboxItem> items = <OutboxItem>[].obs;

  /// Messages from the last sync (conflicts, refusals) the user should read.
  static final RxList<String> notes = <String>[].obs;
  static final RxBool syncing = false.obs;

  /// Called after something was sent (screens reload their data).
  static final RxInt sent = 0.obs;

  static Timer? _timer;
  static bool _started = false;

  static String get owner => '${SessionStore.schoolUrl ?? ''}|${SessionStore.user?['id'] ?? ''}';

  static List<OutboxItem> _all() {
    final raw = _box.read(_kItems);
    return raw is List ? raw.whereType<Map>().map((e) => OutboxItem.fromJson(Map<String, dynamic>.from(e))).toList() : [];
  }

  static Future<void> _write(List<OutboxItem> all) async {
    await _box.write(_kItems, all.map((e) => e.toJson()).toList());
    _refresh();
  }

  static void _refresh() {
    final me = owner;
    items.assignAll(_all().where((e) => e.owner == me));
    final n = _box.read(_kNotes);
    notes.assignAll(n is List ? n.map((e) => '$e') : const <String>[]);
  }

  /// Starts trying to send every 30 seconds and when the app comes back to the
  /// foreground. Safe to call more than once.
  static void start() {
    if (_started) return;
    _started = true;
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => flush());
    WidgetsBinding.instance.addObserver(_Resume());
    ever(ApiClient.offline, (bool off) {
      if (!off) flush();
    });
  }

  static void stop() {
    _timer?.cancel();
    _started = false;
  }

  static Future<OutboxItem> add({
    required String kind,
    required String path,
    required Map<String, dynamic> body,
    required String label,
    String? group,
  }) async {
    final item = OutboxItem(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      kind: kind,
      path: path,
      body: body,
      label: label,
      createdAt: DateTime.now(),
      owner: owner,
      group: group,
    );
    await _write([..._all(), item]);
    return item;
  }

  static List<OutboxItem> inGroup(String group) => items.where((e) => e.group == group && e.error == null).toList();

  static Future<void> remove(String id) => _write(_all().where((e) => e.id != id).toList());

  static Future<void> clearNotes() async {
    await _box.write(_kNotes, <String>[]);
    _refresh();
  }

  static Future<void> _note(String text) async {
    final n = _box.read(_kNotes);
    final list = n is List ? n.map((e) => '$e').toList() : <String>[];
    list.insert(0, text);
    await _box.write(_kNotes, list.take(30).toList());
  }

  /// Sends waiting changes in the order they were made. Stops at the first
  /// network failure (still offline); a change the school refuses is kept with
  /// its error so the user can see it, and the rest carry on.
  static Future<void> flush() async {
    if (syncing.value || SessionStore.token == null) return;
    final me = owner;
    final mine = _all().where((e) => e.owner == me && e.error == null).toList();
    if (mine.isEmpty) return;
    syncing.value = true;
    var any = false;
    try {
      for (final item in mine) {
        try {
          final res = await ApiClient.post(item.path, body: item.body);
          any = true;
          final conflicts = res.meta['conflicts'];
          if (conflicts is List && conflicts.isNotEmpty) {
            await _note('${item.label}: ${conflicts.length} score(s) had been changed by someone else, so your offline value was not used. Please check them.');
          }
          await _write(_all().where((e) => e.id != item.id).toList());
        } on ApiException catch (e) {
          if (e.isOffline) break;
          if (e.isUnauthenticated) break;
          final all = _all();
          for (final x in all) {
            if (x.id == item.id) x.error = e.message;
          }
          await _note('${item.label}: not saved — ${e.message}');
          await _write(all);
        }
      }
    } finally {
      syncing.value = false;
      _refresh();
      if (any) sent.value++;
    }
  }
}

class _Resume with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) Outbox.flush();
  }
}
