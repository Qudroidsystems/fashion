import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../storage/session_store.dart';
import 'api_exception.dart';

/// A successful API reply: the `data`, plus `meta` and `message` if sent.
class ApiResponse {
  const ApiResponse(this.data, {this.meta = const {}, this.message, this.cachedAt});

  final dynamic data;
  final Map<String, dynamic> meta;
  final String? message;

  /// Set when the phone is offline and this is the copy saved the last time
  /// the page was opened online.
  final DateTime? cachedAt;
  bool get fromCache => cachedAt != null;

  Map<String, dynamic> get map =>
      data is Map ? Map<String, dynamic>.from(data as Map) : <String, dynamic>{};

  List<dynamic> get list => data is List ? data as List : const [];
}

/// Talks to the Laravel mobile API (v1).
///
/// Every reply uses one envelope:
///   { "success": true,  "message": "...", "data": ..., "meta": {...} }
///   { "success": false, "message": "...", "code": "...", "errors": {...} }
class ApiClient {
  ApiClient._();

  static final http.Client _http = http.Client();

  /// Saved copies of pages (GET replies) for offline use. Cleared on sign-out.
  static final GetStorage _cache = GetStorage('api_cache');

  /// True after a request failed for lack of connection; false after the next
  /// one that reached the school. Screens show an "offline" banner from it.
  static final RxBool offline = false.obs;

  /// When the page now on screen was saved, if it came from the offline copy.
  static final Rxn<DateTime> showingCachedFrom = Rxn<DateTime>();

  static Future<void> clearCache() => _cache.erase();

  /// Called when the server says the token is no longer valid (401).
  /// The auth controller uses it to send the user back to sign-in.
  static void Function()? onUnauthenticated;

  /// Called when the server says the password must be changed first.
  static void Function()? onPasswordChangeRequired;

  static Uri uri(String path, [Map<String, dynamic>? query]) {
    final base = AppConfig.apiBaseUrl;
    final p = path.startsWith('/') ? path : '/$path';
    final q = <String, String>{};
    query?.forEach((k, v) {
      if (v != null && '$v'.isNotEmpty) q[k] = '$v';
    });
    final u = Uri.parse('$base$p');
    return q.isEmpty ? u : u.replace(queryParameters: {...u.queryParameters, ...q});
  }

  static Map<String, String> _headers({bool json = true}) {
    final token = SessionStore.token;
    return {
      'Accept': 'application/json',
      if (json) 'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  /// GET a full URL (used to check a school's address before it is saved).
  static Future<ApiResponse> getUrl(Uri url) => _send(() => _http.get(url, headers: {'Accept': 'application/json'}));

  /// GET a page. With [cache] (the default) a successful reply is saved, and
  /// when the phone is offline the saved copy is returned instead of an error.
  static Future<ApiResponse> get(String path, {Map<String, dynamic>? query, bool cache = true}) async {
    final u = uri(path, query);
    final key = '${SessionStore.schoolUrl ?? ''}|${SessionStore.user?['id'] ?? ''}|${u.path}?${u.query}';
    try {
      final res = await _guard(() => _http.get(u, headers: _headers()));
      final parsed = _parse(res);
      if (cache && res.statusCode == 200) {
        _cache.write(key, {'t': DateTime.now().millisecondsSinceEpoch, 'b': utf8.decode(res.bodyBytes)});
      }
      showingCachedFrom.value = null;
      return parsed;
    } on ApiException catch (e) {
      if (!cache || !e.isOffline) rethrow;
      final saved = _cache.read(key);
      if (saved is! Map || saved['b'] is! String) rethrow;
      final at = DateTime.fromMillisecondsSinceEpoch((saved['t'] as num?)?.toInt() ?? 0);
      final body = jsonDecode(saved['b'] as String);
      final map = body is Map ? Map<String, dynamic>.from(body) : <String, dynamic>{};
      showingCachedFrom.value = at;
      return ApiResponse(
        map.containsKey('data') ? map['data'] : body,
        meta: map['meta'] is Map ? Map<String, dynamic>.from(map['meta']) : const {},
        message: map['message']?.toString(),
        cachedAt: at,
      );
    }
  }

  static Future<ApiResponse> post(String path, {Object? body}) => _send(
      () => _http.post(uri(path), headers: _headers(), body: jsonEncode(body ?? const {})));

  static Future<ApiResponse> put(String path, {Object? body}) => _send(
      () => _http.put(uri(path), headers: _headers(), body: jsonEncode(body ?? const {})));

  static Future<ApiResponse> delete(String path, {Object? body}) => _send(
      () => _http.delete(uri(path), headers: _headers(), body: jsonEncode(body ?? const {})));

  /// POST with an optional file (e.g. a medical note on a leave request).
  static Future<ApiResponse> postMultipart(
    String path, {
    required Map<String, String> fields,
    String? fileField,
    String? filePath,
  }) {
    return _send(() async {
      final req = http.MultipartRequest('POST', uri(path))
        ..headers.addAll(_headers(json: false))
        ..fields.addAll(fields);
      if (fileField != null && filePath != null) {
        req.files.add(await http.MultipartFile.fromPath(fileField, filePath));
      }
      return http.Response.fromStream(await _http.send(req));
    });
  }

  /// Downloads a file (report card, payslip PDF). Throws [ApiException] on error.
  static Future<Uint8List> download(String urlOrPath) async {
    final u = urlOrPath.startsWith('http') ? Uri.parse(urlOrPath) : uri(urlOrPath);
    final res = await _guard(() => _http.get(u, headers: {..._headers(json: false), 'Accept': 'application/pdf, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/json, */*'}));
    final type = res.headers['content-type'] ?? '';
    if (res.statusCode == 200 && !type.contains('json')) return res.bodyBytes;
    _parse(res); // throws with the API's message
    throw const ApiException('The file could not be downloaded.');
  }

  // ── internals ────────────────────────────────────────────────────────

  static Future<ApiResponse> _send(Future<http.Response> Function() call) async {
    final res = await _guard(call);
    return _parse(res);
  }

  static Future<http.Response> _guard(Future<http.Response> Function() call) async {
    try {
      final res = await call().timeout(AppConfig.requestTimeout);
      if (offline.value) offline.value = false;
      return res;
    } on SocketException {
      offline.value = true;
      throw const ApiException('No internet connection. Please check your network.', code: 'offline');
    } on TimeoutException {
      offline.value = true;
      throw const ApiException('The school server is taking too long. Please try again.', code: 'timeout');
    } on http.ClientException {
      offline.value = true;
      throw const ApiException('Could not reach the school server. Please try again.', code: 'offline');
    } on HandshakeException {
      throw const ApiException('A secure connection could not be made. Please try again.', code: 'offline');
    }
  }

  static ApiResponse _parse(http.Response res) {
    dynamic body;
    try {
      body = res.body.isEmpty ? null : jsonDecode(utf8.decode(res.bodyBytes));
    } catch (_) {
      body = null;
    }

    if (kDebugMode) {
      debugPrint('[api] ${res.request?.method} ${res.request?.url} → ${res.statusCode}');
    }

    final map = body is Map ? Map<String, dynamic>.from(body) : <String, dynamic>{};
    final ok = res.statusCode >= 200 && res.statusCode < 300 && map['success'] != false;

    if (ok) {
      return ApiResponse(
        map.containsKey('data') ? map['data'] : body,
        meta: map['meta'] is Map ? Map<String, dynamic>.from(map['meta']) : const {},
        message: map['message']?.toString(),
      );
    }

    final code = map['code']?.toString();
    final errors = <String, List<String>>{};
    if (map['errors'] is Map) {
      (map['errors'] as Map).forEach((k, v) {
        errors['$k'] = v is List ? v.map((e) => '$e').toList() : ['$v'];
      });
    }

    final message = map['message']?.toString() ?? _fallbackMessage(res.statusCode);
    final ex = ApiException(message, statusCode: res.statusCode, code: code, errors: errors);

    if (res.statusCode == 401) onUnauthenticated?.call();
    if (code == 'password_change_required') onPasswordChangeRequired?.call();
    if (code == 'account_disabled') onUnauthenticated?.call();

    throw ex;
  }

  static String _fallbackMessage(int status) {
    if (status == 401) return 'Please sign in again.';
    if (status == 403) return 'You are not allowed to do that.';
    if (status == 404) return 'Not found.';
    if (status == 419 || status == 429) return 'Too many requests. Please wait a moment.';
    if (status >= 500) return 'The school server had a problem. Please try again.';
    return 'Something went wrong. Please try again.';
  }
}
