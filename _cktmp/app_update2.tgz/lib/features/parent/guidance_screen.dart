import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/json.dart';
import '../../core/widgets/charts.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';

/// Learning & career guidance from the student's results: learning style,
/// study and reading plans, strengths, interests, vocations and the university
/// courses that fit best. Written by the school's chosen AI, or by the
/// portal's built-in rules.
class GuidanceScreen extends StatefulWidget {
  const GuidanceScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<GuidanceScreen> createState() => _GuidanceScreenState();
}

class _GuidanceScreenState extends LoadState<GuidanceScreen, Map<String, dynamic>> {
  bool _refreshing = false;

  @override
  Future<Map<String, dynamic>> fetch() => StudentRepository.guidance(widget.student.id);

  Future<void> _refresh() async {
    final left = asInt(data?['refreshes_left']) ?? 0;
    if (left <= 0) {
      Toast.info('No more refreshes this term. Guidance updates by itself when new results are published.');
      return;
    }
    if (!await confirmDialog('Refresh guidance?', 'A new report is written from the latest results. $left refresh(es) left this term.', confirm: 'Refresh')) return;
    setState(() => _refreshing = true);
    try {
      final d = await StudentRepository.guidance(widget.student.id, refresh: true);
      setState(() => data = d);
      Toast.success('Guidance refreshed.');
    } catch (e) {
      Toast.error(e);
    } finally {
      if (mounted) setState(() => _refreshing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = data;
    final available = d != null && asBool(d['available']);
    return Scaffold(
      appBar: AppBar(
        title: Text('Guidance — ${widget.student.firstName}'),
        actions: [
          if (available)
            IconButton(
              tooltip: 'Refresh',
              onPressed: _refreshing ? null : _refresh,
              icon: _refreshing
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(AppIcons.refresh),
            ),
        ],
      ),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: d != null && !available,
        emptyIcon: Icons.auto_awesome_outlined,
        emptyTitle: 'Guidance not ready yet',
        emptyMessage: asString(d?['message']) ?? 'It appears once results are published.',
        child: !available ? const SizedBox() : _body(d),
      ),
    );
  }

  Widget _body(Map<String, dynamic> d) {
    final r = asMap(d['report']);
    final based = asMap(d['based_on']);
    final ai = asString(d['source']) == 'ai';
    final model = asMap(r['learning_model']);

    List<String> strings(dynamic v) => asStringList(v);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
      children: FadeSlideIn.staggered([
        // Header
        Container(
          margin: const EdgeInsets.only(top: 16),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF4F46E5), Color(0xFF7C3AED)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: const Color(0xFF4F46E5).withValues(alpha: 0.3), blurRadius: 18, offset: const Offset(0, 8))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.auto_awesome, color: Colors.white),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(ai ? 'Written by ${asString(d['provider_label']) ?? 'AI'}' : 'Built from school records',
                        style: TextStyle(color: Colors.white.withValues(alpha: 0.9), fontWeight: FontWeight.w600, fontSize: 12.5)),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(asString(r['summary']) ?? '', style: const TextStyle(color: Colors.white, fontSize: 15.5, height: 1.4, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              Text(
                'Based on ${asInt(based['terms']) ?? 0} term(s), ${asInt(based['subjects']) ?? 0} subjects · updated ${Fmt.ago(DateTime.tryParse(asString(d['generated_at']) ?? '')?.toLocal())}',
                style: TextStyle(color: Colors.white.withValues(alpha: 0.75), fontSize: 12),
              ),
            ],
          ),
        ),

        if (strings(r['strengths']).isNotEmpty || strings(r['areas_to_improve']).isNotEmpty) ...[
          const SectionTitle('Strengths & focus areas'),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: _ListCard('Strengths', strings(r['strengths']), AppColors.success, AppIcons.medal)),
              const SizedBox(width: 10),
              Expanded(child: _ListCard('Focus on', strings(r['areas_to_improve']), AppColors.warning, AppIcons.trendUp)),
            ],
          ),
        ],

        if (model.isNotEmpty) ...[
          const SectionTitle('How they learn best'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: AppColors.blue.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.psychology_alt_outlined, color: AppColors.blue),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Text(asString(model['style']) ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                  ],
                ),
                const SizedBox(height: 8),
                Text(asString(model['description']) ?? ''),
                const SizedBox(height: 8),
                for (final t in strings(model['tips'])) _Bullet(t),
              ],
            ),
          ),
        ],

        if (asMapList(r['cognitive_profile']).isNotEmpty) ...[
          const SectionTitle('Thinking strengths'),
          AppCard(
            child: Column(
              children: [
                for (final c in asMapList(r['cognitive_profile']))
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(asString(c['trait']) ?? '', style: const TextStyle(fontWeight: FontWeight.w700))),
                            StatusPill(asString(c['level']) ?? '', color: _levelColor(asString(c['level']))),
                          ],
                        ),
                        const SizedBox(height: 6),
                        AnimatedBar(value: _levelValue(asString(c['level'])), color: _levelColor(asString(c['level'])), height: 7),
                        if (asString(c['evidence']) != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(asString(c['evidence'])!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],

        if (strings(r['passions']).isNotEmpty) ...[
          const SectionTitle('Passions & interests'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final p in strings(r['passions']))
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: const Color(0xFFDB2777).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
                  child: Text(p, style: const TextStyle(color: Color(0xFFDB2777), fontWeight: FontWeight.w700)),
                ),
            ],
          ),
        ],

        if (asMapList(r['higher_education']).isNotEmpty) ...[
          const SectionTitle('Courses that fit (higher institution)'),
          for (final h in asMapList(r['higher_education']))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                child: Row(
                  children: [
                    ProgressRing(value: (asDouble(h['fit']) ?? 0) / 100, size: 56, color: (asDouble(h['fit']) ?? 0) >= 75 ? AppColors.success : AppColors.blue),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(asString(h['discipline']) ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          if (asString(h['why']) != null) Text(asString(h['why'])!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                          if (strings(h['key_subjects']).isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text('Key subjects: ${strings(h['key_subjects']).join(', ')}',
                                  style: const TextStyle(color: AppColors.navy, fontSize: 12, fontWeight: FontWeight.w600)),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],

        if (asMapList(r['vocational_interests']).isNotEmpty) ...[
          const SectionTitle('Career paths to explore'),
          for (final v in asMapList(r['vocational_interests']))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(AppIcons.leave, color: Color(0xFF0D9488)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(asString(v['field']) ?? '', style: const TextStyle(fontWeight: FontWeight.w800)),
                          if (asString(v['why']) != null) Text(asString(v['why'])!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],

        if (asMapList(r['study_plan']).isNotEmpty) ...[
          const SectionTitle('Study plan'),
          for (final (i, p) in asMapList(r['study_plan']).indexed) _PlanStep(index: i + 1, plan: p),
        ],

        if (asMapList(r['reading_plan']).isNotEmpty) ...[
          const SectionTitle('Reading plan'),
          for (final b in asMapList(r['reading_plan']))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(AppIcons.book, color: AppColors.navy, size: 20),
                        const SizedBox(width: 8),
                        Expanded(child: Text(asString(b['focus']) ?? '', style: const TextStyle(fontWeight: FontWeight.w800))),
                        if (asString(b['how_often']) != null) StatusPill(asString(b['how_often'])!, color: AppColors.blue),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(asString(b['what']) ?? ''),
                    if (asString(b['why']) != null)
                      Padding(padding: const EdgeInsets.only(top: 4), child: Text(asString(b['why'])!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5))),
                  ],
                ),
              ),
            ),
        ],

        if (strings(r['parent_tips']).isNotEmpty) ...[
          const SectionTitle('Tips for parents'),
          AppCard(color: AppColors.sky, child: Column(children: [for (final t in strings(r['parent_tips'])) _Bullet(t)])),
        ],

        Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Text(asString(r['disclaimer']) ?? '', style: const TextStyle(color: AppColors.textMuted, fontSize: 12, fontStyle: FontStyle.italic)),
        ),
      ], maxSteps: 14),
    );
  }

  static double _levelValue(String? l) => switch ((l ?? '').toLowerCase()) { 'high' => 0.9, 'moderate' => 0.6, _ => 0.35 };

  static Color _levelColor(String? l) => switch ((l ?? '').toLowerCase()) { 'high' => AppColors.success, 'moderate' => AppColors.blue, _ => AppColors.warning };
}

class _ListCard extends StatelessWidget {
  const _ListCard(this.title, this.items, this.color, this.icon);
  final String title;
  final List<String> items;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Icon(icon, color: color, size: 18), const SizedBox(width: 6), Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w800))]),
            const SizedBox(height: 8),
            if (items.isEmpty) const Text('—', style: TextStyle(color: AppColors.textMuted)),
            for (final i in items) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(i, style: const TextStyle(fontSize: 13))),
          ],
        ),
      );
}

class _Bullet extends StatelessWidget {
  const _Bullet(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(padding: EdgeInsets.only(top: 6), child: Icon(Icons.circle, size: 6, color: AppColors.navy)),
            const SizedBox(width: 8),
            Expanded(child: Text(text)),
          ],
        ),
      );
}

class _PlanStep extends StatelessWidget {
  const _PlanStep({required this.index, required this.plan});
  final int index;
  final Map<String, dynamic> plan;

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Column(
            children: [
              Container(
                width: 30,
                height: 30,
                alignment: Alignment.center,
                decoration: const BoxDecoration(color: AppColors.navy, shape: BoxShape.circle),
                child: Text('$index', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              ),
              Expanded(child: Container(width: 2, color: AppColors.border)),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(asString(plan['period']) ?? '', style: const TextStyle(color: AppColors.blue, fontWeight: FontWeight.w700, fontSize: 12.5)),
                    Text(asString(plan['focus']) ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    const SizedBox(height: 6),
                    for (final a in asStringList(plan['actions'])) _Bullet(a),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
