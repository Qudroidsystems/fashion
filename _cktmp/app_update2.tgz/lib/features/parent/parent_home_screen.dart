import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../common/calendar_screen.dart';
import '../student/attendance_screen.dart';
import '../student/fees_screen.dart';
import '../student/pay_fees_screen.dart';
import '../student/results_screen.dart';
import 'guidance_screen.dart';
import 'learning_screen.dart';
import 'performance_screen.dart';
import 'report_cards_screen.dart';
import 'teachers_screen.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import '../auth/auth_controller.dart';
import '../common/inbox_screen.dart';
import '../student/student_hub_screen.dart';
import '../student/student_leave_screen.dart';

/// Parent home: one card per child with fees, attendance and latest result.
class ParentHomeScreen extends StatefulWidget {
  const ParentHomeScreen({super.key});

  @override
  State<ParentHomeScreen> createState() => _ParentHomeScreenState();
}

class _ParentHomeScreenState extends LoadState<ParentHomeScreen, List<StudentCard>> {
  @override
  Future<List<StudentCard>> fetch() => StudentRepository.myStudents();

  /// Runs [open] for the only child, or asks which child first.
  void _forChild(String title, void Function(StudentCard c) open) {
    final kids = data ?? const <StudentCard>[];
    if (kids.isEmpty) return;
    if (kids.length == 1) return open(kids.first);
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4))),
              ),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const Text('Which child?', style: TextStyle(color: AppColors.textMuted)),
              const SizedBox(height: 8),
              ...FadeSlideIn.staggered([
                for (final c in kids)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: PersonAvatar(name: c.fullName, url: c.photoUrl, size: 42),
                    title: Text(c.fullName, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(c.className ?? ''),
                    trailing: const Icon(AppIcons.arrow, size: 18),
                    onTap: () {
                      Get.back();
                      open(c);
                    },
                  ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = AuthController.to;
    final user = auth.user.value;
    final kids = data ?? const <StudentCard>[];
    final owing = kids.where((c) => (c.feeBalance ?? 0) > 0).toList();
    final totalOwed = owing.fold<double>(0, (t, c) => t + (c.feeBalance ?? 0));
    final results = user?.module('results') ?? true;
    final menu = <MenuItem>[
      if (results) MenuItem('Results', AppIcons.results, AppColors.blue, () => _forChild('Results', (c) => Get.to(() => ResultsScreen(student: c)))),
      if (results) MenuItem('Progress', AppIcons.chart, const Color(0xFF7C3AED), () => _forChild('Progress', (c) => Get.to(() => PerformanceScreen(student: c)))),
      if (results) MenuItem('AI guide', Icons.auto_awesome, const Color(0xFF4F46E5), () => _forChild('AI learning guide', (c) => Get.to(() => GuidanceScreen(student: c)))),
      if (user?.module('finance') ?? true) MenuItem('Fees', AppIcons.fees, AppColors.success, () => _forChild('Fees', (c) => Get.to(() => FeesScreen(student: c)))),
      if ((user?.module('online_payments') ?? true) && owing.isNotEmpty)
        MenuItem('Pay fees', AppIcons.pay, const Color(0xFF059669), () => _forChild('Pay fees', (c) async {
              await Get.to(() => PayFeesScreen(student: c));
              reload();
            }), badge: owing.length),
      MenuItem('Homework', AppIcons.book, const Color(0xFF0D9488), () => _forChild('Homework', (c) => Get.to(() => LearningScreen(student: c)))),
      MenuItem('Attendance', AppIcons.attendance, AppColors.info, () => _forChild('Attendance', (c) => Get.to(() => AttendanceScreen(student: c)))),
      MenuItem('Teachers', AppIcons.teacher, const Color(0xFFEA580C), () => _forChild('Teachers', (c) => Get.to(() => TeachersScreen(student: c)))),
      if (results)
        MenuItem('Report cards', AppIcons.document, const Color(0xFFDB2777), () => _forChild('Report cards', (c) => Get.to(() => ReportCardsScreen(student: c)))),
      if (user?.can('student_leave.apply') ?? true)
        MenuItem('Request leave', AppIcons.leave, const Color(0xFF4F46E5), () => Get.to(() => const StudentLeaveScreen())),
      MenuItem('Calendar', AppIcons.calendar, const Color(0xFF334155), () => Get.to(() => const CalendarScreen(standalone: true))),
      MenuItem('Notices', AppIcons.inbox, AppColors.navy, () => Get.to(() => const InboxScreen(standalone: true))),
    ];
    return Scaffold(
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            HeroHeader(
              child: SafeArea(
                bottom: false,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${greeting()},', style: TextStyle(color: Colors.white.withValues(alpha: 0.75))),
                              Obx(() => Text(auth.user.value?.name ?? '',
                                  style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800))),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => Get.to(() => const InboxScreen(standalone: true)),
                          icon: const Icon(AppIcons.bell, color: Colors.white),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Obx(() {
                      final s = auth.school.value;
                      return Text(
                        [s?.name, if (s?.currentTerm != null) '${s!.currentTerm} · ${s.currentSession ?? ''}'].whereType<String>().join('\n'),
                        style: TextStyle(color: Colors.white.withValues(alpha: 0.8), fontSize: 13),
                      );
                    }),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (owing.isNotEmpty && (user?.module('online_payments') ?? true))
                    FadeSlideIn(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: _FeesBanner(
                          amount: totalOwed,
                          children: owing.length,
                          onPay: () => _forChild('Pay fees', (c) async {
                            await Get.to(() => PayFeesScreen(student: c));
                            reload();
                          }),
                        ),
                      ),
                    ),
                  SectionTitle(kids.length == 1 ? 'Your child' : 'Your children'),
                  if (kids.isEmpty)
                    const EmptyState(
                      icon: AppIcons.people,
                      title: 'No child linked yet',
                      message: 'Ask the school to link your children to this phone number.',
                    ),
                  ...FadeSlideIn.staggered([
                    for (final c in kids)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _ChildCard(child: c, onTap: () async {
                          await Get.to(() => StudentHubScreen(studentId: c.id, initial: c));
                          reload();
                        }),
                      ),
                  ]),
                  if (kids.isNotEmpty) ...[
                    const SectionTitle('Family menu'),
                    MenuGrid(items: menu),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChildCard extends StatelessWidget {
  const _ChildCard({required this.child, required this.onTap});

  final StudentCard child;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final owes = (child.feeBalance ?? 0) > 0;
    return AppCard(
      onTap: onTap,
      child: Column(
        children: [
          Row(
            children: [
              Hero(tag: 'student-${child.id}', child: PersonAvatar(name: child.fullName, url: child.photoUrl, size: 52)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(child.fullName, style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text([child.className, child.admissionNo].whereType<String>().join(' · '),
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
                  ],
                ),
              ),
              const Icon(AppIcons.arrow, size: 18, color: AppColors.textMuted),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _Mini(label: 'Fee balance', value: child.feeBalance == null ? '—' : Fmt.nairaShort(child.feeBalance), color: owes ? AppColors.danger : AppColors.success),
              _Mini(label: 'Attendance', value: Fmt.percent(child.attendanceRate), color: AppColors.blue),
              _Mini(label: 'Absent', value: '${child.daysAbsent} day${child.daysAbsent == 1 ? '' : 's'}', color: child.daysAbsent > 0 ? AppColors.warning : AppColors.textMuted),
            ],
          ),
          if (child.latestResultLabel != null) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(AppIcons.results, size: 16, color: AppColors.textMuted),
                const SizedBox(width: 6),
                Expanded(child: Text('Latest result: ${child.latestResultLabel}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5))),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _Mini extends StatelessWidget {
  const _Mini({required this.label, required this.value, required this.color});

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            FittedBox(child: Text(value, style: TextStyle(fontWeight: FontWeight.w800, color: color, fontSize: 15))),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
          ],
        ),
      ),
    );
  }
}

class _FeesBanner extends StatelessWidget {
  const _FeesBanner({required this.amount, required this.children, required this.onPay});

  final double amount;
  final int children;
  final VoidCallback onPay;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFF97316), Color(0xFFDC2626)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: AppColors.danger.withValues(alpha: 0.25), blurRadius: 16, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(12)),
            child: const Icon(AppIcons.fees, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Outstanding fees${children > 1 ? ' · $children children' : ''}', style: TextStyle(color: Colors.white.withValues(alpha: 0.9), fontSize: 12.5)),
                CountUpText(Fmt.naira(amount), style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          PressScale(
            onTap: onPay,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: const Text('Pay now', style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ),
    );
  }
}
