import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

import '../../../core/network/api_exception.dart';
import '../../../core/offline/outbox.dart';
import '../../../core/utils/formatters.dart';
import '../../../data/models/staff.dart';
import '../../../data/repositories/school_repository.dart';

/// One column of marks on the phone: a whole assessment (CA 1, Exam…) or one
/// part of an assessment that is split (Exam → Theory / Objective).
class SheetColumn {
  const SheetColumn({
    required this.key,
    required this.name,
    required this.short,
    required this.max,
    required this.assessment,
    this.sub,
  });

  /// 'a<assessment id>' or 's<sub-assessment id>'.
  final String key;
  final String name;
  final String short;
  final double max;
  final Assessment assessment;
  final Assessment? sub;

  bool get isPart => sub != null;
  bool get isExam => assessment.name.toLowerCase().contains('exam');
}

/// A score sheet being filled in: typed marks are kept as "pending", checked
/// against each column's maximum as they are typed, and saved automatically a
/// few seconds after the teacher stops typing (or at once with Save).
///
/// Offline, the marks are kept on the phone (see [Outbox]) and sent when the
/// school can be reached; each carries the value the teacher saw, so a mark
/// changed elsewhere in the meantime is never overwritten.
class SheetController extends GetxController {
  SheetController(this.assignment);

  final SubjectAssignment assignment;

  Scoresheet? sheet;
  bool loading = true;
  bool saving = false;
  Object? error;
  bool fromCache = false;

  DateTime? savedAt;
  String? autoError;
  bool autosave = true;
  Timer? _auto;
  static const autosaveAfter = Duration(seconds: 3);

  /// 'assessment' (one column, every student) or 'student' (one student, every column).
  String mode = 'assessment';
  String? columnKey;
  String query = '';

  /// broadsheet id → column key → text typed.
  final Map<int, Map<String, String>> pending = {};

  /// broadsheet id → column key → value waiting in the outbox (offline saves).
  final Map<int, Map<String, double>> queued = {};

  final Map<String, TextEditingController> _controllers = {};
  Worker? _sentWorker;

  String get group => 'sheet:${assignment.subjectclassId}:${assignment.termId}:${assignment.sessionId}';

  @override
  void onInit() {
    super.onInit();
    _sentWorker = ever(Outbox.sent, (_) {
      if (pending.isEmpty && !saving) load(silent: true);
    });
    load();
  }

  @override
  void onClose() {
    _auto?.cancel();
    _sentWorker?.dispose();
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.onClose();
  }

  Future<void> load({bool silent = false}) async {
    if (!silent) {
      loading = true;
      error = null;
      update();
    }
    try {
      final s = await StaffRepository.scoresheet(assignment.subjectclassId!, termId: assignment.termId, sessionId: assignment.sessionId);
      fromCache = StaffRepository.lastFromCache;
      _take(s, keep: const {});
    } catch (e) {
      if (sheet == null) error = e;
    } finally {
      loading = false;
      update();
    }
  }

  void _take(Scoresheet s, {Set<int>? keep, bool resetControllers = true}) {
    sheet = s;
    if (keep != null) pending.removeWhere((bid, _) => !keep.contains(bid));
    _loadQueued();
    if (resetControllers) _resetControllers();
    final cols = columns;
    if (columnKey == null || !cols.any((c) => c.key == columnKey)) columnKey = cols.isEmpty ? null : cols.first.key;
  }

  /// Marks saved offline for this sheet, shown until they reach the school.
  void _loadQueued() {
    queued.clear();
    for (final item in Outbox.inGroup(group)) {
      final b = item.body;
      final isSub = b['is_sub'] == true;
      final rows = b['scores'] is List ? b['scores'] as List : const [];
      for (final r in rows.whereType<Map>()) {
        final bid = int.tryParse('${r['id']}') ?? 0;
        final vals = r['assessments'] is Map ? r['assessments'] as Map : const {};
        vals.forEach((k, v) {
          final n = double.tryParse('$v');
          if (n != null) queued.putIfAbsent(bid, () => {})['${isSub ? 's' : 'a'}$k'] = n;
        });
      }
    }
  }

  void _resetControllers() {
    final old = _controllers.values.toList();
    _controllers.clear();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final c in old) {
        c.dispose();
      }
    });
  }

  // ── columns & rows ─────────────────────────────────────────────────

  List<SheetColumn> get columns {
    final s = sheet;
    if (s == null) return const [];
    final out = <SheetColumn>[];
    for (final a in s.assessments) {
      if (a.hasSubs) {
        for (final p in a.subs) {
          out.add(SheetColumn(key: 's${p.id}', name: '${a.name} · ${p.name}', short: '${_abbr(a.name)}·${_abbr(p.name)}', max: p.maxScore, assessment: a, sub: p));
        }
      } else {
        out.add(SheetColumn(key: 'a${a.id}', name: a.name, short: _abbr(a.name), max: a.maxScore, assessment: a));
      }
    }
    return out;
  }

  static String _abbr(String name) {
    final n = name.trim();
    if (n.length <= 6) return n;
    final words = n.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.length > 1) return words.map((w) => RegExp(r'^\d+$').hasMatch(w) ? w : w[0].toUpperCase()).join();
    return n.substring(0, 4);
  }

  SheetColumn? get column {
    for (final c in columns) {
      if (c.key == columnKey) return c;
    }
    return null;
  }

  List<ScoreRow> get rows => sheet?.rows ?? const [];

  List<ScoreRow> get visibleRows {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return rows;
    return rows.where((r) => r.name.toLowerCase().contains(q) || (r.admissionNo ?? '').toLowerCase().contains(q)).toList();
  }

  bool get editable => sheet?.editable ?? false;
  bool rowEditable(ScoreRow r) => editable && !r.locked;

  // ── values ─────────────────────────────────────────────────────────

  /// The parts of a split assessment carry nothing, but the assessment itself
  /// has a score (it was entered as a whole on the portal).
  bool enteredAsWhole(ScoreRow r, Assessment a) {
    if (!a.hasSubs) return false;
    final whole = r.scores[a.id] ?? 0;
    if (whole <= 0) return false;
    return a.subs.every((p) => (r.subScores[p.id] ?? 0) == 0);
  }

  /// The value saved at the school for this column (null = nothing entered).
  double? saved(ScoreRow r, SheetColumn c) {
    if (c.isPart) {
      if (enteredAsWhole(r, c.assessment)) return null;
      return r.subScores[c.sub!.id];
    }
    return r.scores[c.assessment.id];
  }

  /// The raw stored value, sent as "base" so offline saves never overwrite a newer mark.
  double? _base(ScoreRow r, SheetColumn c) => c.isPart ? r.subScores[c.sub!.id] : r.scores[c.assessment.id];

  double? queuedValue(ScoreRow r, SheetColumn c) => queued[r.broadsheetId]?[c.key];

  /// What the field shows: typed text, else a mark waiting to upload, else the saved mark.
  String text(ScoreRow r, SheetColumn c) {
    final p = pending[r.broadsheetId]?[c.key];
    if (p != null) return p;
    final q = queuedValue(r, c);
    if (q != null) return Fmt.number(q);
    final v = saved(r, c);
    return v == null ? '' : Fmt.number(v);
  }

  TextEditingController controllerFor(ScoreRow r, SheetColumn c) =>
      _controllers.putIfAbsent('${r.broadsheetId}|${c.key}', () => TextEditingController(text: text(r, c)));

  void setText(ScoreRow r, SheetColumn c, String value) {
    final v = value.trim();
    final map = pending.putIfAbsent(r.broadsheetId, () => {});
    final current = queuedValue(r, c) ?? saved(r, c);
    final same = v.isEmpty ? current == null : (double.tryParse(v) != null && current != null && (double.parse(v) - current).abs() < 0.0001);
    if (same || v.isEmpty) {
      map.remove(c.key);
    } else {
      map[c.key] = v;
    }
    if (map.isEmpty) pending.remove(r.broadsheetId);
    autoError = null;
    update(['bar', 'row-${r.broadsheetId}']);
    _scheduleAutosave();
  }

  /// Put a mark straight in (fast entry, "Absent", "Full marks"), keeping an open field in step.
  void setMark(ScoreRow r, SheetColumn c, String value) {
    final ctl = _controllers['${r.broadsheetId}|${c.key}'];
    if (ctl != null && ctl.text != value) ctl.text = value;
    setText(r, c, value);
  }

  String? problem(ScoreRow r, SheetColumn c) {
    final v = pending[r.broadsheetId]?[c.key];
    if (v == null || v.isEmpty) return null;
    final n = double.tryParse(v);
    if (n == null) return 'Not a number';
    if (n < 0 || n > c.max) return '0 – ${Fmt.number(c.max)}';
    return null;
  }

  bool get hasProblems => rows.any((r) => columns.any((c) => problem(r, c) != null));
  int get pendingCount => pending.values.fold<int>(0, (t, m) => t + m.length);
  int get queuedCount => queued.values.fold<int>(0, (t, m) => t + m.length);

  bool complete(ScoreRow r) => columns.every((c) => text(r, c).isNotEmpty || (c.isPart && enteredAsWhole(r, c.assessment)));
  int get completeCount => rows.where(complete).length;
  int enteredIn(SheetColumn c) => rows.where((r) => text(r, c).isNotEmpty).length;

  /// Total from what is on screen now (typed, waiting or saved), for the preview.
  double? preview(ScoreRow r) {
    final s = sheet;
    if (s == null) return null;
    double? value(Assessment a) {
      if (!a.hasSubs) return double.tryParse(text(r, columns.firstWhere((c) => c.key == 'a${a.id}')));
      if (enteredAsWhole(r, a) && !a.subs.any((p) => pending[r.broadsheetId]?['s${p.id}'] != null)) return r.scores[a.id];
      double sum = 0, max = 0;
      for (final p in a.subs) {
        final n = double.tryParse(text(r, columns.firstWhere((c) => c.key == 's${p.id}')));
        if (n == null) return null;
        sum += n;
        max += p.maxScore;
      }
      return max > 0 ? sum / max * a.maxScore : 0;
    }

    if (s.totalFormula == 'avg_ca_exam') {
      final cas = s.assessments.where((a) => !a.name.toLowerCase().contains('exam')).toList();
      final exams = s.assessments.where((a) => a.name.toLowerCase().contains('exam')).toList();
      double ca = 0;
      for (final a in cas) {
        final v = value(a);
        if (v == null) return null;
        ca += v;
      }
      double ex = 0;
      for (final a in exams) {
        final v = value(a);
        if (v == null) return null;
        ex += v;
      }
      final caAvg = cas.isEmpty ? 0 : ca / cas.length;
      return double.parse(((caAvg + ex) / 2).toStringAsFixed(1));
    }

    double t = 0;
    for (final a in s.assessments) {
      final v = value(a);
      if (v == null) return null;
      t += v;
    }
    return t;
  }

  void discard() {
    _auto?.cancel();
    pending.clear();
    _resetControllers();
    update();
  }

  // ── saving ─────────────────────────────────────────────────────────

  void _scheduleAutosave() {
    _auto?.cancel();
    if (!autosave || !editable || pending.isEmpty) return;
    _auto = Timer(autosaveAfter, () async {
      if (saving || pending.isEmpty || hasProblems) return;
      try {
        await save(auto: true);
      } on ApiException catch (e) {
        autoError = e.message;
      } finally {
        update(['bar']);
      }
    });
  }

  /// Builds the requests for what is pending: one for whole assessments and
  /// one per split assessment (its parts).
  List<({int? subOf, List<Map<String, dynamic>> rows, int count})> _requests(Map<int, Map<String, String>> sent) {
    final cols = {for (final c in columns) c.key: c};
    final byRow = <int, ScoreRow>{for (final r in rows) r.broadsheetId: r};
    final whole = <int, Map<String, dynamic>>{};
    final wholeBase = <int, Map<String, dynamic>>{};
    final parts = <int, Map<int, Map<String, dynamic>>>{};
    final partsBase = <int, Map<int, Map<String, dynamic>>>{};
    var wholeCount = 0;
    final partCount = <int, int>{};

    sent.forEach((bid, marks) {
      final r = byRow[bid];
      if (r == null) return;
      marks.forEach((key, txt) {
        final c = cols[key];
        final v = double.tryParse(txt);
        if (c == null || v == null) return;
        if (c.isPart) {
          final a = c.assessment.id;
          parts.putIfAbsent(a, () => {}).putIfAbsent(bid, () => {})['${c.sub!.id}'] = v;
          partsBase.putIfAbsent(a, () => {}).putIfAbsent(bid, () => {})['${c.sub!.id}'] = _base(r, c);
          partCount[a] = (partCount[a] ?? 0) + 1;
        } else {
          whole.putIfAbsent(bid, () => {})['${c.assessment.id}'] = v;
          wholeBase.putIfAbsent(bid, () => {})['${c.assessment.id}'] = _base(r, c);
          wholeCount++;
        }
      });
    });

    final out = <({int? subOf, List<Map<String, dynamic>> rows, int count})>[];
    if (whole.isNotEmpty) {
      out.add((
        subOf: null,
        rows: whole.entries.map<Map<String, dynamic>>((e) => {'id': e.key, 'assessments': e.value, 'base': wholeBase[e.key]}).toList(),
        count: wholeCount,
      ));
    }
    parts.forEach((a, byBid) {
      out.add((
        subOf: a,
        rows: byBid.entries.map<Map<String, dynamic>>((e) => {'id': e.key, 'assessments': e.value, 'base': partsBase[a]![e.key]}).toList(),
        count: partCount[a] ?? 0,
      ));
    });
    return out;
  }

  /// Saves what is pending. Returns messages the teacher should read
  /// (conflicts, refusals); empty when everything was saved.
  /// Offline, the marks are put in the outbox instead and sent later.
  Future<List<String>> save({bool auto = false}) async {
    final s = sheet;
    if (s == null || pending.isEmpty || hasProblems) return const [];
    _auto?.cancel();
    final sent = {for (final e in pending.entries) e.key: Map<String, String>.of(e.value)};
    final requests = _requests(sent);
    if (requests.isEmpty) return const [];

    saving = true;
    update(['bar']);
    final notes = <String>[];
    try {
      Scoresheet latest = s;
      var i = 0;
      for (; i < requests.length; i++) {
        final req = requests[i];
        try {
          final res = await StaffRepository.saveScoreRows(s, req.rows, subOf: req.subOf);
          latest = res.sheet;
          notes.addAll(_describeConflicts(res.conflicts, latest));
        } on ApiException catch (e) {
          if (!e.isOffline) rethrow;
          // Offline: keep this and the remaining requests on the phone.
          for (final rest in requests.sublist(i)) {
            await Outbox.add(
              kind: 'scores',
              path: '/staff/scoresheets/${s.subjectclassId}/bulk',
              body: {
                'term_id': s.termId,
                'session_id': s.sessionId,
                if (rest.subOf != null) 'is_sub': true,
                if (rest.subOf != null) 'assessment_id': rest.subOf,
                'scores': rest.rows,
              },
              label: '${s.subject} · ${s.className ?? ''} — ${rest.count} mark(s)',
              group: group,
            );
          }
          autoError = 'Offline — marks are kept on this phone and will upload automatically.';
          break;
        }
      }
      final keep = <int>{
        for (final e in pending.entries)
          if (!mapEquals(e.value, sent[e.key])) e.key,
      };
      _take(latest, keep: keep, resetControllers: !auto);
      if (i == requests.length) {
        savedAt = DateTime.now();
        autoError = null;
      }
      return notes;
    } finally {
      saving = false;
      if (auto) {
        update(['bar', 'fast', ...rows.map((x) => 'row-${x.broadsheetId}')]);
      } else {
        update();
      }
    }
  }

  List<String> _describeConflicts(List<Map<String, dynamic>> conflicts, Scoresheet s) {
    if (conflicts.isEmpty) return const [];
    final byRow = {for (final r in s.rows) r.broadsheetId: r};
    final cols = columns;
    return conflicts.map((c) {
      final r = byRow[int.tryParse('${c['broadsheet_id']}')];
      final key = '${c['is_sub'] == true ? 's' : 'a'}${c['key']}';
      final col = cols.where((x) => x.key == key);
      return '${r?.name ?? 'A student'} — ${col.isEmpty ? 'a score' : col.first.name}: changed to '
          '${Fmt.number(c['server'] is num ? c['server'] as num : null)} by someone else; your ${Fmt.number(c['yours'] is num ? c['yours'] as num : null)} was not saved.';
    }).toList();
  }

  /// After an Excel upload or a recalculation.
  void replaceSheet(Scoresheet s) {
    pending.clear();
    _take(s, keep: const {});
    savedAt = DateTime.now();
    update();
  }

  void setMode(String m) {
    mode = m;
    update();
  }

  void setColumn(String key) {
    columnKey = key;
    update();
    update(['fast']);
  }

  void search(String q) {
    query = q;
    update();
  }
}
