import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/staff.dart';
import 'sheet/sheet_controller.dart';

/// Fast entry: one column at a time, one student at a time, with a big number
/// field. Type the mark and press Next (or the keyboard's enter) to move on;
/// marks are checked as they are typed and saved automatically.
class FastEntryScreen extends StatefulWidget {
  const FastEntryScreen({super.key, required this.tag});

  /// Tag of the [SheetController] of the open score sheet.
  final String tag;

  @override
  State<FastEntryScreen> createState() => _FastEntryScreenState();
}

class _FastEntryScreenState extends State<FastEntryScreen> {
  late final SheetController c = Get.find<SheetController>(tag: widget.tag);
  final _input = TextEditingController();
  final _focus = FocusNode();
  int _i = 0;
  bool _onlyMissing = false;

  @override
  void initState() {
    super.initState();
    final col = c.column;
    if (col != null) {
      final first = _rows.indexWhere((r) => c.text(r, col).isEmpty);
      _i = first < 0 ? 0 : first;
    }
    _fill();
  }

  @override
  void dispose() {
    _input.dispose();
    _focus.dispose();
    super.dispose();
  }

  List<ScoreRow> get _rows => c.rows.where(c.rowEditable).toList();
  ScoreRow? get _row => _rows.isEmpty ? null : _rows[_i.clamp(0, _rows.length - 1).toInt()];

  void _fill() {
    final r = _row;
    final col = c.column;
    _input.text = (r == null || col == null) ? '' : c.text(r, col);
    _input.selection = TextSelection(baseOffset: 0, extentOffset: _input.text.length);
  }

  void _go(int to) {
    if (_rows.isEmpty) return;
    setState(() => _i = to.clamp(0, _rows.length - 1).toInt());
    _fill();
    _focus.requestFocus();
  }

  Future<void> _next() async {
    final col = c.column;
    final r = _row;
    if (col == null || r == null) return;
    if (c.problem(r, col) != null) {
      HapticFeedback.heavyImpact();
      return;
    }
    var j = _i + 1;
    while (_onlyMissing && j < _rows.length && c.text(_rows[j], col).isNotEmpty) {
      j++;
    }
    if (j < _rows.length) {
      _go(j);
      return;
    }
    final cols = c.columns;
    final at = cols.indexWhere((x) => x.key == col.key);
    final nextCol = at >= 0 && at < cols.length - 1 ? cols[at + 1] : null;
    final go = await confirmDialog(
      '${col.name} done',
      nextCol == null ? 'That was the last student and the last column.' : 'Go on to ${nextCol.name} (out of ${Fmt.number(nextCol.max)})?',
      confirm: nextCol == null ? 'Back to the sheet' : 'Next column',
    );
    if (!go || !mounted) return;
    if (nextCol == null) {
      if (c.pending.isNotEmpty && !c.hasProblems) await c.save();
      Get.back();
    } else {
      c.setColumn(nextCol.key);
      final first = _rows.indexWhere((x) => c.text(x, nextCol).isEmpty);
      _go(first < 0 ? 0 : first);
    }
  }

  void _put(String v) {
    final r = _row;
    final col = c.column;
    if (r == null || col == null) return;
    _input.text = v;
    _input.selection = TextSelection.collapsed(offset: v.length);
    c.setMark(r, col, v);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SheetController>(
      tag: widget.tag,
      id: 'fast',
      builder: (_) {
        final col = c.column;
        final r = _row;
        if (col == null || r == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Fast entry')),
            body: const EmptyState(icon: AppIcons.people, title: 'No students to enter marks for'),
          );
        }
        final done = _rows.where((x) => c.text(x, col).isNotEmpty).length;
        final err = c.problem(r, col);
        final total = c.preview(r);

        return PopScope(
          onPopInvokedWithResult: (didPop, _) {
            if (didPop && c.pending.isNotEmpty && !c.hasProblems && !c.saving) {
              c.save(auto: true).catchError((_) => <String>[]);
            }
          },
          child: Scaffold(
            appBar: AppBar(
              title: Text('${c.sheet?.subject ?? ''} · fast entry'),
              actions: [
                GetBuilder<SheetController>(
                  tag: widget.tag,
                  id: 'bar',
                  builder: (_) => Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: Center(
                      child: c.saving
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : Icon(c.pending.isEmpty ? Icons.cloud_done_outlined : (c.autoError != null ? Icons.cloud_off_outlined : Icons.cloud_upload_outlined)),
                    ),
                  ),
                ),
              ],
            ),
            body: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                SizedBox(
                  height: 40,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: c.columns.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) {
                      final x = c.columns[i];
                      final on = x.key == col.key;
                      return ChoiceChip(
                        label: Text('${x.name} /${Fmt.number(x.max)}'),
                        selected: on,
                        showCheckmark: false,
                        selectedColor: AppColors.navy,
                        backgroundColor: Colors.white,
                        labelStyle: TextStyle(color: on ? Colors.white : AppColors.text, fontWeight: FontWeight.w600),
                        onSelected: (_) {
                          c.setColumn(x.key);
                          _fill();
                          setState(() {});
                        },
                      );
                    },
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text('$done of ${_rows.length} have ${col.name}', style: const TextStyle(fontSize: 12.5, color: AppColors.textMuted))),
                    const Text('Only missing', style: TextStyle(fontSize: 12.5)),
                    Switch(value: _onlyMissing, onChanged: (v) => setState(() => _onlyMissing = v)),
                  ],
                ),
                AnimatedBar(value: _rows.isEmpty ? 0 : done / _rows.length, height: 6),
                const SizedBox(height: 16),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  transitionBuilder: (child, a) => FadeTransition(
                    opacity: a,
                    child: SlideTransition(position: Tween(begin: const Offset(0.08, 0), end: Offset.zero).animate(a), child: child),
                  ),
                  child: AppCard(
                    key: ValueKey('${r.broadsheetId}|${col.key}'),
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Text('Student ${_i + 1} of ${_rows.length}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                        const SizedBox(height: 10),
                        PersonAvatar(name: r.name, url: r.photoUrl, size: 64),
                        const SizedBox(height: 10),
                        Text(r.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                        Text(r.admissionNo ?? '', style: const TextStyle(color: AppColors.textMuted)),
                        const SizedBox(height: 18),
                        SizedBox(
                          width: 230,
                          child: TextField(
                            controller: _input,
                            focusNode: _focus,
                            autofocus: true,
                            textAlign: TextAlign.center,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            textInputAction: TextInputAction.next,
                            inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                            style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: err != null ? AppColors.danger : AppColors.navy),
                            decoration: InputDecoration(
                              hintText: '–',
                              suffixText: '/ ${Fmt.number(col.max)}',
                              errorText: err == null ? null : 'Must be $err',
                              labelText: col.name,
                            ),
                            onChanged: (v) {
                              c.setMark(r, col, v);
                              setState(() {});
                            },
                            onSubmitted: (_) {
                              _next();
                              _focus.requestFocus();
                            },
                          ),
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          alignment: WrapAlignment.center,
                          children: [
                            ActionChip(avatar: const Icon(Icons.person_off_outlined, size: 18), label: const Text('Absent (0)'), onPressed: () => _put('0')),
                            ActionChip(avatar: const Icon(Icons.star_outline_rounded, size: 18), label: Text('Full (${Fmt.number(col.max)})'), onPressed: () => _put(Fmt.number(col.max))),
                            ActionChip(avatar: const Icon(Icons.backspace_outlined, size: 18), label: const Text('Clear'), onPressed: () => _put('')),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                          decoration: BoxDecoration(color: AppColors.sky, borderRadius: BorderRadius.circular(12)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              _fig('Total now', total == null ? '—' : Fmt.number(total), bold: true),
                              _fig('Saved', Fmt.number(r.total)),
                              _fig('Grade', r.grade ?? '—'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _i > 0 ? () => _go(_i - 1) : null,
                        icon: const Icon(Icons.chevron_left_rounded),
                        label: const Text('Previous'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: err == null ? _next : null,
                        icon: const Icon(Icons.chevron_right_rounded),
                        label: const Text('Next'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                GetBuilder<SheetController>(
                  tag: widget.tag,
                  id: 'bar',
                  builder: (_) => Text(
                    c.autoError ??
                        (c.pending.isEmpty
                            ? (c.savedAt == null ? 'Marks save automatically as you go.' : 'All marks saved at ${TimeOfDay.fromDateTime(c.savedAt!).format(context)}.')
                            : (c.saving ? 'Saving…' : '${c.pendingCount} mark(s) waiting to save…')),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12.5, color: c.autoError != null ? AppColors.danger : AppColors.textMuted),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _fig(String label, String value, {bool bold = false}) => Column(
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
          Text(value, style: TextStyle(fontSize: bold ? 20 : 16, fontWeight: bold ? FontWeight.w900 : FontWeight.w700, color: AppColors.navy)),
        ],
      );
}
