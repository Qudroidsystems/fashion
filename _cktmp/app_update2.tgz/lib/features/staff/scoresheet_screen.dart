import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../core/network/api_exception.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/pdf_opener.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/staff.dart';
import '../../data/repositories/school_repository.dart';
import 'fast_entry_screen.dart';
import 'sheet/sheet_controller.dart';

/// Score entry for one subject class.
///
/// Two ways to work: **By assessment** (one column — CA 1, Exam, or a part of
/// a split assessment — for every student) or **By student** (every column for
/// one student, with a live total and "Next student"). Marks save
/// automatically a few seconds after typing stops; **Fast entry** gives one
/// big field per student. Offline, marks are kept on the phone and uploaded
/// later. Totals, grades and positions are worked out by the school with the
/// same code as the portal.
class ScoresheetScreen extends StatefulWidget {
  const ScoresheetScreen({super.key, required this.assignment});

  final SubjectAssignment assignment;

  @override
  State<ScoresheetScreen> createState() => _ScoresheetScreenState();
}

class _ScoresheetScreenState extends State<ScoresheetScreen> {
  late final String _tag;
  late final SheetController c;

  @override
  void initState() {
    super.initState();
    _tag = 'sheet-${widget.assignment.subjectclassId}-${DateTime.now().microsecondsSinceEpoch}';
    c = Get.put(SheetController(widget.assignment), tag: _tag);
  }

  @override
  void dispose() {
    Get.delete<SheetController>(tag: _tag);
    super.dispose();
  }

  String get _fileStem {
    final a = widget.assignment;
    return '${a.subject}_${a.className ?? ''}_${a.term ?? ''}_${a.session ?? ''}'.replaceAll(RegExp(r'[^A-Za-z0-9]+'), '_');
  }

  // ── saving ─────────────────────────────────────────────────────────

  Future<void> _save() async {
    FocusScope.of(context).unfocus();
    try {
      final notes = await c.save();
      if (!mounted) return;
      if (notes.isNotEmpty) {
        _showLines('Some marks were not saved', 'They were changed by someone else after you opened the sheet.', notes);
      } else if (c.autoError != null) {
        Toast.info(c.autoError!);
      } else {
        Toast.success('Marks saved.');
      }
    } on ApiException catch (e) {
      Toast.error(e);
    }
  }

  Future<bool> _confirmLeave() => confirmDialog(
        'Leave without saving?',
        '${c.pendingCount} mark(s) are not saved yet.',
        confirm: 'Leave',
        danger: true,
      );

  // ── Excel & printing ───────────────────────────────────────────────

  Future<void> _downloadExcel({bool share = false}) async {
    final s = c.sheet;
    if (s == null) return;
    if (c.pending.isNotEmpty && !c.hasProblems) await _save();
    final url = StaffRepository.scoresheetExcelUrl(s);
    final name = '${_fileStem}_scoresheet.xlsx';
    if (share) {
      await FileOpener.share(url, name, mime: FileOpener.xlsx);
    } else {
      await FileOpener.open(url, name, mime: FileOpener.xlsx, busyLabel: 'Preparing spreadsheet…');
    }
  }

  Future<void> _uploadExcel() async {
    final s = c.sheet;
    if (s == null) return;
    if (c.pending.isNotEmpty && !c.hasProblems) await _save();
    final picked = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const ['xlsx', 'xls']);
    final path = picked?.files.single.path;
    if (path == null || !mounted) return;
    if (!await confirmDialog('Upload scores?', 'Marks in "${picked!.files.single.name}" replace the marks on this sheet for the students in the file.', confirm: 'Upload')) {
      return;
    }
    c.saving = true;
    c.update(['bar']);
    try {
      final (sheet, message, warnings) = await StaffRepository.importScoresheet(s, path);
      c.replaceSheet(sheet);
      if (warnings.isEmpty) {
        Toast.success(message ?? 'Spreadsheet imported.');
      } else {
        _showLines(message ?? 'Imported with warnings', 'These rows were skipped; everything else was saved.', warnings);
      }
    } on ApiException catch (e) {
      final rows = e.errors['rows'] ?? const <String>[];
      if (rows.isNotEmpty) {
        _showLines(e.message, 'Fix these rows in the spreadsheet and upload it again.', rows, failed: true);
      } else {
        Toast.error(e);
      }
    } finally {
      c.saving = false;
      c.update();
    }
  }

  Future<void> _recalculate() async {
    final s = c.sheet;
    if (s == null) return;
    try {
      final fresh = await StaffRepository.scoresheet(s.subjectclassId, termId: s.termId, sessionId: s.sessionId, recalculate: true);
      c.replaceSheet(fresh);
      Toast.success('Totals and positions recalculated.');
    } catch (e) {
      Toast.error(e);
    }
  }

  void _showLines(String title, String hint, List<String> lines, {bool failed = false}) {
    Get.bottomSheet(
      Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.7),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(failed ? AppIcons.close : AppIcons.warning, color: failed ? AppColors.danger : AppColors.warning),
                const SizedBox(width: 10),
                Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
              ],
            ),
            const SizedBox(height: 6),
            Text(hint, style: const TextStyle(color: AppColors.textMuted)),
            const SizedBox(height: 12),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: lines.length,
                separatorBuilder: (_, __) => const Divider(height: 14),
                itemBuilder: (_, i) => Text(lines[i], style: const TextStyle(fontSize: 13.5)),
              ),
            ),
          ],
        ),
      ),
      isScrollControlled: true,
    );
  }

  void _openTools() {
    final s = c.sheet;
    if (s == null) return;
    Widget tool(IconData icon, Color color, String title, String subtitle, VoidCallback? onTap) => ListTile(
          enabled: onTap != null,
          onTap: onTap == null
              ? null
              : () {
                  Get.back();
                  onTap();
                },
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: color.withValues(alpha: onTap == null ? 0.05 : 0.12), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: onTap == null ? AppColors.textMuted : color, size: 20),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(subtitle, style: const TextStyle(fontSize: 12.5)),
        );

    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: FadeSlideIn.staggered([
                Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4))),
                if (c.editable) tool(Icons.bolt_rounded, AppColors.warning, 'Fast entry', 'One student at a time with a big number field', _fast),
                tool(AppIcons.download, AppColors.success, 'Download Excel sheet', 'Fill scores offline in Excel or Google Sheets', _downloadExcel),
                tool(AppIcons.upload, AppColors.blue, 'Upload filled Excel sheet', s.editable ? 'Import the scores from the downloaded template' : (s.lockMessage ?? 'This score sheet is locked'),
                    s.editable ? _uploadExcel : null),
                tool(AppIcons.message, AppColors.info, 'Share the Excel sheet', 'Send the template to your computer or e-mail', () => _downloadExcel(share: true)),
                tool(AppIcons.printer, AppColors.navy, 'Marks sheet (PDF)', 'Printable list of all scores', () => PdfOpener.open(StaffRepository.marksheetUrl(s), '${_fileStem}_marksheet.pdf')),
                tool(AppIcons.refresh, const Color(0xFF7C3AED), 'Recalculate positions', 'Refresh totals, grades and positions', c.pending.isEmpty ? _recalculate : null),
              ]),
            ),
          ),
        ),
      ),
      isScrollControlled: true,
    );
  }

  Future<void> _fast() async {
    await Get.to(() => FastEntryScreen(tag: _tag));
    if (mounted) setState(() {});
  }

  // ── screen ─────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SheetController>(
      tag: _tag,
      builder: (c) {
        final s = c.sheet;
        return PopScope(
          canPop: c.pending.isEmpty,
          onPopInvokedWithResult: (didPop, _) async {
            if (didPop) return;
            final nav = Navigator.of(context);
            // Unsaved but valid marks are saved (or kept offline) on the way out.
            if (!c.hasProblems && !c.saving) {
              try {
                await c.save();
                if (c.pending.isEmpty) {
                  nav.pop();
                  return;
                }
              } on ApiException catch (_) {}
            }
            if (await _confirmLeave()) {
              c.discard();
              nav.pop();
            }
          },
          child: Scaffold(
            appBar: AppBar(
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.assignment.subject, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  Text('${widget.assignment.className ?? ''} · ${widget.assignment.term ?? ''}',
                      style: TextStyle(fontSize: 12.5, color: Colors.white.withValues(alpha: 0.8))),
                ],
              ),
              actions: [
                if (s != null && c.editable) IconButton(tooltip: 'Fast entry', icon: const Icon(Icons.bolt_rounded), onPressed: _fast),
                if (s != null) IconButton(tooltip: 'Excel & printing', onPressed: c.saving ? null : _openTools, icon: const Icon(AppIcons.excel)),
              ],
            ),
            body: c.loading && s == null
                ? const SkeletonList()
                : (s == null
                    ? ErrorState(error: c.error ?? 'Could not open the score sheet.', onRetry: () => c.load())
                    : _body(context, c, s)),
            bottomNavigationBar: s == null ? null : GetBuilder<SheetController>(tag: _tag, id: 'bar', builder: (c) => _bar(context, c, s)),
          ),
        );
      },
    );
  }

  Widget _body(BuildContext context, SheetController c, Scoresheet s) {
    final rows = c.visibleRows;
    final byAssessment = c.mode == 'assessment';
    final col = c.column;
    final cols = c.columns;

    return Column(
      children: [
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (c.fromCache)
                const _Banner(icon: AppIcons.warning, color: AppColors.warning, text: 'Offline — showing the copy saved on this phone. Marks you enter are kept and uploaded later.'),
              if (!s.editable) _Banner(icon: AppIcons.lock, color: AppColors.warning, text: s.lockMessage ?? 'This score sheet is locked. You can view the marks.'),
              if (c.queuedCount > 0)
                _Banner(icon: AppIcons.upload, color: AppColors.info, text: '${c.queuedCount} mark(s) saved on this phone are waiting to upload.'),
              Row(
                children: [
                  Expanded(
                    child: SegmentedButton<String>(
                      showSelectedIcon: false,
                      segments: const [
                        ButtonSegment(value: 'assessment', label: Text('By assessment'), icon: Icon(Icons.view_column_outlined, size: 18)),
                        ButtonSegment(value: 'student', label: Text('By student'), icon: Icon(Icons.person_outline, size: 18)),
                      ],
                      selected: {c.mode},
                      onSelectionChanged: (v) => c.setMode(v.first),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (byAssessment)
                SizedBox(
                  height: 40,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: cols.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) {
                      final x = cols[i];
                      final on = x.key == c.columnKey;
                      return ChoiceChip(
                        label: Text('${x.name} /${Fmt.number(x.max)}'),
                        selected: on,
                        showCheckmark: false,
                        selectedColor: AppColors.navy,
                        backgroundColor: Colors.white,
                        labelStyle: TextStyle(color: on ? Colors.white : AppColors.text, fontWeight: FontWeight.w600),
                        onSelected: (_) => c.setColumn(x.key),
                      );
                    },
                  ),
                )
              else
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [for (final x in cols) _Pill('${x.name} /${Fmt.number(x.max)}', color: x.isExam ? AppColors.navy : AppColors.info)],
                ),
              const SizedBox(height: 10),
              _Progress(c: c, column: byAssessment ? col : null),
              const SizedBox(height: 10),
              TextField(
                onChanged: c.search,
                decoration: const InputDecoration(hintText: 'Find a student', prefixIcon: Icon(AppIcons.search), isDense: true),
              ),
            ],
          ),
        ),
        Expanded(
          child: rows.isEmpty
              ? ListView(children: [
                  const SizedBox(height: 60),
                  EmptyState(
                    icon: AppIcons.scores,
                    title: c.rows.isEmpty ? 'No students on this score sheet' : 'No student matches',
                    message: c.rows.isEmpty ? 'Students appear here once they are registered for the subject.' : null,
                  ),
                ])
              : RefreshIndicator(
                  onRefresh: () async {
                    if (c.pending.isEmpty) await c.load(silent: true);
                  },
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                    itemCount: rows.length,
                    itemBuilder: (context, i) {
                      final child = GetBuilder<SheetController>(
                        tag: _tag,
                        id: 'row-${rows[i].broadsheetId}',
                        builder: (c) => byAssessment && col != null
                            ? _AssessmentRow(c: c, row: rows[i], col: col)
                            : _StudentRow(c: c, row: rows[i], onTap: c.rowEditable(rows[i]) ? () => _edit(context, rows, i) : null),
                      );
                      return i < 12 ? FadeSlideIn(delay: Duration(milliseconds: 25 * i), child: child) : child;
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _bar(BuildContext context, SheetController c, Scoresheet s) {
    Widget child;
    if (c.pendingCount > 0) {
      final status = c.hasProblems ? 'Fix the marks in red to save' : (c.saving ? 'Saving…' : (c.autoError ?? 'Saving automatically…'));
      final bad = c.hasProblems || c.autoError != null;
      child = Row(
        children: [
          if (c.saving)
            const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
          else
            Icon(bad ? AppIcons.warning : AppIcons.upload, size: 18, color: bad ? AppColors.danger : AppColors.textMuted),
          const SizedBox(width: 8),
          Expanded(child: Text(status, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5))),
          TextButton(onPressed: c.saving ? null : c.discard, child: const Text('Undo')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(minimumSize: const Size(0, 42), padding: const EdgeInsets.symmetric(horizontal: 18)),
            onPressed: c.saving || c.hasProblems ? null : _save,
            child: Text('Save ${c.pendingCount}'),
          ),
        ],
      );
    } else if (s.editable) {
      final saved = c.savedAt == null ? null : TimeOfDay.fromDateTime(c.savedAt!).format(context);
      final missing = c.rows.length - c.completeCount;
      child = Row(
        children: [
          Icon(missing == 0 ? AppIcons.check : AppIcons.info, size: 18, color: missing == 0 ? AppColors.success : AppColors.textMuted),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              c.rows.isEmpty
                  ? 'No students on this sheet yet.'
                  : '${saved != null ? 'Saved at $saved. ' : ''}${missing == 0 ? 'Every student has all marks.' : '$missing of ${c.rows.length} students still need marks.'}',
              style: const TextStyle(fontSize: 12.5),
            ),
          ),
          if (c.rows.isNotEmpty && missing > 0)
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40), padding: const EdgeInsets.symmetric(horizontal: 12)),
              onPressed: _fast,
              icon: const Icon(Icons.bolt_rounded, size: 18),
              label: const Text('Fast entry'),
            ),
        ],
      );
    } else {
      child = Text(s.lockMessage ?? 'This sheet is locked; marks can no longer be changed here.', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12.5));
    }
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
        decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.border))),
        child: child,
      ),
    );
  }

  /// One student's marks for every column, with "Next student".
  Future<void> _edit(BuildContext context, List<ScoreRow> rows, int index) async {
    final next = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      builder: (ctx) => _StudentEditor(c: c, row: rows[index], hasNext: index < rows.length - 1),
    );
    if (next == true && index < rows.length - 1 && context.mounted) {
      await _edit(context, rows, index + 1);
    }
  }
}

class _Banner extends StatelessWidget {
  const _Banner({required this.icon, required this.color, required this.text});
  final IconData icon;
  final Color color;
  final String text;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
        child: Row(
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5))),
          ],
        ),
      );
}

class _Pill extends StatelessWidget {
  const _Pill(this.label, {required this.color});
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
        child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12)),
      );
}

class _Progress extends StatelessWidget {
  const _Progress({required this.c, this.column});
  final SheetController c;
  final SheetColumn? column;

  @override
  Widget build(BuildContext context) {
    final total = c.rows.length;
    final done = column == null ? c.completeCount : c.enteredIn(column!);
    final ratio = total == 0 ? 0.0 : done / total;
    final label = column == null ? '$done of $total students complete' : '$done of $total have ${column!.name}';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.textMuted)),
        const SizedBox(height: 6),
        AnimatedBar(value: ratio, color: ratio >= 1 ? AppColors.success : AppColors.blue, height: 6),
      ],
    );
  }
}

/// One student in "By student" mode: every mark as a chip, the live total, tap to edit.
class _StudentRow extends StatelessWidget {
  const _StudentRow({required this.c, required this.row, this.onTap});

  final SheetController c;
  final ScoreRow row;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final changed = c.pending.containsKey(row.broadsheetId);
    final waiting = c.queued.containsKey(row.broadsheetId);
    final bad = c.columns.any((x) => c.problem(row, x) != null);
    final total = c.preview(row);
    final showServer = !changed && !waiting;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        onTap: onTap,
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
        color: changed ? AppColors.sky : null,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                PersonAvatar(name: row.name, url: row.photoUrl, size: 38),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(row.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text(row.admissionNo ?? '', style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    ],
                  ),
                ),
                if (row.locked) const Padding(padding: EdgeInsets.only(right: 6), child: Icon(AppIcons.lock, size: 16, color: AppColors.warning)),
                if (changed) Padding(padding: const EdgeInsets.only(right: 8), child: StatusPill(bad ? 'Check' : 'Not saved', color: bad ? AppColors.danger : AppColors.warning)),
                if (!changed && waiting) const Padding(padding: EdgeInsets.only(right: 8), child: StatusPill('On phone', color: AppColors.info)),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      showServer ? Fmt.number(row.total) : (total == null ? '—' : Fmt.number(total)),
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
                    ),
                    if (showServer && row.grade != null)
                      Text('${row.grade}${row.position != null ? ' · ${Fmt.ordinal(row.position)}' : ''}',
                          style: TextStyle(color: AppColors.grade(row.grade), fontSize: 12, fontWeight: FontWeight.w700)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final x in c.columns)
                  _MarkChip(
                    label: x.short,
                    value: c.text(row, x),
                    max: x.max,
                    error: c.problem(row, x) != null,
                    note: x.isPart && c.enteredAsWhole(row, x.assessment) ? 'whole' : null,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MarkChip extends StatelessWidget {
  const _MarkChip({required this.label, required this.value, required this.max, this.error = false, this.note});

  final String label;
  final String value;
  final double max;
  final bool error;
  final String? note;

  @override
  Widget build(BuildContext context) {
    final empty = value.isEmpty;
    final color = error ? AppColors.danger : (empty ? AppColors.textMuted : AppColors.text);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: empty ? Colors.transparent : AppColors.background,
        border: Border.all(color: error ? AppColors.danger : AppColors.border),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text('$label ${empty ? (note == null ? '–' : '($note)') : value}/${Fmt.number(max)}',
          style: TextStyle(fontSize: 12, color: color, fontWeight: empty ? FontWeight.w500 : FontWeight.w700)),
    );
  }
}

/// One student in "By assessment" mode: the mark for the chosen column in a text field.
class _AssessmentRow extends StatelessWidget {
  const _AssessmentRow({required this.c, required this.row, required this.col});

  final SheetController c;
  final ScoreRow row;
  final SheetColumn col;

  @override
  Widget build(BuildContext context) {
    final err = c.problem(row, col);
    final changed = c.pending[row.broadsheetId]?.containsKey(col.key) ?? false;
    final waiting = c.queuedValue(row, col) != null && !changed;
    final whole = col.isPart && c.enteredAsWhole(row, col.assessment) ? row.scores[col.assessment.id] : null;
    final editable = c.rowEditable(row);

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(12, 8, 10, 8),
        color: changed ? AppColors.sky : null,
        child: Row(
          children: [
            PersonAvatar(name: row.name, url: row.photoUrl, size: 36),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(row.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(
                    [
                      'Total ${Fmt.number(row.total)}',
                      if (row.grade != null) row.grade!,
                      if (whole != null) '${col.assessment.name} ${Fmt.number(whole)} (whole)',
                      if (waiting) 'on phone',
                    ].join(' · '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: waiting ? AppColors.info : AppColors.grade(row.grade), fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 104,
              child: TextField(
                key: ValueKey('${row.broadsheetId}|${col.key}'),
                controller: c.controllerFor(row, col),
                enabled: editable,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                textInputAction: TextInputAction.next,
                textAlign: TextAlign.center,
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                onChanged: (v) => c.setText(row, col, v),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                decoration: InputDecoration(
                  isDense: true,
                  hintText: '–',
                  suffixText: '/${Fmt.number(col.max)}',
                  errorText: err,
                  errorStyle: const TextStyle(fontSize: 10.5),
                  contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StudentEditor extends StatefulWidget {
  const _StudentEditor({required this.c, required this.row, required this.hasNext});

  final SheetController c;
  final ScoreRow row;
  final bool hasNext;

  @override
  State<_StudentEditor> createState() => _StudentEditorState();
}

class _StudentEditorState extends State<_StudentEditor> {
  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    final row = widget.row;
    final cols = c.columns;
    final total = c.preview(row);
    final wholeNotes = <String>{
      for (final x in cols)
        if (x.isPart && c.enteredAsWhole(row, x.assessment))
          '${x.assessment.name} was entered as a whole on the portal (${Fmt.number(row.scores[x.assessment.id])}/${Fmt.number(x.assessment.maxScore)}). Enter its parts to replace it.',
    };

    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                PersonAvatar(name: row.name, url: row.photoUrl, size: 46),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(row.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      Text(row.admissionNo ?? '', style: const TextStyle(color: AppColors.textMuted)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            for (final n in wholeNotes) _Banner(icon: AppIcons.info, color: AppColors.info, text: n),
            for (var i = 0; i < cols.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: TextField(
                  controller: c.controllerFor(row, cols[i]),
                  autofocus: i == 0,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  textInputAction: i == cols.length - 1 ? TextInputAction.done : TextInputAction.next,
                  inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                  onChanged: (v) {
                    c.setText(row, cols[i], v);
                    setState(() {});
                  },
                  decoration: InputDecoration(
                    labelText: cols[i].name,
                    suffixText: 'out of ${Fmt.number(cols[i].max)}',
                    errorText: c.problem(row, cols[i]),
                  ),
                ),
              ),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.sky, borderRadius: BorderRadius.circular(14)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _fig('Total now', total == null ? '—' : Fmt.number(total), bold: true),
                  _fig('Saved total', Fmt.number(row.total)),
                  _fig('Grade', row.grade ?? '—'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context, false), child: const Text('Done'))),
                if (widget.hasNext) ...[
                  const SizedBox(width: 12),
                  Expanded(child: ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Next student'))),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _fig(String label, String value, {bool bold = false}) => Column(
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
          Text(value, style: TextStyle(fontSize: bold ? 20 : 16, fontWeight: bold ? FontWeight.w900 : FontWeight.w700, color: AppColors.navy)),
        ],
      );
}
