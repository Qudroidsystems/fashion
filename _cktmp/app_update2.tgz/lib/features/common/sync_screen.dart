import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/network/api_client.dart';
import '../../core/offline/outbox.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/motion.dart';

/// A thin bar above the bottom navigation: offline, or changes waiting to upload.
class OfflineBar extends StatelessWidget {
  const OfflineBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final off = ApiClient.offline.value;
      final waiting = Outbox.items.length;
      final failed = Outbox.items.where((e) => e.error != null).length;
      final syncing = Outbox.syncing.value;
      if (!off && waiting == 0) return const SizedBox.shrink();
      final color = failed > 0 ? AppColors.danger : (off ? AppColors.warning : AppColors.info);
      final text = off
          ? (waiting > 0 ? 'Offline · $waiting change(s) saved on this phone' : 'Offline · showing saved pages')
          : (syncing ? 'Uploading $waiting change(s)…' : (failed > 0 ? '$failed change(s) could not be saved — tap to see' : '$waiting change(s) waiting to upload'));
      return Material(
        color: color,
        child: InkWell(
          onTap: () => Get.to(() => const SyncScreen()),
          child: SafeArea(
            top: false,
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
              child: Row(
                children: [
                  if (syncing)
                    const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  else
                    Icon(off ? Icons.cloud_off_rounded : Icons.cloud_upload_outlined, color: Colors.white, size: 16),
                  const SizedBox(width: 8),
                  Expanded(child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600))),
                  const Icon(AppIcons.arrow, color: Colors.white, size: 14),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}

/// What is saved on this phone waiting for the school, and what happened on the last upload.
class SyncScreen extends StatelessWidget {
  const SyncScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Offline & sync')),
      body: Obx(() {
        final items = Outbox.items.toList();
        final notes = Outbox.notes.toList();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: FadeSlideIn.staggered([
            AppCard(
              color: ApiClient.offline.value ? AppColors.warning.withValues(alpha: 0.08) : AppColors.success.withValues(alpha: 0.08),
              child: Row(
                children: [
                  Icon(ApiClient.offline.value ? Icons.cloud_off_rounded : Icons.cloud_done_rounded,
                      color: ApiClient.offline.value ? AppColors.warning : AppColors.success, size: 30),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      ApiClient.offline.value
                          ? 'You are offline. Pages you opened before still show, and score sheets and registers you save are kept here until the school can be reached.'
                          : 'You are online. Changes below are uploaded automatically.',
                    ),
                  ),
                ],
              ),
            ),
            SectionTitle(
              'Waiting to upload (${items.length})',
              trailing: TextButton.icon(
                onPressed: Outbox.syncing.value || items.isEmpty ? null : Outbox.flush,
                icon: const Icon(AppIcons.refresh, size: 16),
                label: const Text('Send now'),
              ),
            ),
            if (items.isEmpty) const EmptyState(icon: Icons.cloud_done_outlined, title: 'Nothing waiting', message: 'Everything you saved has reached the school.'),
            for (final it in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: AppCard(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(it.kind == 'attendance' ? AppIcons.register : AppIcons.scores, color: it.error != null ? AppColors.danger : AppColors.navy),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(it.label, style: const TextStyle(fontWeight: FontWeight.w700)),
                            Text('Saved ${Fmt.ago(it.createdAt)}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                            if (it.error != null) ...[
                              const SizedBox(height: 4),
                              Text(it.error!, style: const TextStyle(color: AppColors.danger, fontSize: 12.5)),
                            ],
                          ],
                        ),
                      ),
                      if (it.error != null)
                        IconButton(
                          tooltip: 'Remove',
                          icon: const Icon(AppIcons.close, color: AppColors.danger),
                          onPressed: () async {
                            if (await confirmDialog('Remove this change?', 'It was refused by the school and will not be sent.', confirm: 'Remove', danger: true)) {
                              await Outbox.remove(it.id);
                            }
                          },
                        ),
                    ],
                  ),
                ),
              ),
            if (notes.isNotEmpty) ...[
              SectionTitle('From the last uploads', trailing: TextButton(onPressed: Outbox.clearNotes, child: const Text('Clear'))),
              for (final n in notes)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: AppCard(
                    color: AppColors.warning.withValues(alpha: 0.06),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(AppIcons.warning, color: AppColors.warning, size: 18),
                        const SizedBox(width: 10),
                        Expanded(child: Text(n, style: const TextStyle(fontSize: 13))),
                      ],
                    ),
                  ),
                ),
            ],
            const SectionTitle('What works offline'),
            const AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _Line(true, 'Open any page you have opened before (results, fees, timetable, notices, score sheets, registers).'),
                  _Line(true, 'Enter scores — they upload later; a score someone changed meanwhile is never overwritten.'),
                  _Line(true, 'Mark attendance for a day you opened online — it uploads later the same way.'),
                  _Line(false, 'Paying fees, signing in, changing your password, leave requests, Excel upload and report approvals need a connection.'),
                ],
              ),
            ),
          ]),
        );
      }),
    );
  }
}

class _Line extends StatelessWidget {
  const _Line(this.ok, this.text);
  final bool ok;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(ok ? AppIcons.check : AppIcons.close, size: 18, color: ok ? AppColors.success : AppColors.danger),
            const SizedBox(width: 10),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 13.5))),
          ],
        ),
      );
}
