import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../common/calendar_screen.dart';
import '../parent/child_profile_screen.dart';
import '../parent/guidance_screen.dart';
import '../parent/learning_screen.dart';
import '../parent/performance_screen.dart';
import '../parent/report_cards_screen.dart';
import '../parent/teachers_screen.dart';
import 'pay_fees_screen.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import '../auth/auth_controller.dart';
import '../common/inbox_screen.dart';
import 'attendance_screen.dart';
import 'fees_screen.dart';
import 'results_screen.dart';
import 'student_leave_screen.dart';
import 'timetable_screen.dart';

/// One student's page: summary and the way into results, fees,
/// attendance, timetable and leave. Used by parents (per child) and as the
/// student's own home tab.
class StudentHubScreen extends StatefulWidget {
  const StudentHubScreen({super.key, required this.studentId, this.initial, this.asTab = false});

  final int studentId;
  final StudentCard? initial;
  final bool asTab;

  @override
  State<StudentHubScreen> createState() => _StudentHubScreenState();
}

class _StudentHubScreenState extends LoadState<StudentHubScreen, StudentCard> {
  @override
  void initState() {
    data = widget.initial;
    super.initState();
  }

  @override
  Future<StudentCard> fetch() => StudentRepository.student(widget.studentId);

  @override
  Widget build(BuildContext context) {
    final user = AuthController.to.user.value;
    final s = data;
    final canLeave = user?.can('student_leave.apply') ?? false;

    final results = user?.module('results') ?? true;
    final finance = user?.module('finance') ?? true;
    final canPay = (user?.module('online_payments') ?? true) && (s?.relationship != null) && (s?.feeBalance ?? 0) > 0;
    final menu = s == null
        ? const <MenuItem>[]
        : <MenuItem>[
            if (results) MenuItem('Results', AppIcons.results, AppColors.blue, () => Get.to(() => ResultsScreen(student: s))),
            if (results) MenuItem('Progress', AppIcons.chart, const Color(0xFF7C3AED), () => Get.to(() => PerformanceScreen(student: s))),
            if (results) MenuItem('AI guide', Icons.auto_awesome, const Color(0xFF4F46E5), () => Get.to(() => GuidanceScreen(student: s))),
            if (results) MenuItem('Report cards', AppIcons.document, const Color(0xFFDB2777), () => Get.to(() => ReportCardsScreen(student: s))),
            if (finance) MenuItem('Fees', AppIcons.fees, AppColors.success, () => Get.to(() => FeesScreen(student: s))),
            if (canPay) MenuItem('Pay fees', AppIcons.pay, const Color(0xFF059669), () async {
              await Get.to(() => PayFeesScreen(student: s));
              reload();
            }),
            MenuItem('Attendance', AppIcons.attendance, AppColors.info, () => Get.to(() => AttendanceScreen(student: s))),
            if (user?.module('timetable') ?? true)
              MenuItem('Timetable', AppIcons.timetable, AppColors.warning, () => Get.to(() => TimetableScreen(student: s))),
            MenuItem('Homework', AppIcons.book, const Color(0xFF0D9488), () => Get.to(() => LearningScreen(student: s))),
            MenuItem('Teachers', AppIcons.teacher, const Color(0xFFEA580C), () => Get.to(() => TeachersScreen(student: s))),
            MenuItem('Profile', AppIcons.profile, AppColors.navy, () => Get.to(() => ChildProfileScreen(student: s))),
            if (canLeave) MenuItem('Leave', AppIcons.leave, const Color(0xFF4F46E5), () => Get.to(() => StudentLeaveScreen(studentId: s.id))),
            MenuItem('Calendar', AppIcons.calendar, const Color(0xFF334155), () => Get.to(() => const CalendarScreen(standalone: true))),
          ];

    final body = (s == null)
        ? AsyncBody(loading: loading, error: error, onRetry: load, child: const SizedBox())
        : RefreshIndicator(
            onRefresh: reload,
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                HeroHeader(
                  child: SafeArea(
                    bottom: false,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            if (!widget.asTab)
                              IconButton(onPressed: () => Get.back(), icon: const Icon(Icons.arrow_back, color: Colors.white)),
                            const Spacer(),
                            if (widget.asTab)
                              IconButton(
                                onPressed: () => Get.to(() => const InboxScreen(standalone: true)),
                                icon: const Icon(AppIcons.bell, color: Colors.white),
                              ),
                          ],
                        ),
                        Hero(
                          tag: 'student-${s.id}',
                          child: Container(
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withValues(alpha: 0.5), width: 2)),
                            child: PersonAvatar(name: s.fullName, url: s.photoUrl, size: 76),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(s.fullName, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Text([s.className, s.admissionNo].whereType<String>().join(' · '),
                            style: TextStyle(color: Colors.white.withValues(alpha: 0.8))),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      ...FadeSlideIn.staggered([
                        Row(
                          children: [
                            if (finance) ...[
                              Expanded(
                                child: StatTile(
                                  label: 'Fee balance',
                                  value: s.feeBalance == null ? '—' : Fmt.nairaShort(s.feeBalance),
                                  icon: AppIcons.fees,
                                  color: (s.feeBalance ?? 0) > 0 ? AppColors.danger : AppColors.success,
                                  onTap: () => Get.to(() => FeesScreen(student: s)),
                                ),
                              ),
                              const SizedBox(width: 10),
                            ],
                            Expanded(
                              child: StatTile(
                                label: 'Attendance',
                                value: Fmt.percent(s.attendanceRate),
                                icon: AppIcons.attendance,
                                color: AppColors.blue,
                                onTap: () => Get.to(() => AttendanceScreen(student: s)),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: StatTile(label: 'Days absent', value: '${s.daysAbsent}', icon: AppIcons.calendarDay, color: AppColors.warning),
                            ),
                          ],
                        ),
                        if (s.latestResultLabel != null && results)
                          Padding(
                            padding: const EdgeInsets.only(top: 12),
                            child: AppCard(
                              onTap: () => Get.to(() => ResultsScreen(student: s)),
                              color: AppColors.sky,
                              padding: const EdgeInsets.all(14),
                              child: Row(
                                children: [
                                  const Icon(AppIcons.medal, color: AppColors.navy),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text('Latest result', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                                        Text(s.latestResultLabel!, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.navy)),
                                      ],
                                    ),
                                  ),
                                  const Icon(AppIcons.arrow, size: 18, color: AppColors.navy),
                                ],
                              ),
                            ),
                          ),
                      ]),
                      const SectionTitle('Menu'),
                      MenuGrid(items: menu),
                    ],
                  ),
                ),
              ],
            ),
          );

    return Scaffold(body: body);
  }
}

