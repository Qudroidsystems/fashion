import 'package:get_storage/get_storage.dart';

/// What the app keeps on the phone between launches: the API token, the
/// last user profile (so the app opens instantly) and the chosen "face".
class SessionStore {
  SessionStore._();

  static final GetStorage _box = GetStorage();

  static const _kToken = 'auth_token';
  static const _kUser = 'auth_user';
  static const _kFace = 'active_face';
  static const _kLastLogin = 'last_login';
  static const _kOnboarded = 'onboarding_done';
  static const _kSchool = 'school_info';
  static const _kSchoolUrl = 'school_url';
  static const _kKnownSchools = 'known_schools';

  static String? get token => _box.read<String>(_kToken);
  static Future<void> setToken(String? value) =>
      value == null ? _box.remove(_kToken) : _box.write(_kToken, value);

  static Map<String, dynamic>? get user {
    final raw = _box.read(_kUser);
    return raw is Map ? Map<String, dynamic>.from(raw) : null;
  }

  static Future<void> setUser(Map<String, dynamic>? value) =>
      value == null ? _box.remove(_kUser) : _box.write(_kUser, value);

  static String? get face => _box.read<String>(_kFace);
  static Future<void> setFace(String? value) =>
      value == null ? _box.remove(_kFace) : _box.write(_kFace, value);

  /// The e-mail / phone last used to sign in, to pre-fill the form.
  static String? get lastLogin => _box.read<String>(_kLastLogin);
  static Future<void> setLastLogin(String value) => _box.write(_kLastLogin, value);

  /// The intro slides are shown once per install.
  static bool get onboardingDone => _box.read<bool>(_kOnboarded) ?? false;
  static Future<void> setOnboardingDone() => _box.write(_kOnboarded, true);

  /// Last school details from the server, so the splash shows the name and
  /// logo straight away, even offline.
  static Map<String, dynamic>? get school {
    final raw = _box.read(_kSchool);
    return raw is Map ? Map<String, dynamic>.from(raw) : null;
  }

  static Future<void> setSchool(Map<String, dynamic> value) => _box.write(_kSchool, value);

  /// The school's portal address chosen on the connect screen.
  static String? get schoolUrl => _box.read<String>(_kSchoolUrl);

  static Future<void> setSchoolUrl(String? value) async {
    if (value == null) {
      await _box.remove(_kSchoolUrl);
      await _box.remove(_kSchool);
    } else {
      await _box.write(_kSchoolUrl, value);
    }
  }

  /// Schools used on this phone before: [{url, name, logo_url}], newest first.
  static List<Map<String, dynamic>> get knownSchools {
    final raw = _box.read(_kKnownSchools);
    return raw is List ? raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];
  }

  static Future<void> rememberSchool(String url, String name, String? logoUrl) async {
    final list = knownSchools.where((s) => s['url'] != url).toList();
    list.insert(0, {'url': url, 'name': name, 'logo_url': logoUrl});
    await _box.write(_kKnownSchools, list.take(6).toList());
  }

  static Future<void> forgetSchool(String url) =>
      _box.write(_kKnownSchools, knownSchools.where((s) => s['url'] != url).toList());

  static Future<void> clear() async {
    await _box.remove(_kToken);
    await _box.remove(_kUser);
    await _box.remove(_kFace);
  }
}
