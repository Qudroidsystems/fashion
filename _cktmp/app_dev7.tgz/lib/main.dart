import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'app.dart';
import 'core/push/push_notifications.dart';
import 'core/storage/session_store.dart';
import 'features/auth/auth_controller.dart';
import 'features/common/inbox_screen.dart';
import 'features/staff/staff_timetable_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  await GetStorage.init();
  await PushNotifications.init();
  PushNotifications.onOpen = _openNotification;
  Get.put(AuthController(), permanent: true);

  runApp(const ViteSchoolsApp());
}

/// Tapping a push notification opens the matching screen.
void _openNotification(String type, Map<String, dynamic> data) {
  if (SessionStore.token == null) return;
  Future<void>.delayed(const Duration(milliseconds: 600), () {
    if (type == 'lesson' || type == 'timetable') {
      Get.to(() => const StaffTimetableScreen());
    } else {
      Get.to(() => const InboxScreen(standalone: true));
    }
  });
}
