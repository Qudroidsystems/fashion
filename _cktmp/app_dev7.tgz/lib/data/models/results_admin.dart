import '../../core/utils/json.dart';
import 'user.dart';

/// One class on the results board (GET /results/board).
class BoardClass {
  BoardClass({
    required this.classId,
    required this.className,
    this.teacher,
    this.students = 0,
    this.subjects = 0,
    this.vettedPct = 0,
    this.teacherComments = 0,
    this.ready = false,
    this.status = 'pending',
    this.statusLabel = '',
  });

  final int classId;
  final String className;
  final String? teacher;
  final int students;
  final int subjects;
  final int vettedPct;
  final int teacherComments;
  final bool ready;
  final String status;
  final String statusLabel;

  factory BoardClass.fromJson(Map<String, dynamic> j) => BoardClass(
        classId: asInt(j['class_id']) ?? 0,
        className: asString(j['class_name']) ?? '',
        teacher: asString(j['teacher']),
        students: asInt(j['students']) ?? 0,
        subjects: asInt(j['subjects']) ?? 0,
        vettedPct: asInt(j['vetted_pct']) ?? 0,
        teacherComments: asInt(j['teacher_comments']) ?? 0,
        ready: asBool(j['ready']),
        status: asString(j['status']) ?? 'pending',
        statusLabel: asString(j['status_label']) ?? '',
      );
}

class ResultsBoard {
  ResultsBoard({required this.classes, required this.termId, required this.sessionId, this.terms = const [], this.sessions = const [], this.canApprove = false, this.enforced = false});

  final List<BoardClass> classes;
  final int termId;
  final int sessionId;
  final List<IdName> terms;
  final List<IdName> sessions;
  final bool canApprove;
  final bool enforced;
}

class BroadsheetSubject {
  const BroadsheetSubject(this.id, this.name, this.code);
  final int id;
  final String name;
  final String? code;

  String get short => (code != null && code!.isNotEmpty) ? code! : (name.length > 4 ? name.substring(0, 4) : name);
}

class BroadsheetRow {
  BroadsheetRow({
    required this.studentId,
    required this.name,
    this.admissionNo,
    this.photoUrl,
    required this.scores,
    this.termAverage,
    this.cumAverage,
    this.totalTerm,
    this.gpa,
    this.position,
    this.numSubjects = 0,
  });

  final int studentId;
  final String name;
  final String? admissionNo;
  final String? photoUrl;

  /// subject id → {total, cum_ave, grade}
  final Map<int, Map<String, dynamic>> scores;
  final double? termAverage;
  final double? cumAverage;
  final double? totalTerm;
  final double? gpa;
  final int? position;
  final int numSubjects;

  factory BroadsheetRow.fromJson(Map<String, dynamic> j) => BroadsheetRow(
        studentId: asInt(j['student_id']) ?? 0,
        name: asString(j['name']) ?? '',
        admissionNo: asString(j['admission_no']),
        photoUrl: asString(j['photo_url']),
        scores: asMap(j['subjects']).map((k, v) => MapEntry(int.tryParse(k) ?? 0, asMap(v))),
        termAverage: asDouble(j['term_average']),
        cumAverage: asDouble(j['cum_average']),
        totalTerm: asDouble(j['total_term']),
        gpa: asDouble(j['gpa']),
        position: asInt(j['position']),
        numSubjects: asInt(j['num_subjects']) ?? 0,
      );
}

class Broadsheet {
  Broadsheet({required this.classId, this.className, this.term, this.session, required this.basis, this.classAverage, this.subjects = const [], this.rows = const []});

  final int classId;
  final String? className;
  final String? term;
  final String? session;
  final String basis;
  final double? classAverage;
  final List<BroadsheetSubject> subjects;
  final List<BroadsheetRow> rows;

  bool get byTotal => basis == 'total';

  factory Broadsheet.fromJson(Map<String, dynamic> j) => Broadsheet(
        classId: asInt(j['class_id']) ?? 0,
        className: asString(j['class_name']),
        term: asString(j['term']),
        session: asString(j['session']),
        basis: asString(j['basis']) ?? 'cum_ave',
        classAverage: asDouble(j['class_average']),
        subjects: asMapList(j['subjects'])
            .map((s) => BroadsheetSubject(asInt(s['subject_id']) ?? 0, asString(s['name']) ?? '', asString(s['code'])))
            .toList(),
        rows: asMapList(j['students']).map(BroadsheetRow.fromJson).toList(),
      );
}

class ApprovalStudent {
  ApprovalStudent({required this.id, required this.name, this.entries = 0, this.vetted = 0, this.average, this.teacherComment, this.principalComment});

  final int id;
  final String name;
  final int entries;
  final int vetted;
  final double? average;
  final String? teacherComment;
  final String? principalComment;
}

class ReportApproval {
  ReportApproval({
    required this.id,
    required this.label,
    required this.status,
    required this.statusLabel,
    this.submittedBy,
    this.submitNote,
    this.reviewedBy,
    this.reviewNote,
    this.enforced = false,
    this.canSubmit = false,
    this.canApprove = false,
    this.readiness = const {},
    this.history = const [],
    this.students = const [],
  });

  final int id;
  final String label;
  final String status;
  final String statusLabel;
  final String? submittedBy;
  final String? submitNote;
  final String? reviewedBy;
  final String? reviewNote;
  final bool enforced;
  final bool canSubmit;
  final bool canApprove;
  final Map<String, dynamic> readiness;
  final List<Map<String, dynamic>> history;
  final List<ApprovalStudent> students;

  factory ReportApproval.fromJson(Map<String, dynamic> j) => ReportApproval(
        id: asInt(j['id']) ?? 0,
        label: asString(j['label']) ?? '',
        status: asString(j['status']) ?? 'pending',
        statusLabel: asString(j['status_label']) ?? '',
        submittedBy: asString(j['submitted_by']),
        submitNote: asString(j['submit_note']),
        reviewedBy: asString(j['reviewed_by']),
        reviewNote: asString(j['review_note']),
        enforced: asBool(j['enforced']),
        canSubmit: asBool(j['can_submit']),
        canApprove: asBool(j['can_approve']),
        readiness: asMap(j['readiness']),
        history: asMapList(j['history']),
        students: asMapList(j['students'])
            .map((s) => ApprovalStudent(
                  id: asInt(s['id']) ?? 0,
                  name: asString(s['name']) ?? '',
                  entries: asInt(s['entries']) ?? 0,
                  vetted: asInt(s['vetted']) ?? 0,
                  average: asDouble(s['average']),
                  teacherComment: asString(s['teacher_comment']),
                  principalComment: asString(s['principal_comment']),
                ))
            .toList(),
      );
}

/// Push and lesson-reminder settings (GET/PUT /me/preferences).
class NotificationPrefs {
  NotificationPrefs({this.pushEnabled = true, this.lessonReminders = true, this.reminderMinutes = 10, this.pushAvailable = false});

  bool pushEnabled;
  bool lessonReminders;
  int reminderMinutes;
  final bool pushAvailable;

  factory NotificationPrefs.fromJson(Map<String, dynamic> j) => NotificationPrefs(
        pushEnabled: asBool(j['push_enabled'], true),
        lessonReminders: asBool(j['lesson_reminders'], true),
        reminderMinutes: asInt(j['reminder_minutes']) ?? 10,
        pushAvailable: asBool(j['push_available']),
      );
}
