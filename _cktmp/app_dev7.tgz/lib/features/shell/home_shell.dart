import 'package:flutter/material.dart';
import '../../core/theme/app_icons.dart';

import '../admin/admin_dashboard_screen.dart';
import '../admin/approvals_screen.dart';
import '../admin/student_search_screen.dart';
import '../auth/auth_controller.dart';
import '../common/account_screen.dart';
import '../common/calendar_screen.dart';
import '../common/inbox_screen.dart';
import '../parent/parent_home_screen.dart';
import '../results/results_board_screen.dart';
import '../staff/classes_screen.dart';
import '../staff/staff_home_screen.dart';
import '../staff/subjects_screen.dart';
import '../student/student_hub_screen.dart';

class _Tab {
  const _Tab(this.label, this.icon, this.activeIcon, this.builder);
  final String label;
  final IconData icon;
  final IconData activeIcon;
  final Widget Function() builder;
}

/// Bottom navigation, built for the face that is showing
/// (parent, student, staff or admin).
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final Set<int> _opened = {0};

  List<_Tab> _tabsFor(String face) {
    final user = AuthController.to.user.value;
    const account = _Tab('Account', AppIcons.user, AppIcons.userActive, AccountScreen.new);
    switch (face) {
      case 'student':
        return [
          _Tab('Home', AppIcons.home, AppIcons.homeActive, () => StudentHubScreen(studentId: user?.studentId ?? 0, asTab: true)),
          const _Tab('Inbox', AppIcons.inbox, AppIcons.inbox, InboxScreen.new),
          const _Tab('Calendar', AppIcons.calendar, AppIcons.calendar, CalendarScreen.new),
          account,
        ];
      case 'staff':
        return [
          const _Tab('Home', AppIcons.home, AppIcons.homeActive, StaffHomeScreen.new),
          if (user?.can('scores.enter') ?? false) const _Tab('Scores', AppIcons.scores, AppIcons.scores, SubjectsScreen.new),
          if (user?.can('attendance.mark') ?? false) const _Tab('Register', AppIcons.register, AppIcons.register, ClassesScreen.new),
          const _Tab('Inbox', AppIcons.inbox, AppIcons.inbox, InboxScreen.new),
          account,
        ];
      case 'admin':
        final tabs = [
          if (user?.can('management.dashboard') ?? false) const _Tab('Overview', AppIcons.overview, AppIcons.overview, AdminDashboardScreen.new),
          if (user?.can('results.board') ?? false) _Tab('Results', AppIcons.results, AppIcons.results, () => const ResultsBoardScreen(standalone: false)),
          if ((user?.can('leave.approve') ?? false) || (user?.can('student_leave.approve') ?? false))
            const _Tab('Approvals', AppIcons.approvals, AppIcons.approvals, ApprovalsScreen.new),
          if (user?.can('students.view') ?? false) const _Tab('Students', AppIcons.people, AppIcons.people, StudentSearchScreen.new),
          account,
        ];
        return tabs.length > 1 ? tabs : [const _Tab('Inbox', AppIcons.inbox, AppIcons.inbox, InboxScreen.new), account];
      case 'parent':
      default:
        return [
          const _Tab('Home', AppIcons.home, AppIcons.homeActive, ParentHomeScreen.new),
          const _Tab('Inbox', AppIcons.inbox, AppIcons.inbox, InboxScreen.new),
          const _Tab('Calendar', AppIcons.calendar, AppIcons.calendar, CalendarScreen.new),
          account,
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final tabs = _tabsFor(AuthController.to.face.value);
    if (_index >= tabs.length) _index = 0;

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          for (var i = 0; i < tabs.length; i++) _opened.contains(i) ? tabs[i].builder() : const SizedBox.shrink(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() {
          _index = i;
          _opened.add(i);
        }),
        destinations: [
          for (final t in tabs) NavigationDestination(icon: Icon(t.icon), selectedIcon: Icon(t.activeIcon), label: t.label),
        ],
      ),
    );
  }
}
