import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/staff.dart';
import '../../data/repositories/school_repository.dart';
import '../student/period_picker.dart';

/// Mark a class register for one day (and period, if the school tracks
/// afternoons). Backdating limits are enforced by the server.
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key, required this.teacherClass});

  final TeacherClass teacherClass;

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends LoadState<RegisterScreen, AttendanceRegister> {
  DateTime _date = DateTime.now();
  String? _period;
  bool _saving = false;
  bool _dirty = false;

  static const _statuses = ['present', 'absent', 'late', 'excused', 'sick_leave'];
  static String _label(String s) => s == 'sick_leave' ? 'Sick' : '${s[0].toUpperCase()}${s.substring(1)}';

  @override
  Future<AttendanceRegister> fetch() =>
      StaffRepository.register(widget.teacherClass, date: Fmt.apiDate(_date), period: _period);

  Future<void> _pickDate() async {
    final r = data;
    final now = DateTime.now();
    final first = r?.termStart ?? now.subtract(const Duration(days: 120));
    final picked = await showDatePicker(
      context: context,
      initialDate: _date.isAfter(now) ? now : _date,
      firstDate: first.isAfter(now) ? now : first,
      lastDate: now,
      selectableDayPredicate: (d) => d.weekday != DateTime.saturday && d.weekday != DateTime.sunday,
    );
    if (picked == null) return;
    if (_dirty && !await confirmDialog('Unsaved register', 'Discard the changes on this day?', confirm: 'Discard', danger: true)) return;
    _date = picked;
    _dirty = false;
    load();
  }

  void _set(RegisterStudent s, String status) => setState(() {
        s.status = status;
        _dirty = true;
      });

  void _allPresent() => setState(() {
        for (final s in data?.students ?? <RegisterStudent>[]) {
          s.status ??= 'present';
        }
        _dirty = true;
      });

  Future<void> _save() async {
    final r = data;
    if (r == null) return;
    final missing = r.students.where((s) => s.status == null).length;
    if (missing > 0 &&
        !await confirmDialog('Some students not marked', '$missing student(s) have no mark. Save the others anyway?', confirm: 'Save')) {
      return;
    }
    setState(() => _saving = true);
    try {
      final msg = await StaffRepository.saveRegister(r);
      _dirty = false;
      Toast.success(msg);
      reload();
    } catch (e) {
      Toast.error(e);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = data;
    final marked = r?.students.where((s) => s.status != null).length ?? 0;
    final present = r?.students.where((s) => s.status == 'present' || s.status == 'late').length ?? 0;

    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final nav = Navigator.of(context);
        if (await confirmDialog('Unsaved register', 'Leave without saving the register?', confirm: 'Leave', danger: true)) {
          _dirty = false;
          nav.pop();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.teacherClass.className, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              Text(widget.teacherClass.term ?? '', style: TextStyle(fontSize: 12.5, color: Colors.white.withValues(alpha: 0.8))),
            ],
          ),
          actions: [
            if (r != null && r.editable && !r.isHoliday)
              TextButton(onPressed: _allPresent, child: const Text('All present', style: TextStyle(color: Colors.white))),
          ],
        ),
        bottomNavigationBar: (r != null && r.editable && !r.isHoliday)
            ? SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: BusyButton(label: 'Save register ($marked/${r.students.length})', busy: _saving, icon: AppIcons.save, onPressed: _save),
                ),
              )
            : null,
        body: AsyncBody(
          loading: loading,
          error: error,
          onRetry: load,
          child: r == null
              ? const SizedBox()
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _pickDate,
                            icon: const Icon(AppIcons.calendar),
                            label: Text(Fmt.dayDate(DateTime.tryParse(r.date))),
                          ),
                        ),
                        if (r.periods.length > 1) ...[
                          const SizedBox(width: 10),
                          Expanded(
                            child: ChoiceRow<String>(
                              items: r.periods,
                              selected: r.period,
                              label: (p) => '${p[0].toUpperCase()}${p.substring(1)}',
                              onSelected: (p) {
                                _period = p;
                                load();
                              },
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 10),
                    if (r.isHoliday)
                      const AppCard(child: Text('This day is a school holiday. No register is needed.')),
                    if (!r.editable && r.note != null)
                      AppCard(
                        color: AppColors.warning.withValues(alpha: 0.08),
                        child: Text(r.note!),
                      ),
                    if (!r.isHoliday) ...[
                      Text('$present present · $marked of ${r.students.length} marked',
                          style: const TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 10),
                      for (final s in r.students) ...[
                        _StudentMark(student: s, enabled: r.editable, statuses: _statuses, label: _label, onSet: (v) => _set(s, v)),
                        const SizedBox(height: 8),
                      ],
                    ],
                  ],
                ),
        ),
      ),
    );
  }
}

class _StudentMark extends StatelessWidget {
  const _StudentMark({required this.student, required this.enabled, required this.statuses, required this.label, required this.onSet});

  final RegisterStudent student;
  final bool enabled;
  final List<String> statuses;
  final String Function(String) label;
  final ValueChanged<String> onSet;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              PersonAvatar(name: student.name, url: student.photoUrl, size: 36),
              const SizedBox(width: 10),
              Expanded(child: Text(student.name, style: const TextStyle(fontWeight: FontWeight.w700))),
              if (student.termRate != null)
                Text(Fmt.percent(student.termRate), style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final st in statuses)
                ChoiceChip(
                  label: Text(label(st)),
                  selected: student.status == st,
                  showCheckmark: false,
                  visualDensity: VisualDensity.compact,
                  selectedColor: AppColors.attendance(st),
                  labelStyle: TextStyle(
                    color: student.status == st ? Colors.white : AppColors.text,
                    fontWeight: FontWeight.w600,
                    fontSize: 12.5,
                  ),
                  onSelected: enabled ? (_) => onSet(st) : null,
                ),
            ],
          ),
        ],
      ),
    );
  }
}
