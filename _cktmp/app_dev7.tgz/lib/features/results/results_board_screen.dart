import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/results_admin.dart';
import '../../data/models/user.dart';
import '../../data/repositories/school_repository.dart';
import '../student/period_picker.dart';
import 'class_results_screen.dart';

/// Every class with results this term — how far vetting has got and where
/// the report cards are in the approval process. Class teachers see their
/// own classes; the principal sees all of them.
class ResultsBoardScreen extends StatefulWidget {
  const ResultsBoardScreen({super.key, this.standalone = true});

  final bool standalone;

  @override
  State<ResultsBoardScreen> createState() => _ResultsBoardScreenState();
}

class _ResultsBoardScreenState extends LoadState<ResultsBoardScreen, ResultsBoard> {
  int? _termId;
  int? _sessionId;
  String _status = 'all';

  static const _filters = ['all', 'pending', 'submitted', 'returned', 'approved'];
  static const _filterLabels = {'all': 'All', 'pending': 'Not submitted', 'submitted': 'Awaiting', 'returned': 'Returned', 'approved': 'Approved'};

  @override
  Future<ResultsBoard> fetch() => ResultsRepository.board(termId: _termId, sessionId: _sessionId);

  Color _statusColor(String s) => switch (s) {
        'approved' => AppColors.success,
        'submitted' => AppColors.warning,
        'returned' => AppColors.danger,
        _ => AppColors.textMuted,
      };

  Future<void> _approveAll(ResultsBoard b) async {
    final waiting = b.classes.where((c) => c.status == 'submitted').length;
    if (waiting == 0) {
      Toast.info('No class is waiting for approval.');
      return;
    }
    if (!await confirmDialog('Approve all?', 'Approve the report cards of all $waiting submitted class(es)?', confirm: 'Approve all')) return;
    try {
      Toast.success(await ResultsRepository.approveAll(termId: b.termId, sessionId: b.sessionId));
      reload();
    } catch (e) {
      Toast.error(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = data;
    final list = (b?.classes ?? const <BoardClass>[]).where((c) => _status == 'all' || c.status == _status).toList();

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: widget.standalone,
        title: const Text('Results & report cards'),
        actions: [
          if (b != null && b.canApprove)
            IconButton(tooltip: 'Approve all submitted', onPressed: () => _approveAll(b), icon: const Icon(AppIcons.approvals)),
        ],
      ),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        child: b == null
            ? const SizedBox()
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  SessionTermPicker(
                    sessions: b.sessions,
                    terms: b.terms,
                    sessionId: b.sessionId,
                    termId: b.termId,
                    onChanged: (s, t) {
                      _sessionId = s;
                      _termId = t;
                      reload();
                    },
                  ),
                  const SizedBox(height: 8),
                  ChoiceRow<String>(
                    items: _filters,
                    selected: _status,
                    label: (f) {
                      final n = f == 'all' ? b.classes.length : b.classes.where((c) => c.status == f).length;
                      return '${_filterLabels[f]} ($n)';
                    },
                    onSelected: (f) => setState(() => _status = f),
                  ),
                  if (b.enforced)
                    const Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: Text('Students and parents only see a class\'s results after its report cards are approved.',
                          style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                    ),
                  const SizedBox(height: 12),
                  if (list.isEmpty)
                    const EmptyState(
                      icon: AppIcons.results,
                      title: 'No classes here',
                      message: 'Classes appear once scores have been entered for this term.',
                    ),
                  for (final c in list) ...[
                    AppCard(
                      onTap: () async {
                        await Get.to(() => ClassResultsScreen(
                              classId: c.classId,
                              className: c.className,
                              termId: b.termId,
                              sessionId: b.sessionId,
                              term: _name(b.terms, b.termId),
                            ));
                        reload();
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(child: Text(c.className, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                              StatusPill(c.statusLabel, color: _statusColor(c.status)),
                            ],
                          ),
                          if (c.teacher != null)
                            Text(c.teacher!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                          const SizedBox(height: 10),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: LinearProgressIndicator(
                              value: c.vettedPct / 100,
                              minHeight: 6,
                              backgroundColor: AppColors.background,
                              color: c.ready ? AppColors.success : AppColors.blue,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '${c.students} students · ${c.subjects} subjects · ${c.vettedPct}% vetted · ${c.teacherComments}/${c.students} comments',
                            style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                ],
              ),
      ),
    );
  }

  String? _name(List<IdName> l, int id) {
    for (final x in l) {
      if (x.id == id) return x.name;
    }
    return null;
  }
}
