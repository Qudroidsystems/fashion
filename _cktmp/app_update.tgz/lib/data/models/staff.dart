import '../../core/utils/json.dart';
import 'user.dart';

/// One subject × class × term a teacher is assigned to (GET /staff/subjects).
class SubjectAssignment {
  SubjectAssignment({
    this.subjectclassId,
    required this.subject,
    this.subjectCode,
    this.classId,
    this.className,
    required this.termId,
    this.term,
    required this.sessionId,
    this.session,
    this.students = 0,
    this.entered = 0,
    this.progress = 0,
    this.status = '',
  });

  final int? subjectclassId;
  final String subject;
  final String? subjectCode;
  final int? classId;
  final String? className;
  final int termId;
  final String? term;
  final int sessionId;
  final String? session;
  final int students;
  final int entered;
  final int progress;
  final String status;

  bool get canOpen => subjectclassId != null;

  factory SubjectAssignment.fromJson(Map<String, dynamic> j) => SubjectAssignment(
        subjectclassId: asInt(j['subjectclass_id']),
        subject: asString(j['subject']) ?? '',
        subjectCode: asString(j['subject_code']),
        classId: asInt(j['class_id']),
        className: asString(j['class_name']),
        termId: asInt(j['term_id']) ?? 0,
        term: asString(j['term']),
        sessionId: asInt(j['session_id']) ?? 0,
        session: asString(j['session']),
        students: asInt(j['students']) ?? 0,
        entered: asInt(j['entered']) ?? 0,
        progress: asInt(j['progress']) ?? 0,
        status: asString(j['status']) ?? '',
      );
}

class Assessment {
  Assessment(this.id, this.name, this.maxScore, this.subs);
  final int id;
  final String name;
  final double maxScore;
  final List<Assessment> subs;

  bool get hasSubs => subs.isNotEmpty;

  factory Assessment.fromJson(Map<String, dynamic> j) => Assessment(
        asInt(j['id']) ?? 0,
        asString(j['name']) ?? '',
        asDouble(j['max_score']) ?? 0,
        asMapList(j['sub_assessments']).map(Assessment.fromJson).toList(),
      );
}

class ScoreRow {
  ScoreRow({
    required this.broadsheetId,
    required this.studentId,
    this.admissionNo,
    required this.name,
    this.photoUrl,
    required this.scores,
    required this.subScores,
    this.total,
    this.grade,
    this.position,
    this.locked = false,
  });

  final int broadsheetId;
  final int studentId;
  final String? admissionNo;
  final String name;
  final String? photoUrl;

  /// assessment id → score (null = not entered).
  final Map<int, double?> scores;

  /// sub-assessment id → score.
  final Map<int, double?> subScores;
  double? total;
  String? grade;
  String? position;
  final bool locked;

  factory ScoreRow.fromJson(Map<String, dynamic> j) {
    Map<int, double?> m(dynamic v) => asMap(v).map((k, val) => MapEntry(int.tryParse(k) ?? 0, asDouble(val)));
    final name = [asString(j['last_name']), asString(j['first_name']), asString(j['other_name'])].whereType<String>().join(' ');
    return ScoreRow(
      broadsheetId: asInt(j['broadsheet_id']) ?? 0,
      studentId: asInt(j['student_id']) ?? 0,
      admissionNo: asString(j['admission_no']),
      name: name.isEmpty ? 'Student' : name,
      photoUrl: asString(j['photo_url']),
      scores: m(j['scores']),
      subScores: m(j['sub_scores']),
      total: asDouble(j['total']),
      grade: asString(j['grade']),
      position: asString(j['position']),
      locked: asBool(j['locked']),
    );
  }
}

class Scoresheet {
  Scoresheet({
    required this.subjectclassId,
    required this.subject,
    this.className,
    required this.termId,
    this.term,
    required this.sessionId,
    this.session,
    this.editable = true,
    this.lockMessage,
    this.assessments = const [],
    this.rows = const [],
  });

  final int subjectclassId;
  final String subject;
  final String? className;
  final int termId;
  final String? term;
  final int sessionId;
  final String? session;
  final bool editable;
  final String? lockMessage;
  final List<Assessment> assessments;
  final List<ScoreRow> rows;

  factory Scoresheet.fromJson(Map<String, dynamic> j) => Scoresheet(
        subjectclassId: asInt(j['subjectclass_id']) ?? 0,
        subject: asString(j['subject']) ?? '',
        className: asString(j['class_name']),
        termId: asInt(j['term_id']) ?? 0,
        term: asString(j['term']),
        sessionId: asInt(j['session_id']) ?? 0,
        session: asString(j['session']),
        editable: asBool(j['editable'], true),
        lockMessage: asString(j['lock_message']),
        assessments: asMapList(j['assessments']).map(Assessment.fromJson).toList(),
        rows: asMapList(j['students']).map(ScoreRow.fromJson).toList(),
      );
}

/// A class this user is class teacher of (GET /staff/classes).
class TeacherClass {
  TeacherClass({required this.classId, required this.className, required this.termId, this.term, required this.sessionId, this.session, this.students = 0, this.isCurrentTerm = false});

  final int classId;
  final String className;
  final int termId;
  final String? term;
  final int sessionId;
  final String? session;
  final int students;
  final bool isCurrentTerm;

  factory TeacherClass.fromJson(Map<String, dynamic> j) => TeacherClass(
        classId: asInt(j['class_id']) ?? 0,
        className: asString(j['class_name']) ?? '',
        termId: asInt(j['term_id']) ?? 0,
        term: asString(j['term']),
        sessionId: asInt(j['session_id']) ?? 0,
        session: asString(j['session']),
        students: asInt(j['students']) ?? 0,
        isCurrentTerm: asBool(j['is_current_term']),
      );
}

class RegisterStudent {
  RegisterStudent({required this.id, required this.name, this.admissionNo, this.photoUrl, this.status, this.termRate});

  final int id;
  final String name;
  final String? admissionNo;
  final String? photoUrl;
  String? status;
  final double? termRate;

  factory RegisterStudent.fromJson(Map<String, dynamic> j) {
    final name = [asString(j['last_name']), asString(j['first_name']), asString(j['other_name'])].whereType<String>().join(' ');
    return RegisterStudent(
      id: asInt(j['id']) ?? 0,
      name: name,
      admissionNo: asString(j['admission_no']),
      photoUrl: asString(j['photo_url']),
      status: asString(j['status']),
      termRate: asDouble(j['term_rate']),
    );
  }
}

class AttendanceRegister {
  AttendanceRegister({
    required this.classId,
    required this.termId,
    required this.sessionId,
    required this.date,
    required this.period,
    this.periods = const ['morning'],
    this.isHoliday = false,
    this.editable = true,
    this.note,
    this.termStart,
    this.termEnd,
    this.students = const [],
  });

  final int classId;
  final int termId;
  final int sessionId;
  final String date;
  final String period;
  final List<String> periods;
  final bool isHoliday;
  final bool editable;
  final String? note;
  final DateTime? termStart;
  final DateTime? termEnd;
  final List<RegisterStudent> students;

  factory AttendanceRegister.fromJson(Map<String, dynamic> j) => AttendanceRegister(
        classId: asInt(j['class_id']) ?? 0,
        termId: asInt(j['term_id']) ?? 0,
        sessionId: asInt(j['session_id']) ?? 0,
        date: asString(j['date']) ?? '',
        period: asString(j['period']) ?? 'morning',
        periods: asStringList(j['periods']),
        isHoliday: asBool(j['is_holiday']),
        editable: asBool(j['editable'], true),
        note: asString(j['note']),
        termStart: asDate(j['term_start']),
        termEnd: asDate(j['term_end']),
        students: asMapList(j['students']).map(RegisterStudent.fromJson).toList(),
      );
}

class LeaveBalance {
  LeaveBalance({required this.typeId, required this.name, this.remaining, this.entitled = 0, this.limited = false, this.requiresDocument = false});

  final int typeId;
  final String name;
  final double? remaining;
  final double entitled;
  final bool limited;
  final bool requiresDocument;

  factory LeaveBalance.fromJson(Map<String, dynamic> j) => LeaveBalance(
        typeId: asInt(j['leave_type_id']) ?? 0,
        name: asString(j['name']) ?? '',
        remaining: asDouble(j['remaining']),
        entitled: asDouble(j['entitled']) ?? 0,
        limited: asBool(j['limited']),
        requiresDocument: asBool(j['requires_document']),
      );
}

class StaffLeave {
  StaffLeave({required this.id, this.type, this.startDate, this.endDate, this.days = 0, this.reason, this.status = '', this.statusLabel = '', this.note, this.staffName, this.department, this.stage, this.remaining});

  final int id;
  final String? type;
  final String? startDate;
  final String? endDate;
  final double days;
  final String? reason;
  final String status;
  final String statusLabel;
  final String? note;
  final String? staffName;
  final String? department;
  final String? stage;
  final double? remaining;

  bool get isOpen => status == 'pending_hod' || status == 'pending_principal';

  factory StaffLeave.fromJson(Map<String, dynamic> j) => StaffLeave(
        id: asInt(j['id']) ?? 0,
        type: asString(j['type']),
        startDate: asString(j['start_date']),
        endDate: asString(j['end_date']),
        days: asDouble(j['days']) ?? 0,
        reason: asString(j['reason']),
        status: asString(j['status']) ?? '',
        statusLabel: asString(j['status_label']) ?? '',
        note: asString(j['approver_note']) ?? asString(j['hod_note']),
        staffName: asString(j['staff_name']),
        department: asString(j['department']),
        stage: asString(j['stage']),
        remaining: asDouble(j['remaining']),
      );
}

class Payslip {
  Payslip({required this.id, this.period, this.paymentDate, this.gross = 0, this.deductions = 0, this.net = 0, this.pdfUrl, this.lines = const []});

  final int id;
  final String? period;
  final String? paymentDate;
  final double gross;
  final double deductions;
  final double net;
  final String? pdfUrl;
  final List<Map<String, dynamic>> lines;

  factory Payslip.fromJson(Map<String, dynamic> j) => Payslip(
        id: asInt(j['id']) ?? 0,
        period: asString(j['period']),
        paymentDate: asString(j['payment_date']),
        gross: asDouble(j['gross']) ?? 0,
        deductions: asDouble(j['deductions']) ?? 0,
        net: asDouble(j['net']) ?? 0,
        pdfUrl: asString(j['pdf_url']),
        lines: asMapList(j['lines']),
      );
}

class Lesson {
  Lesson({this.period, this.start, this.end, this.subject, this.className, this.room});

  final String? period;
  final String? start;
  final String? end;
  final String? subject;
  final String? className;
  final String? room;

  factory Lesson.fromJson(Map<String, dynamic> j) => Lesson(
        period: asString(j['period']),
        start: asString(j['start_time']),
        end: asString(j['end_time']),
        subject: asString(j['subject']),
        className: asString(j['class_name']),
        room: asString(j['room']),
      );
}


/// A session the teacher had subjects in, with its terms (history picker).
class TeachingPeriod {
  TeachingPeriod({required this.sessionId, required this.session, required this.current, required this.terms});

  final int sessionId;
  final String session;
  final bool current;
  final List<IdName> terms;

  factory TeachingPeriod.fromJson(Map<String, dynamic> j) => TeachingPeriod(
        sessionId: asInt(j['session_id']) ?? 0,
        session: asString(j['session']) ?? '',
        current: asBool(j['current']),
        terms: asMapList(j['terms']).map((t) => IdName(asInt(t['id']) ?? 0, asString(t['name']) ?? '')).toList(),
      );
}
