import '../../core/utils/json.dart';

/// A teacher a parent can reach (form teacher or subject teacher).
class TeacherContact {
  TeacherContact({required this.id, required this.name, this.jobTitle, this.photoUrl, this.email, this.phone, this.subjects = const []});

  final int id;
  final String name;
  final String? jobTitle;
  final String? photoUrl;
  final String? email;
  final String? phone;
  final List<String> subjects;

  factory TeacherContact.fromJson(Map<String, dynamic> j) => TeacherContact(
        id: asInt(j['id']) ?? 0,
        name: asString(j['name']) ?? '',
        jobTitle: asString(j['job_title']),
        photoUrl: asString(j['photo_url']),
        email: asString(j['email']),
        phone: asString(j['phone']),
        subjects: asStringList(j['subjects']),
      );
}

class TeachersPage {
  TeachersPage({this.className, required this.classTeachers, required this.subjectTeachers});

  final String? className;
  final List<TeacherContact> classTeachers;
  final List<TeacherContact> subjectTeachers;

  factory TeachersPage.fromJson(Map<String, dynamic> j) => TeachersPage(
        className: asString(j['class_name']),
        classTeachers: asMapList(j['class_teachers']).map(TeacherContact.fromJson).toList(),
        subjectTeachers: asMapList(j['subject_teachers']).map(TeacherContact.fromJson).toList(),
      );
}

class PerformanceTerm {
  PerformanceTerm({
    required this.sessionId,
    required this.termId,
    required this.label,
    required this.term,
    required this.session,
    this.className,
    this.average,
    this.classAverage,
    this.bestSubject,
    this.bestScore,
    this.grades = const {},
  });

  final int sessionId;
  final int termId;
  final String label;
  final String term;
  final String session;
  final String? className;
  final double? average;
  final double? classAverage;
  final String? bestSubject;
  final double? bestScore;
  final Map<String, int> grades;

  factory PerformanceTerm.fromJson(Map<String, dynamic> j) {
    final best = asMap(j['best']);
    return PerformanceTerm(
      sessionId: asInt(j['session_id']) ?? 0,
      termId: asInt(j['term_id']) ?? 0,
      label: asString(j['label']) ?? '',
      term: asString(j['term']) ?? '',
      session: asString(j['session']) ?? '',
      className: asString(j['class_name']),
      average: asDouble(j['average']),
      classAverage: asDouble(j['class_average']),
      bestSubject: asString(best['subject']),
      bestScore: asDouble(best['score']),
      grades: asMap(j['grades']).map((k, v) => MapEntry(k, asInt(v) ?? 0)),
    );
  }
}

class SubjectTrend {
  SubjectTrend({required this.subject, required this.scores, this.latest, this.average, this.trend});

  final String subject;

  /// One entry per term in [PerformancePage.terms] (null when not taken).
  final List<double?> scores;
  final double? latest;
  final double? average;

  /// Change from the previous term (points).
  final double? trend;

  factory SubjectTrend.fromJson(Map<String, dynamic> j) => SubjectTrend(
        subject: asString(j['subject']) ?? '',
        scores: (j['scores'] is List ? j['scores'] as List : const []).map(asDouble).toList(),
        latest: asDouble(j['latest']),
        average: asDouble(j['average']),
        trend: asDouble(j['trend']),
      );
}

class PerformancePage {
  PerformancePage({
    required this.terms,
    required this.subjects,
    this.latestAverage,
    this.change,
    this.bestAverage,
    this.strongest,
    this.needsAttention,
    this.hiddenTerms = 0,
  });

  final List<PerformanceTerm> terms;
  final List<SubjectTrend> subjects;
  final double? latestAverage;
  final double? change;
  final double? bestAverage;
  final String? strongest;
  final String? needsAttention;
  final int hiddenTerms;

  factory PerformancePage.fromJson(Map<String, dynamic> j) {
    final s = asMap(j['summary']);
    return PerformancePage(
      terms: asMapList(j['terms']).map(PerformanceTerm.fromJson).toList(),
      subjects: asMapList(j['subjects']).map(SubjectTrend.fromJson).toList(),
      latestAverage: asDouble(s['latest_average']),
      change: asDouble(s['change']),
      bestAverage: asDouble(s['best_average']),
      strongest: asString(s['strongest']),
      needsAttention: asString(s['needs_attention']),
      hiddenTerms: asInt(s['hidden_terms']) ?? 0,
    );
  }
}

class LmsCourseInfo {
  LmsCourseInfo({required this.id, required this.title, this.code, this.teacher, this.progress = 0, this.quizAverage, this.pending = 0});

  final int id;
  final String title;
  final String? code;
  final String? teacher;
  final int progress;
  final double? quizAverage;
  final int pending;

  factory LmsCourseInfo.fromJson(Map<String, dynamic> j) => LmsCourseInfo(
        id: asInt(j['id']) ?? 0,
        title: asString(j['title']) ?? '',
        code: asString(j['code']),
        teacher: asString(j['teacher']),
        progress: asInt(j['progress']) ?? 0,
        quizAverage: asDouble(j['quiz_average']),
        pending: asInt(j['pending']) ?? 0,
      );
}

class Homework {
  Homework({
    required this.id,
    required this.title,
    required this.course,
    required this.state,
    this.instructions,
    this.dueAt,
    this.maxScore,
    this.score,
    this.feedback,
  });

  final int id;
  final String title;
  final String course;

  /// pending | overdue | submitted | graded
  final String state;
  final String? instructions;
  final DateTime? dueAt;
  final double? maxScore;
  final double? score;
  final String? feedback;

  factory Homework.fromJson(Map<String, dynamic> j) => Homework(
        id: asInt(j['id']) ?? 0,
        title: asString(j['title']) ?? '',
        course: asString(j['course']) ?? '',
        state: asString(j['state']) ?? 'pending',
        instructions: asString(j['instructions']),
        dueAt: DateTime.tryParse(asString(j['due_at']) ?? '')?.toLocal(),
        maxScore: asDouble(j['max_score']),
        score: asDouble(j['score']),
        feedback: asString(j['feedback']),
      );
}

class LearningPage {
  LearningPage({required this.courses, required this.homework, this.due = 0, this.overdue = 0, this.graded = 0});

  final List<LmsCourseInfo> courses;
  final List<Homework> homework;
  final int due;
  final int overdue;
  final int graded;

  factory LearningPage.fromJson(Map<String, dynamic> j) {
    final s = asMap(j['summary']);
    return LearningPage(
      courses: asMapList(j['courses']).map(LmsCourseInfo.fromJson).toList(),
      homework: asMapList(j['assignments']).map(Homework.fromJson).toList(),
      due: asInt(s['due']) ?? 0,
      overdue: asInt(s['overdue']) ?? 0,
      graded: asInt(s['graded']) ?? 0,
    );
  }
}
