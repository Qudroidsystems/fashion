import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// One line on a [TrendChart].
class ChartSeries {
  const ChartSeries(this.label, this.values, this.color, {this.dashed = false});
  final String label;
  final List<double?> values;
  final Color color;
  final bool dashed;
}

/// A small animated line chart (0–100 scale) with labels along the bottom.
class TrendChart extends StatelessWidget {
  const TrendChart({super.key, required this.labels, required this.series, this.height = 190, this.maxY = 100});

  final List<String> labels;
  final List<ChartSeries> series;
  final double height;
  final double maxY;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: height,
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 1100),
            curve: Curves.easeOutCubic,
            builder: (_, t, __) => CustomPaint(
              size: Size.infinite,
              painter: _TrendPainter(labels: labels, series: series, progress: t, maxY: maxY),
            ),
          ),
        ),
        if (series.length > 1) ...[
          const SizedBox(height: 8),
          Wrap(
            spacing: 14,
            children: [
              for (final s in series)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 14, height: 3, color: s.color),
                    const SizedBox(width: 6),
                    Text(s.label, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                  ],
                ),
            ],
          ),
        ],
      ],
    );
  }
}

class _TrendPainter extends CustomPainter {
  _TrendPainter({required this.labels, required this.series, required this.progress, required this.maxY});

  final List<String> labels;
  final List<ChartSeries> series;
  final double progress;
  final double maxY;

  @override
  void paint(Canvas canvas, Size size) {
    const left = 28.0, bottom = 22.0, top = 10.0, right = 10.0;
    final w = size.width - left - right;
    final h = size.height - top - bottom;
    final grid = Paint()
      ..color = AppColors.border
      ..strokeWidth = 1;
    final tp = TextPainter(textDirection: TextDirection.ltr);

    for (var i = 0; i <= 4; i++) {
      final y = top + h - h * i / 4;
      canvas.drawLine(Offset(left, y), Offset(left + w, y), grid);
      tp.text = TextSpan(text: (maxY * i / 4).round().toString(), style: const TextStyle(fontSize: 10, color: AppColors.textMuted));
      tp.layout();
      tp.paint(canvas, Offset(left - tp.width - 6, y - tp.height / 2));
    }

    final n = labels.length;
    double xAt(int i) => n <= 1 ? left + w / 2 : left + w * i / (n - 1);
    double yAt(double v) => top + h - h * (v.clamp(0, maxY) / maxY) * progress;

    final step = n <= 6 ? 1 : (n / 6).ceil();
    for (var i = 0; i < n; i += step) {
      tp.text = TextSpan(text: labels[i], style: const TextStyle(fontSize: 10, color: AppColors.textMuted));
      tp.layout(maxWidth: 64);
      tp.paint(canvas, Offset(xAt(i) - tp.width / 2, size.height - bottom + 6));
    }

    for (final s in series) {
      final pts = <Offset>[];
      for (var i = 0; i < math.min(n, s.values.length); i++) {
        final v = s.values[i];
        if (v != null) pts.add(Offset(xAt(i), yAt(v)));
      }
      if (pts.isEmpty) continue;

      final line = Paint()
        ..color = s.color
        ..strokeWidth = s.dashed ? 2 : 3
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;

      final path = Path()..moveTo(pts.first.dx, pts.first.dy);
      for (var i = 1; i < pts.length; i++) {
        final a = pts[i - 1], b = pts[i];
        final mx = (a.dx + b.dx) / 2;
        path.cubicTo(mx, a.dy, mx, b.dy, b.dx, b.dy);
      }

      if (!s.dashed && pts.length > 1) {
        final fill = Path.from(path)
          ..lineTo(pts.last.dx, top + h)
          ..lineTo(pts.first.dx, top + h)
          ..close();
        canvas.drawPath(
          fill,
          Paint()
            ..shader = LinearGradient(
              colors: [s.color.withValues(alpha: 0.25), s.color.withValues(alpha: 0.0)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ).createShader(Rect.fromLTWH(0, top, size.width, h)),
        );
      }

      if (s.dashed) {
        for (final metric in path.computeMetrics()) {
          var d = 0.0;
          while (d < metric.length) {
            canvas.drawPath(metric.extractPath(d, math.min(d + 6, metric.length)), line);
            d += 11;
          }
        }
      } else {
        canvas.drawPath(path, line);
      }

      for (final p in pts) {
        canvas.drawCircle(p, s.dashed ? 2.5 : 4.5, Paint()..color = Colors.white);
        canvas.drawCircle(p, s.dashed ? 2.5 : 4.5, line..strokeWidth = 2);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _TrendPainter old) => old.progress != progress || old.series != series || old.labels != labels;
}

/// Tiny inline trend line for list rows.
class Sparkline extends StatelessWidget {
  const Sparkline({super.key, required this.values, this.color = AppColors.blue, this.width = 64, this.height = 24});

  final List<double?> values;
  final Color color;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) =>
      SizedBox(width: width, height: height, child: CustomPaint(painter: _SparkPainter(values.whereType<double>().toList(), color)));
}

class _SparkPainter extends CustomPainter {
  _SparkPainter(this.v, this.color);
  final List<double> v;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    if (v.isEmpty) return;
    final lo = v.reduce(math.min), hi = v.reduce(math.max);
    final span = (hi - lo).abs() < 1 ? 1 : hi - lo;
    Offset at(int i) => Offset(
          v.length == 1 ? size.width / 2 : size.width * i / (v.length - 1),
          size.height - 3 - (size.height - 6) * ((v[i] - lo) / span),
        );
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()..moveTo(at(0).dx, at(0).dy);
    for (var i = 1; i < v.length; i++) {
      path.lineTo(at(i).dx, at(i).dy);
    }
    canvas.drawPath(path, paint);
    canvas.drawCircle(at(v.length - 1), 3, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _SparkPainter old) => old.v != v || old.color != color;
}

/// Animated ring showing a percentage.
class ProgressRing extends StatelessWidget {
  const ProgressRing({super.key, required this.value, this.size = 70, this.color = AppColors.blue, this.label});

  /// 0..1
  final double value;
  final double size;
  final Color color;
  final String? label;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: value.isNaN ? 0.0 : value.clamp(0.0, 1.0).toDouble()),
      duration: const Duration(milliseconds: 1000),
      curve: Curves.easeOutCubic,
      builder: (_, v, __) => SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: size,
              height: size,
              child: CircularProgressIndicator(
                value: v,
                strokeWidth: size * 0.1,
                backgroundColor: color.withValues(alpha: 0.12),
                color: color,
                strokeCap: StrokeCap.round,
              ),
            ),
            Text(label ?? '${(v * 100).round()}%', style: TextStyle(fontWeight: FontWeight.w900, color: color, fontSize: size * 0.22)),
          ],
        ),
      ),
    );
  }
}
