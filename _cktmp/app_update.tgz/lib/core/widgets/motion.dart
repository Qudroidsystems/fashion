import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_colors.dart';

/// Fades and slides its child in once, after an optional delay.
/// Use [FadeSlideIn.staggered] to animate a list of widgets one after another.
class FadeSlideIn extends StatefulWidget {
  const FadeSlideIn({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 420),
    this.offset = const Offset(0, 0.08),
  });

  final Widget child;
  final Duration delay;
  final Duration duration;
  final Offset offset;

  /// Wraps each widget with an increasing delay (capped so long lists don't lag).
  static List<Widget> staggered(List<Widget> children, {int stepMs = 55, int startMs = 0, int maxSteps = 12}) {
    return [
      for (var i = 0; i < children.length; i++)
        FadeSlideIn(
          delay: Duration(milliseconds: startMs + stepMs * (i < maxSteps ? i : maxSteps)),
          child: children[i],
        ),
    ];
  }

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: widget.duration);
  late final Animation<double> _curve = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);

  @override
  void initState() {
    super.initState();
    if (widget.delay == Duration.zero) {
      _c.forward();
    } else {
      Future.delayed(widget.delay, () {
        if (mounted) _c.forward();
      });
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _curve,
      child: SlideTransition(
        position: Tween<Offset>(begin: widget.offset, end: Offset.zero).animate(_curve),
        child: widget.child,
      ),
    );
  }
}

/// Shrinks slightly while pressed — gives taps a physical feel.
class PressScale extends StatefulWidget {
  const PressScale({super.key, required this.child, this.onTap, this.scale = 0.96, this.haptic = true});

  final Widget child;
  final VoidCallback? onTap;
  final double scale;
  final bool haptic;

  @override
  State<PressScale> createState() => _PressScaleState();
}

class _PressScaleState extends State<PressScale> {
  bool _down = false;

  void _set(bool v) {
    if (_down != v && mounted) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    if (widget.onTap == null) return widget.child;
    return Listener(
      onPointerDown: (_) => _set(true),
      onPointerUp: (_) => _set(false),
      onPointerCancel: (_) => _set(false),
      child: AnimatedScale(
        scale: _down ? widget.scale : 1,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            if (widget.haptic) HapticFeedback.selectionClick();
            widget.onTap!();
          },
          child: widget.child,
        ),
      ),
    );
  }
}

/// Scales down while a pointer is on it but leaves tap handling to the child
/// (so InkWell ripples still work).
class PressDown extends StatefulWidget {
  const PressDown({super.key, required this.child, this.scale = 0.975});
  final Widget child;
  final double scale;

  @override
  State<PressDown> createState() => _PressDownState();
}

class _PressDownState extends State<PressDown> {
  bool _down = false;

  void _set(bool v) {
    if (_down != v && mounted) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _set(true),
      onPointerUp: (_) => _set(false),
      onPointerCancel: (_) => _set(false),
      child: AnimatedScale(scale: _down ? widget.scale : 1, duration: const Duration(milliseconds: 120), child: widget.child),
    );
  }
}

/// Counts up to a number the first time it shows (e.g. "78%" or "₦12,500").
/// Text that doesn't contain a number is shown as is.
class CountUpText extends StatelessWidget {
  const CountUpText(this.text, {super.key, this.style, this.duration = const Duration(milliseconds: 900)});

  final String text;
  final TextStyle? style;
  final Duration duration;

  static final _num = RegExp(r'-?\d[\d,]*(\.\d+)?');

  @override
  Widget build(BuildContext context) {
    final m = _num.firstMatch(text);
    if (m == null) return Text(text, style: style);
    final raw = m.group(0)!;
    final target = double.tryParse(raw.replaceAll(',', ''));
    if (target == null) return Text(text, style: style);
    final decimals = m.group(1) == null ? 0 : m.group(1)!.length - 1;
    final grouped = raw.contains(',');
    final prefix = text.substring(0, m.start);
    final suffix = text.substring(m.end);

    return TweenAnimationBuilder<double>(
      key: ValueKey(text),
      tween: Tween(begin: 0, end: target),
      duration: duration,
      curve: Curves.easeOutCubic,
      builder: (_, v, __) => Text('$prefix${_format(v, decimals, grouped)}$suffix', style: style),
    );
  }

  static String _format(double v, int decimals, bool grouped) {
    var s = v.toStringAsFixed(decimals);
    if (!grouped) return s;
    final parts = s.split('.');
    final neg = parts[0].startsWith('-');
    final digits = neg ? parts[0].substring(1) : parts[0];
    final b = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) b.write(',');
      b.write(digits[i]);
    }
    s = '${neg ? '-' : ''}$b';
    return parts.length > 1 ? '$s.${parts[1]}' : s;
  }
}

/// A rounded progress bar that fills smoothly.
class AnimatedBar extends StatelessWidget {
  const AnimatedBar({super.key, required this.value, this.color = AppColors.blue, this.height = 8, this.background});

  /// 0..1
  final double value;
  final Color color;
  final double height;
  final Color? background;

  @override
  Widget build(BuildContext context) {
    final v = value.isNaN ? 0.0 : value.clamp(0.0, 1.0).toDouble();
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: Container(
        height: height,
        color: background ?? color.withValues(alpha: 0.12),
        alignment: Alignment.centerLeft,
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: v),
          duration: const Duration(milliseconds: 800),
          curve: Curves.easeOutCubic,
          builder: (_, x, __) => FractionallySizedBox(
            widthFactor: x,
            child: Container(decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(height))),
          ),
        ),
      ),
    );
  }
}

/// One entry in a [MenuGrid].
class MenuItem {
  const MenuItem(this.label, this.icon, this.color, this.onTap, {this.badge, this.caption});

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  /// Small count shown on the corner (e.g. pending items).
  final int? badge;

  /// Optional one-line hint under the label.
  final String? caption;
}

/// Colourful, animated grid of shortcut cards for home screens.
class MenuGrid extends StatelessWidget {
  const MenuGrid({super.key, required this.items, this.columns = 3, this.startDelayMs = 80});

  final List<MenuItem> items;
  final int columns;
  final int startDelayMs;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final cols = c.maxWidth > 560 ? columns + 1 : columns;
      const gap = 10.0;
      final w = (c.maxWidth - gap * (cols - 1)) / cols;
      return Wrap(
        spacing: gap,
        runSpacing: gap,
        children: [
          for (var i = 0; i < items.length; i++)
            SizedBox(
              width: w,
              child: FadeSlideIn(
                delay: Duration(milliseconds: startDelayMs + 40 * (i < 14 ? i : 14)),
                offset: const Offset(0, 0.18),
                child: _MenuCard(item: items[i]),
              ),
            ),
        ],
      );
    });
  }
}

class _MenuCard extends StatelessWidget {
  const _MenuCard({required this.item});
  final MenuItem item;

  @override
  Widget build(BuildContext context) {
    final c = item.color;
    return PressScale(
      onTap: item.onTap,
      child: Container(
        height: item.caption == null ? 104 : 118,
        padding: const EdgeInsets.fromLTRB(10, 12, 10, 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
          boxShadow: [BoxShadow(color: c.withValues(alpha: 0.08), blurRadius: 14, offset: const Offset(0, 6))],
        ),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [c, Color.lerp(c, Colors.black, 0.18)!],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: c.withValues(alpha: 0.35), blurRadius: 10, offset: const Offset(0, 4))],
                  ),
                  child: Icon(item.icon, color: Colors.white, size: 22),
                ),
                const SizedBox(height: 9),
                Text(
                  item.label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, height: 1.15),
                ),
                if (item.caption != null)
                  Text(item.caption!, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.textMuted, fontSize: 10.5)),
              ],
            ),
            if ((item.badge ?? 0) > 0)
              Positioned(
                right: 0,
                top: -4,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(color: AppColors.danger, borderRadius: BorderRadius.circular(10)),
                  child: Text('${item.badge}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// A gentle pulsing dot (e.g. "lesson in progress").
class PulseDot extends StatefulWidget {
  const PulseDot({super.key, this.color = Colors.white, this.size = 10});
  final Color color;
  final double size;

  @override
  State<PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<PulseDot> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size * 2.2,
      height: widget.size * 2.2,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: widget.size * (1 + _c.value * 1.2),
              height: widget.size * (1 + _c.value * 1.2),
              decoration: BoxDecoration(shape: BoxShape.circle, color: widget.color.withValues(alpha: (1 - _c.value) * 0.5)),
            ),
            Container(width: widget.size, height: widget.size, decoration: BoxDecoration(shape: BoxShape.circle, color: widget.color)),
          ],
        ),
      ),
    );
  }
}

/// Greeting by time of day.
String greeting() {
  final h = DateTime.now().hour;
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}
