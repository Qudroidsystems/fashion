import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../network/api_client.dart';
import '../widgets/common.dart';

/// Downloads a PDF from the API (report card, payslip) and opens it in the
/// phone's PDF viewer; offers to share it if no viewer is installed.
class PdfOpener {
  PdfOpener._();

  static Future<void> open(String url, String fileName) => FileOpener.open(url, fileName, mime: 'application/pdf');

  static Future<void> share(String url, String fileName) => FileOpener.share(url, fileName, mime: 'application/pdf');
}

/// Downloads any file from the API and opens it with the phone's app for
/// that type (PDF viewer, Excel / Sheets…), falling back to the share sheet.
class FileOpener {
  FileOpener._();

  static const xlsx = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

  static Future<void> open(String url, String fileName, {required String mime, String busyLabel = 'Preparing document…'}) async {
    Get.dialog(
      PopScope(
        canPop: false,
        child: Center(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)),
                  const SizedBox(width: 16),
                  Text(busyLabel),
                ],
              ),
            ),
          ),
        ),
      ),
      barrierDismissible: false,
    );

    try {
      final bytes = await ApiClient.download(url);
      final dir = await getTemporaryDirectory();
      final safe = fileName.replaceAll(RegExp(r'[^A-Za-z0-9_.-]+'), '_');
      final file = File('${dir.path}/$safe');
      await file.writeAsBytes(bytes, flush: true);
      if (Get.isDialogOpen ?? false) Get.back();

      final result = await OpenFilex.open(file.path, type: mime);
      if (result.type != ResultType.done) {
        await Share.shareXFiles([XFile(file.path, mimeType: mime)], subject: safe);
      }
    } catch (e) {
      if (Get.isDialogOpen ?? false) Get.back();
      Toast.error(e);
    }
  }

  static Future<void> share(String url, String fileName, {required String mime}) async {
    try {
      final bytes = await ApiClient.download(url);
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/${fileName.replaceAll(RegExp(r'[^A-Za-z0-9_.-]+'), '_')}');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles([XFile(file.path, mimeType: mime)]);
    } catch (e) {
      Toast.error(e);
    }
  }
}
