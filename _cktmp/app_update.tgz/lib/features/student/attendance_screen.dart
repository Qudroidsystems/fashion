import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/json.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import 'attendance_calendar.dart';
import 'period_picker.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends LoadState<AttendanceScreen, AttendancePage> {
  int? _termId;
  int? _sessionId;

  @override
  Future<AttendancePage> fetch() => StudentRepository.attendance(widget.student.id, termId: _termId, sessionId: _sessionId);

  static String _label(String s) => s == 'sick_leave' ? 'Sick leave' : (s.isEmpty ? '' : '${s[0].toUpperCase()}${s.substring(1)}');

  @override
  Widget build(BuildContext context) {
    final p = data;
    final sum = p?.summary ?? const {};
    return Scaffold(
      appBar: AppBar(title: Text('Attendance — ${widget.student.firstName}')),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        child: p == null
            ? const SizedBox()
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  SessionTermPicker(
                    sessions: p.sessions,
                    terms: p.terms,
                    sessionId: p.sessionId,
                    termId: p.termId,
                    onChanged: (s, t) {
                      _sessionId = s;
                      _termId = t;
                      reload();
                    },
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(child: StatTile(label: 'Attendance', value: Fmt.percent(asDouble(sum['rate'])), color: AppColors.blue)),
                      const SizedBox(width: 10),
                      Expanded(child: StatTile(label: 'Present', value: '${asInt(sum['present']) ?? 0}', color: AppColors.success)),
                      const SizedBox(width: 10),
                      Expanded(child: StatTile(label: 'Absent', value: '${asInt(sum['absent']) ?? 0}', color: AppColors.danger)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: StatTile(label: 'Late', value: '${asInt(sum['late']) ?? 0}', color: AppColors.warning)),
                      const SizedBox(width: 10),
                      Expanded(child: StatTile(label: 'Excused', value: '${asInt(sum['excused']) ?? 0}', color: AppColors.info)),
                      const SizedBox(width: 10),
                      Expanded(child: StatTile(label: 'Sick leave', value: '${asInt(sum['sick_leave']) ?? 0}', color: AppColors.info)),
                    ],
                  ),
                  if (p.days.isNotEmpty) ...[
                    const SectionTitle('Calendar'),
                    AttendanceCalendar(days: p.days),
                  ],
                  const SectionTitle('Day by day'),
                  if (p.days.isEmpty)
                    const EmptyState(icon: AppIcons.attendance, title: 'No attendance marked for this term yet'),
                  for (final d in p.days)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: AppCard(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        child: Row(
                          children: [
                            Expanded(child: Text(Fmt.dayDate(d.date), style: const TextStyle(fontWeight: FontWeight.w700))),
                            Wrap(
                              spacing: 6,
                              children: [
                                for (final per in d.periods)
                                  StatusPill(
                                    d.periods.length > 1 ? '${asString(per['period']) ?? ''}: ${_label(asString(per['status']) ?? '')}' : _label(asString(per['status']) ?? ''),
                                    color: AppColors.attendance(asString(per['status'])),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
      ),
    );
  }
}
