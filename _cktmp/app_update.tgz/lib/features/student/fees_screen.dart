import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/pdf_opener.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import '../auth/auth_controller.dart';
import 'pay_fees_screen.dart';
import 'period_picker.dart';

/// Fee statement for a term: bills, discounts, payments and balance.
class FeesScreen extends StatefulWidget {
  const FeesScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<FeesScreen> createState() => _FeesScreenState();
}

class _FeesScreenState extends LoadState<FeesScreen, FeeStatement> {
  int? _termId;
  int? _sessionId;

  @override
  Future<FeeStatement> fetch() => StudentRepository.fees(widget.student.id, termId: _termId, sessionId: _sessionId);

  @override
  Widget build(BuildContext context) {
    final st = data;
    final user = AuthController.to.user.value;
    // Only the student or a linked parent can pay (relationship is set for them).
    final canPay = (user?.module('online_payments') ?? true) && widget.student.relationship != null;
    final owes = st != null && (st.outstanding + st.arrears) > 0;

    return Scaffold(
      appBar: AppBar(
        title: Text('Fees — ${widget.student.firstName}'),
        actions: [
          if (st != null)
            IconButton(
              tooltip: 'Payment statement (PDF)',
              icon: const Icon(AppIcons.receipt),
              onPressed: () => PdfOpener.open(
                StudentRepository.statementUrl(widget.student.id, termId: st.termId, sessionId: st.sessionId),
                'Payment_statement_${widget.student.firstName}.pdf',
              ),
            ),
        ],
      ),
      bottomNavigationBar: (canPay && st != null && owes)
          ? SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: ElevatedButton.icon(
                  onPressed: () async {
                    await Get.to(() => PayFeesScreen(student: widget.student, termId: st.termId, sessionId: st.sessionId));
                    reload();
                  },
                  icon: const Icon(AppIcons.pay),
                  label: Text('Pay online · ${Fmt.naira(st.outstanding + st.arrears)}'),
                ),
              ),
            )
          : null,
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        child: st == null
            ? const SizedBox()
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  SessionTermPicker(
                    sessions: st.sessions,
                    terms: st.terms,
                    sessionId: st.sessionId,
                    termId: st.termId,
                    onChanged: (s, t) {
                      _sessionId = s;
                      _termId = t;
                      reload();
                    },
                  ),
                  const SizedBox(height: 14),
                  AppCard(
                    color: AppColors.navy,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Balance this term', style: TextStyle(color: Colors.white.withValues(alpha: 0.75))),
                        const SizedBox(height: 4),
                        Text(Fmt.naira(st.outstanding), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            _Light('Payable', Fmt.naira(st.payable)),
                            _Light('Paid', Fmt.naira(st.paid)),
                            if (st.savings > 0) _Light('Discounts', Fmt.naira(st.savings)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  if (st.arrears > 0) ...[
                    const SizedBox(height: 10),
                    AppCard(
                      color: AppColors.danger.withValues(alpha: 0.06),
                      child: Row(
                        children: [
                          const Icon(AppIcons.warning, color: AppColors.danger),
                          const SizedBox(width: 10),
                          Expanded(child: Text('Unpaid balance from earlier terms: ${Fmt.naira(st.arrears)}', style: const TextStyle(fontWeight: FontWeight.w700))),
                        ],
                      ),
                    ),
                  ],
                  if (st.message != null) ...[
                    const SizedBox(height: 16),
                    EmptyState(icon: AppIcons.fees, title: st.message!),
                  ],
                  if (st.bills.isNotEmpty) const SectionTitle('Bills'),
                  for (final b in st.bills) ...[
                    _BillCard(b),
                    const SizedBox(height: 10),
                  ],
                  if (st.payments.isNotEmpty) const SectionTitle('Payments'),
                  for (final p in st.payments)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: AppCard(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        child: Row(
                          children: [
                            const Icon(AppIcons.check, color: AppColors.success),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(p.bill ?? 'Payment', style: const TextStyle(fontWeight: FontWeight.w700)),
                                  Text('${Fmt.date(p.paidAt)} · ${p.method ?? ''}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                                ],
                              ),
                            ),
                            Text(Fmt.naira(p.amount), style: const TextStyle(fontWeight: FontWeight.w800)),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 24),
                ],
              ),
      ),
    );
  }
}

class _Light extends StatelessWidget {
  const _Light(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: Colors.white.withValues(alpha: 0.7), fontSize: 12)),
          FittedBox(child: Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
        ],
      ),
    );
  }
}

class _BillCard extends StatelessWidget {
  const _BillCard(this.b);
  final FeeBill b;

  @override
  Widget build(BuildContext context) {
    final statusLabel = b.isOverdue ? 'Overdue' : (b.status.isEmpty ? '' : '${b.status[0].toUpperCase()}${b.status.substring(1)}');
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(b.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
              if (statusLabel.isNotEmpty) StatusPill(statusLabel),
            ],
          ),
          if (b.dueDate != null) Text('Due ${b.dueDate}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: (b.progress / 100).clamp(0, 1).toDouble(),
              minHeight: 7,
              backgroundColor: AppColors.background,
              color: b.balance <= 0 ? AppColors.success : AppColors.blue,
            ),
          ),
          const SizedBox(height: 8),
          InfoRow('Amount', Fmt.naira(b.payable)),
          if (b.savings > 0) InfoRow(b.savingsLabels.isEmpty ? 'Discount' : b.savingsLabels.join(', '), '− ${Fmt.naira(b.savings)}', valueColor: AppColors.success),
          InfoRow('Paid', Fmt.naira(b.paid)),
          InfoRow('Balance', Fmt.naira(b.balance), bold: true, valueColor: b.balance > 0 ? AppColors.danger : AppColors.success),
        ],
      ),
    );
  }
}
