import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/json.dart';
import '../../core/widgets/common.dart';
import '../../data/models/student.dart';

/// Month view of attendance: each school day is coloured by its status
/// (the worst status when a day has several periods).
class AttendanceCalendar extends StatefulWidget {
  const AttendanceCalendar({super.key, required this.days});

  final List<AttendanceDay> days;

  @override
  State<AttendanceCalendar> createState() => _AttendanceCalendarState();
}

class _AttendanceCalendarState extends State<AttendanceCalendar> {
  late List<DateTime> _months;
  int _index = 0;

  static const _rank = {'absent': 5, 'late': 4, 'sick_leave': 3, 'excused': 2, 'present': 1};

  @override
  void initState() {
    super.initState();
    _build();
  }

  @override
  void didUpdateWidget(covariant AttendanceCalendar old) {
    super.didUpdateWidget(old);
    if (old.days != widget.days) _build();
  }

  void _build() {
    final set = <String, DateTime>{};
    for (final d in widget.days) {
      final dt = d.date;
      if (dt == null) continue;
      set['${dt.year}-${dt.month}'] = DateTime(dt.year, dt.month);
    }
    _months = set.values.toList()..sort();
    _index = _months.isEmpty ? 0 : _months.length - 1;
  }

  Map<int, String> _statusByDay(DateTime month) {
    final out = <int, String>{};
    for (final d in widget.days) {
      final dt = d.date;
      if (dt == null || dt.year != month.year || dt.month != month.month) continue;
      String? worst;
      for (final p in d.periods) {
        final s = asString(p['status']) ?? '';
        if (worst == null || (_rank[s] ?? 0) > (_rank[worst] ?? 0)) worst = s;
      }
      if (worst != null) out[dt.day] = worst;
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    if (_months.isEmpty) return const SizedBox.shrink();
    final month = _months[_index];
    final status = _statusByDay(month);
    final first = DateTime(month.year, month.month, 1);
    final daysInMonth = DateTime(month.year, month.month + 1, 0).day;
    final lead = first.weekday - 1; // Monday first
    final today = DateTime.now();

    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 14),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                onPressed: _index > 0 ? () => setState(() => _index--) : null,
                icon: const Icon(Icons.chevron_left),
              ),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: Text(
                    DateFormat('MMMM yyyy').format(month),
                    key: ValueKey(month),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5),
                  ),
                ),
              ),
              IconButton(
                onPressed: _index < _months.length - 1 ? () => setState(() => _index++) : null,
                icon: const Icon(Icons.chevron_right),
              ),
            ],
          ),
          Row(
            children: [
              for (final d in const ['M', 'T', 'W', 'T', 'F', 'S', 'S'])
                Expanded(child: Center(child: Text(d, style: const TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w700, fontSize: 12)))),
            ],
          ),
          const SizedBox(height: 6),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: GridView.count(
              key: ValueKey(month),
              crossAxisCount: 7,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 6,
              crossAxisSpacing: 6,
              children: [
                for (var i = 0; i < lead; i++) const SizedBox.shrink(),
                for (var day = 1; day <= daysInMonth; day++)
                  _DayCell(
                    day: day,
                    status: status[day],
                    isToday: today.year == month.year && today.month == month.month && today.day == day,
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          const Wrap(
            spacing: 12,
            runSpacing: 6,
            children: [
              _Legend('Present', 'present'),
              _Legend('Late', 'late'),
              _Legend('Absent', 'absent'),
              _Legend('Excused', 'excused'),
            ],
          ),
        ],
      ),
    );
  }
}

class _DayCell extends StatelessWidget {
  const _DayCell({required this.day, this.status, this.isToday = false});

  final int day;
  final String? status;
  final bool isToday;

  @override
  Widget build(BuildContext context) {
    final c = status == null ? null : AppColors.attendance(status);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.6, end: 1),
      duration: Duration(milliseconds: 250 + day * 12),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Transform.scale(scale: v, child: child),
      child: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: c?.withValues(alpha: 0.16) ?? Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: isToday ? Border.all(color: AppColors.navy, width: 1.5) : null,
        ),
        child: Text(
          '$day',
          style: TextStyle(fontWeight: c == null ? FontWeight.w500 : FontWeight.w800, color: c ?? AppColors.textMuted, fontSize: 13),
        ),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend(this.label, this.status);
  final String label;
  final String status;

  @override
  Widget build(BuildContext context) {
    final c = AppColors.attendance(status);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
      ],
    );
  }
}

