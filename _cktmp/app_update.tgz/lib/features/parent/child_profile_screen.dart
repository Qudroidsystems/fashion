import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/json.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';

/// The student's school record (bio data) as the school holds it.
class ChildProfileScreen extends StatefulWidget {
  const ChildProfileScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<ChildProfileScreen> createState() => _ChildProfileScreenState();
}

class _ChildProfileScreenState extends LoadState<ChildProfileScreen, StudentCard> {
  @override
  void initState() {
    data = widget.student.profile.isEmpty ? null : widget.student;
    super.initState();
  }

  @override
  Future<StudentCard> fetch() => StudentRepository.student(widget.student.id);

  String _v(dynamic v) {
    final s = asString(v);
    return (s == null || s.trim().isEmpty) ? '—' : s;
  }

  @override
  Widget build(BuildContext context) {
    final s = data ?? widget.student;
    final p = s.profile;
    final dob = asDate(p['date_of_birth']);
    final admitted = asDate(p['admission_date']);

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: AsyncBody(
        loading: loading && data == null,
        error: data == null ? error : null,
        onRetry: load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: FadeSlideIn.staggered([
            Center(child: Hero(tag: 'student-${s.id}', child: PersonAvatar(name: s.fullName, url: s.photoUrl, size: 96))),
            const SizedBox(height: 12),
            Text(s.fullName, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            Text([s.className, s.admissionNo].whereType<String>().join(' · '), textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textMuted)),
            const SectionTitle('School record'),
            AppCard(
              child: Column(
                children: [
                  InfoRow('Admission number', _v(s.admissionNo)),
                  InfoRow('Class', _v(s.className)),
                  InfoRow('Admitted', admitted == null ? '—' : Fmt.date(admitted)),
                  InfoRow('Status', _v(p['status'])),
                  InfoRow('House', _v(p['house'])),
                ],
              ),
            ),
            const SectionTitle('Personal'),
            AppCard(
              child: Column(
                children: [
                  InfoRow('Gender', _v(p['gender'])),
                  InfoRow('Date of birth', dob == null ? _v(p['date_of_birth']) : Fmt.date(dob)),
                  InfoRow('Blood group', _v(p['blood_group'])),
                  InfoRow('Genotype', _v(p['genotype'])),
                  InfoRow('Address', _v(p['address'])),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const Row(
              children: [
                Icon(AppIcons.info, size: 16, color: AppColors.textMuted),
                SizedBox(width: 6),
                Expanded(child: Text('Something wrong? Please contact the school office to update it.', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5))),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}
