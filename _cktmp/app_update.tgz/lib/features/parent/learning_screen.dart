import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/charts.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/parent_extras.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import '../student/period_picker.dart';

/// Homework / assignments and e-learning course progress.
class LearningScreen extends StatefulWidget {
  const LearningScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<LearningScreen> createState() => _LearningScreenState();
}

class _LearningScreenState extends LoadState<LearningScreen, LearningPage> {
  String _tab = 'To do';

  @override
  Future<LearningPage> fetch() => StudentRepository.learning(widget.student.id);

  @override
  Widget build(BuildContext context) {
    final p = data;
    final todo = p?.homework.where((h) => h.state == 'pending' || h.state == 'overdue').toList() ?? const <Homework>[];
    final done = p?.homework.where((h) => h.state == 'submitted' || h.state == 'graded').toList() ?? const <Homework>[];
    final list = _tab == 'To do' ? todo : done;

    return Scaffold(
      appBar: AppBar(title: Text('Homework — ${widget.student.firstName}')),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: p != null && p.courses.isEmpty,
        emptyIcon: AppIcons.book,
        emptyTitle: 'No online classes yet',
        emptyMessage: 'Homework and e-learning courses will show here when teachers publish them.',
        child: p == null
            ? const SizedBox()
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  ...FadeSlideIn.staggered([
                    Row(
                      children: [
                        Expanded(child: StatTile(label: 'To do', value: '${p.due}', icon: AppIcons.task, color: AppColors.blue)),
                        const SizedBox(width: 10),
                        Expanded(child: StatTile(label: 'Overdue', value: '${p.overdue}', icon: AppIcons.warning, color: AppColors.danger)),
                        const SizedBox(width: 10),
                        Expanded(child: StatTile(label: 'Marked', value: '${p.graded}', icon: AppIcons.check, color: AppColors.success)),
                      ],
                    ),
                    const SectionTitle('Courses'),
                    SizedBox(
                      height: 132,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: p.courses.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 10),
                        itemBuilder: (_, i) => _CourseCard(p.courses[i]),
                      ),
                    ),
                    const SectionTitle('Assignments'),
                    ChoiceRow<String>(
                      items: const ['To do', 'Done'],
                      selected: _tab,
                      label: (t) => '$t (${t == 'To do' ? todo.length : done.length})',
                      onSelected: (t) => setState(() => _tab = t),
                    ),
                    const SizedBox(height: 10),
                  ]),
                  if (list.isEmpty)
                    EmptyState(
                      icon: _tab == 'To do' ? AppIcons.check : AppIcons.task,
                      title: _tab == 'To do' ? 'All caught up!' : 'Nothing submitted yet',
                    ),
                  ...FadeSlideIn.staggered([for (final h in list) _HomeworkCard(h)], startMs: 120),
                ],
              ),
      ),
    );
  }
}

class _CourseCard extends StatelessWidget {
  const _CourseCard(this.c);
  final LmsCourseInfo c;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 230,
      child: AppCard(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            ProgressRing(value: c.progress / 100, size: 58, color: c.progress >= 100 ? AppColors.success : AppColors.blue),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(c.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                  if (c.teacher != null) Text(c.teacher!, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(
                    [if (c.pending > 0) '${c.pending} to do', if (c.quizAverage != null) 'Quiz ${Fmt.percent(c.quizAverage)}'].join(' · '),
                    style: const TextStyle(color: AppColors.blue, fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeworkCard extends StatelessWidget {
  const _HomeworkCard(this.h);
  final Homework h;

  static const _labels = {'pending': 'To do', 'overdue': 'Overdue', 'submitted': 'Submitted', 'graded': 'Marked'};
  static const _colors = {'pending': AppColors.blue, 'overdue': AppColors.danger, 'submitted': AppColors.info, 'graded': AppColors.success};

  @override
  Widget build(BuildContext context) {
    final due = h.dueAt;
    final days = due?.difference(DateTime.now()).inDays;
    final dueText = due == null
        ? 'No due date'
        : (h.state == 'pending' && days != null && days <= 2 ? 'Due ${days <= 0 ? 'today' : 'in $days day${days == 1 ? '' : 's'}'}' : 'Due ${Fmt.dateTime(due)}');

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(h.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
                StatusPill(_labels[h.state] ?? h.state, color: _colors[h.state]),
              ],
            ),
            const SizedBox(height: 2),
            Text('${h.course} · $dueText', style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
            if (h.instructions != null && h.instructions!.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(h.instructions!, maxLines: 3, overflow: TextOverflow.ellipsis),
            ],
            if (h.score != null) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(AppIcons.medal, size: 18, color: AppColors.success),
                  const SizedBox(width: 6),
                  Text('Score: ${Fmt.number(h.score)}${h.maxScore != null ? ' / ${Fmt.number(h.maxScore)}' : ''}',
                      style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.success)),
                ],
              ),
              if (h.feedback != null && h.feedback!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('“${h.feedback!}”', style: const TextStyle(fontStyle: FontStyle.italic, color: AppColors.textMuted)),
                ),
            ],
          ],
        ),
      ),
    );
  }
}
