import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/parent_extras.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';

/// The child's form teacher and subject teachers, with call / WhatsApp / e-mail.
class TeachersScreen extends StatefulWidget {
  const TeachersScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<TeachersScreen> createState() => _TeachersScreenState();
}

class _TeachersScreenState extends LoadState<TeachersScreen, TeachersPage> {
  @override
  Future<TeachersPage> fetch() => StudentRepository.teachers(widget.student.id);

  @override
  Widget build(BuildContext context) {
    final p = data;
    final children = <Widget>[
      if (p != null && p.classTeachers.isNotEmpty) ...[
        SectionTitle(p.classTeachers.length == 1 ? 'Class teacher' : 'Class teachers'),
        for (final t in p.classTeachers) _TeacherCard(t, highlight: true),
      ],
      if (p != null && p.subjectTeachers.isNotEmpty) ...[
        const SectionTitle('Subject teachers'),
        for (final t in p.subjectTeachers) _TeacherCard(t),
      ],
    ];

    return Scaffold(
      appBar: AppBar(title: Text('Teachers — ${widget.student.firstName}')),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: p != null && p.classTeachers.isEmpty && p.subjectTeachers.isEmpty,
        emptyIcon: AppIcons.teacher,
        emptyTitle: 'No teachers assigned yet',
        emptyMessage: 'Teachers will appear here once the school assigns them to the class.',
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          children: FadeSlideIn.staggered(children),
        ),
      ),
    );
  }
}

class _TeacherCard extends StatelessWidget {
  const _TeacherCard(this.t, {this.highlight = false});

  final TeacherContact t;
  final bool highlight;

  String? get _whatsApp {
    final p = t.phone?.replaceAll(RegExp(r'[^0-9+]'), '');
    if (p == null || p.isEmpty) return null;
    if (p.startsWith('+')) return p.substring(1);
    if (p.startsWith('0')) return '234${p.substring(1)}';
    return p;
  }

  Future<void> _open(String url) async {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication).catchError((_) => false);
    if (!ok) Toast.info('No app on this phone can open that.');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        color: highlight ? AppColors.sky : null,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                PersonAvatar(name: t.name, url: t.photoUrl, size: 50),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                      if (t.subjects.isNotEmpty)
                        Text(t.subjects.join(', '), style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5))
                      else if (t.jobTitle != null)
                        Text(t.jobTitle!, style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                    ],
                  ),
                ),
              ],
            ),
            if (t.phone != null || t.email != null) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  if (t.phone != null) _Action(AppIcons.call, 'Call', AppColors.success, () => _open('tel:${t.phone}')),
                  if (_whatsApp != null) _Action(AppIcons.message, 'WhatsApp', const Color(0xFF25D366), () => _open('https://wa.me/$_whatsApp')),
                  if (t.email != null) _Action(AppIcons.sms, 'E-mail', AppColors.blue, () => _open('mailto:${t.email}')),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Action extends StatelessWidget {
  const _Action(this.icon, this.label, this.color, this.onTap);
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: PressScale(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 9),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 17, color: color),
                const SizedBox(width: 6),
                Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12.5)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
