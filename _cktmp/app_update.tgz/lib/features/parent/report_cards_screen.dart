import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/pdf_opener.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';

/// Every term's report card in one place, to open, save or share.
class ReportCardsScreen extends StatefulWidget {
  const ReportCardsScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<ReportCardsScreen> createState() => _ReportCardsScreenState();
}

class _ReportCardsScreenState extends LoadState<ReportCardsScreen, ResultsPage> {
  @override
  Future<ResultsPage> fetch() => StudentRepository.results(widget.student.id);

  String _url(ResultTerm t) => '/students/${widget.student.id}/report-card/${t.sessionId}/${t.termId}/${t.classId}';

  String _file(ResultTerm t) => 'Report_${widget.student.firstName}_${t.term}_${t.session}.pdf';

  @override
  Widget build(BuildContext context) {
    final terms = data?.terms ?? const <ResultTerm>[];
    final bySession = <String, List<ResultTerm>>{};
    for (final t in terms) {
      bySession.putIfAbsent(t.session, () => []).add(t);
    }

    final children = <Widget>[];
    for (final e in bySession.entries) {
      children.add(SectionTitle(e.key));
      for (final t in e.value) {
        children.add(Padding(padding: const EdgeInsets.only(bottom: 10), child: _card(t)));
      }
    }

    return Scaffold(
      appBar: AppBar(title: Text('Report cards — ${widget.student.firstName}')),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: data != null && terms.isEmpty,
        emptyIcon: AppIcons.document,
        emptyTitle: 'No report cards yet',
        emptyMessage: 'Report cards appear here once results are published.',
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: FadeSlideIn.staggered(children)),
      ),
    );
  }

  Widget _card(ResultTerm t) {
    final ok = t.allowed && t.ready;
    final status = !t.allowed ? (t.notReleased ? 'Not released' : 'On hold') : (t.ready ? 'Ready' : 'In progress');
    final color = ok ? AppColors.success : (!t.allowed ? AppColors.danger : AppColors.warning);

    return AppCard(
      onTap: ok ? () => PdfOpener.open(_url(t), _file(t)) : () => Toast.info(t.holdMessage ?? 'This report card is not ready yet.'),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 56,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
            child: Icon(ok ? AppIcons.document : AppIcons.lock, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.term, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                Text(
                  [t.className, '${t.subjects} subjects', if (t.allowed && t.average != null) 'avg ${Fmt.number(t.average)}'].whereType<String>().join(' · '),
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                ),
                const SizedBox(height: 6),
                StatusPill(status, color: color),
              ],
            ),
          ),
          if (ok)
            IconButton(
              tooltip: 'Share',
              onPressed: () => PdfOpener.share(_url(t), _file(t)),
              icon: const Icon(AppIcons.message, color: AppColors.navy),
            ),
          if (ok) const Icon(AppIcons.download, color: AppColors.blue),
        ],
      ),
    );
  }
}
