import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/charts.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/parent_extras.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';

/// Term-by-term averages and how each subject is moving.
class PerformanceScreen extends StatefulWidget {
  const PerformanceScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<PerformanceScreen> createState() => _PerformanceScreenState();
}

class _PerformanceScreenState extends LoadState<PerformanceScreen, PerformancePage> {
  @override
  Future<PerformancePage> fetch() => StudentRepository.performance(widget.student.id);

  @override
  Widget build(BuildContext context) {
    final p = data;
    return Scaffold(
      appBar: AppBar(title: Text('Progress — ${widget.student.firstName}')),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: p != null && p.terms.isEmpty,
        emptyIcon: AppIcons.chart,
        emptyTitle: 'No results to chart yet',
        emptyMessage: (p?.hiddenTerms ?? 0) > 0
            ? 'Some results are on hold. Clear outstanding fees to see them.'
            : 'Progress shows here once results are published.',
        child: p == null ? const SizedBox() : _body(p),
      ),
    );
  }

  Widget _body(PerformancePage p) {
    final change = p.change;
    final up = (change ?? 0) >= 0;
    final latest = p.terms.isNotEmpty ? p.terms.last : null;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: FadeSlideIn.staggered([
        Row(
          children: [
            Expanded(
              child: StatTile(label: 'Latest average', value: Fmt.percent(p.latestAverage), icon: AppIcons.medal, color: AppColors.blue),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatTile(
                label: 'Since last term',
                value: change == null ? '—' : '${up ? '+' : ''}${Fmt.number(change)}',
                icon: up ? AppIcons.trendUp : AppIcons.trendDown,
                color: change == null ? AppColors.textMuted : (up ? AppColors.success : AppColors.danger),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: StatTile(label: 'Best average', value: Fmt.percent(p.bestAverage), icon: AppIcons.trendUp, color: AppColors.success)),
          ],
        ),
        const SectionTitle('Average per term'),
        AppCard(
          child: TrendChart(
            labels: p.terms.map((t) => t.label).toList(),
            series: [
              ChartSeries(widget.student.firstName, p.terms.map((t) => t.average).toList(), AppColors.blue),
              ChartSeries('Class average', p.terms.map((t) => t.classAverage).toList(), AppColors.warning, dashed: true),
            ],
          ),
        ),
        if (p.strongest != null || p.needsAttention != null) ...[
          const SizedBox(height: 12),
          Row(
            children: [
              if (p.strongest != null)
                Expanded(child: _Insight(AppIcons.medal, 'Strongest', p.strongest!, AppColors.success)),
              if (p.strongest != null && p.needsAttention != null && p.needsAttention != p.strongest) const SizedBox(width: 10),
              if (p.needsAttention != null && p.needsAttention != p.strongest)
                Expanded(child: _Insight(AppIcons.warning, 'Needs attention', p.needsAttention!, AppColors.warning)),
            ],
          ),
        ],
        if (latest != null && latest.grades.isNotEmpty) ...[
          SectionTitle('Grades — ${latest.term}'),
          AppCard(child: _GradeBars(grades: latest.grades)),
        ],
        const SectionTitle('Subjects'),
        for (final s in p.subjects) _SubjectRow(s),
        if (p.hiddenTerms > 0)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              '${p.hiddenTerms} term${p.hiddenTerms == 1 ? ' is' : 's are'} not shown because the result is on hold.',
              style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
            ),
          ),
      ], maxSteps: 10),
    );
  }
}

class _Insight extends StatelessWidget {
  const _Insight(this.icon, this.label, this.value, this.color);
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w700)),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _GradeBars extends StatelessWidget {
  const _GradeBars({required this.grades});
  final Map<String, int> grades;

  @override
  Widget build(BuildContext context) {
    final keys = grades.keys.toList()..sort();
    final most = grades.values.fold<int>(1, (m, v) => v > m ? v : m);
    return Column(
      children: [
        for (final g in keys)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                SizedBox(width: 26, child: Text(g, style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.grade(g)))),
                Expanded(child: AnimatedBar(value: grades[g]! / most, color: AppColors.grade(g), height: 10)),
                SizedBox(width: 34, child: Text('${grades[g]}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700))),
              ],
            ),
          ),
      ],
    );
  }
}

class _SubjectRow extends StatelessWidget {
  const _SubjectRow(this.s);
  final SubjectTrend s;

  @override
  Widget build(BuildContext context) {
    final t = s.trend;
    final color = t == null ? AppColors.textMuted : (t >= 0 ? AppColors.success : AppColors.danger);
    final latest = s.latest ?? 0;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: Text(s.subject, style: const TextStyle(fontWeight: FontWeight.w700))),
                if (s.scores.whereType<double>().length > 1) ...[
                  Sparkline(values: s.scores, color: color),
                  const SizedBox(width: 10),
                ],
                CountUpText(Fmt.number(s.latest), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                if (t != null) ...[
                  const SizedBox(width: 6),
                  Icon(t >= 0 ? AppIcons.trendUp : AppIcons.trendDown, size: 16, color: color),
                ],
              ],
            ),
            const SizedBox(height: 8),
            AnimatedBar(
              value: latest / 100,
              height: 6,
              color: latest >= 70 ? AppColors.success : (latest >= 50 ? AppColors.blue : (latest >= 40 ? AppColors.warning : AppColors.danger)),
            ),
          ],
        ),
      ),
    );
  }
}
