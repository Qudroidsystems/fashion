import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/user.dart';
import '../student/period_picker.dart';
import '../../data/models/staff.dart';
import '../../data/repositories/school_repository.dart';
import 'scoresheet_screen.dart';

/// The teacher's subjects with score-entry progress — for the current term
/// or any earlier term / session (score sheets of past periods open with the
/// totals, grades and positions they ended with).
class SubjectsScreen extends StatefulWidget {
  const SubjectsScreen({super.key, this.standalone = false, this.history = false});

  final bool standalone;

  /// Open on the previous term (for "Past results").
  final bool history;

  @override
  State<SubjectsScreen> createState() => _SubjectsScreenState();
}

class _SubjectsScreenState extends LoadState<SubjectsScreen, List<SubjectAssignment>> {
  List<TeachingPeriod> _periods = const [];
  int? _sessionId; // null = current
  int? _termId; // null = all terms of the session
  bool _historyApplied = false;

  @override
  Future<List<SubjectAssignment>> fetch() async {
    final (items, periods) = await StaffRepository.subjectsWithPeriods(sessionId: _sessionId, termId: _termId);
    _periods = periods;
    if (widget.history && !_historyApplied) {
      _historyApplied = true;
      final prev = _previousPeriod();
      if (prev != null) {
        _sessionId = prev.$1;
        _termId = prev.$2;
        return (await StaffRepository.subjectsWithPeriods(sessionId: _sessionId, termId: _termId)).$1;
      }
    }
    return items;
  }

  /// The term before the latest one the teacher has subjects in.
  (int, int)? _previousPeriod() {
    final flat = <(int, int)>[];
    for (final p in _periods.reversed) {
      for (final t in p.terms) {
        flat.add((p.sessionId, t.id));
      }
    }
    // _periods is newest session first; flat is now oldest → newest.
    if (flat.length < 2) return null;
    return flat[flat.length - 2];
  }

  TeachingPeriod? get _session {
    for (final p in _periods) {
      if (_sessionId == null ? p.current : p.sessionId == _sessionId) return p;
    }
    return _periods.isNotEmpty ? _periods.first : null;
  }

  void _choose({int? sessionId, int? termId, bool clearTerm = false}) {
    setState(() {
      if (sessionId != null) _sessionId = sessionId;
      _termId = clearTerm ? null : (termId ?? _termId);
    });
    load();
  }

  @override
  Widget build(BuildContext context) {
    final items = data ?? const <SubjectAssignment>[];
    final byTerm = <String, List<SubjectAssignment>>{};
    for (final a in items) {
      byTerm.putIfAbsent(a.term ?? 'Term', () => []).add(a);
    }
    final session = _session;
    final isPast = session != null && !session.current;
    final linked = items.where((a) => a.canOpen).toList();
    final avg = linked.isEmpty ? 0 : (linked.fold<int>(0, (t, a) => t + a.progress) / linked.length).round();

    final cards = <Widget>[];
    for (final entry in byTerm.entries) {
      cards.add(SectionTitle(entry.key, trailing: Text(entry.value.first.session ?? '', style: const TextStyle(color: AppColors.textMuted))));
      for (final a in entry.value) {
        cards.add(Padding(padding: const EdgeInsets.only(bottom: 10), child: _AssignmentCard(a, past: isPast, onChanged: reload)));
      }
    }

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: widget.standalone, title: const Text('Scores & results')),
      body: Column(
        children: [
          if (_periods.isNotEmpty)
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (_periods.length > 1) ...[
                    ChoiceRow<TeachingPeriod>(
                      items: _periods,
                      selected: session,
                      label: (p) => p.current ? '${p.session} (current)' : p.session,
                      same: (x, y) => x.sessionId == y.sessionId,
                      onSelected: (p) => _choose(sessionId: p.sessionId, clearTerm: true),
                    ),
                    const SizedBox(height: 8),
                  ],
                  ChoiceRow<IdName>(
                    items: [const IdName(0, 'All terms'), ...?session?.terms],
                    selected: IdName(_termId ?? 0, ''),
                    label: (t) => t.name,
                    same: (x, y) => x.id == y.id,
                    onSelected: (t) => t.id == 0 ? _choose(clearTerm: true) : _choose(termId: t.id),
                  ),
                ],
              ),
            ),
          Expanded(
            child: AsyncBody(
              loading: loading,
              error: error,
              onRetry: load,
              isEmpty: data != null && items.isEmpty,
              emptyIcon: AppIcons.scores,
              emptyTitle: 'No subjects for this period',
              emptyMessage: 'Pick another term or session above to see earlier score sheets.',
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (isPast)
                    FadeSlideIn(
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 6),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: AppColors.sky, borderRadius: BorderRadius.circular(12)),
                        child: Row(
                          children: [
                            const Icon(AppIcons.history, color: AppColors.navy, size: 20),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text('Viewing ${session?.session ?? 'a past session'}. Open a subject to see its scores, grades and positions.',
                                  style: const TextStyle(color: AppColors.navy, fontSize: 13)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  Row(
                    children: [
                      Expanded(child: StatTile(label: 'Subjects', value: '${items.map((a) => a.subject).toSet().length}', icon: AppIcons.book, color: AppColors.blue)),
                      const SizedBox(width: 10),
                      Expanded(child: StatTile(label: 'Students', value: '${linked.fold<int>(0, (t, a) => t + a.students)}', icon: AppIcons.people, color: AppColors.info)),
                      const SizedBox(width: 10),
                      Expanded(child: StatTile(label: 'Entered', value: '$avg%', icon: AppIcons.chart, color: avg >= 100 ? AppColors.success : AppColors.warning)),
                    ],
                  ),
                  ...FadeSlideIn.staggered(cards, startMs: 60),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AssignmentCard extends StatelessWidget {
  const _AssignmentCard(this.a, {required this.onChanged, this.past = false});
  final SubjectAssignment a;
  final VoidCallback onChanged;
  final bool past;

  @override
  Widget build(BuildContext context) {
    final done = a.status == 'complete';
    return AppCard(
      onTap: a.canOpen
          ? () async {
              await Get.to(() => ScoresheetScreen(assignment: a));
              onChanged();
            }
          : () => Toast.info('This subject has not been linked to a class yet. Please ask the admin.'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(a.subject, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                    Text(a.className ?? 'No class linked', style: const TextStyle(color: AppColors.textMuted)),
                  ],
                ),
              ),
              if (past) const Padding(padding: EdgeInsets.only(right: 8), child: StatusPill('View', color: AppColors.navy)),
              CountUpText('${a.progress}%', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: done ? AppColors.success : AppColors.blue)),
            ],
          ),
          const SizedBox(height: 10),
          AnimatedBar(value: a.progress / 100, height: 7, color: done ? AppColors.success : AppColors.blue),
          const SizedBox(height: 6),
          Text('${a.entered} of ${a.students} students scored', style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
        ],
      ),
    );
  }
}
