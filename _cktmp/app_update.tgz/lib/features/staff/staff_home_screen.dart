import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/json.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/staff.dart';
import '../../data/repositories/school_repository.dart';
import '../auth/auth_controller.dart';
import '../admin/admin_dashboard_screen.dart';
import '../admin/approvals_screen.dart';
import '../admin/student_search_screen.dart';
import '../common/calendar_screen.dart';
import '../common/inbox_screen.dart';
import '../common/notification_settings_screen.dart';
import '../results/results_board_screen.dart';
import 'classes_screen.dart';
import 'payslips_screen.dart';
import 'staff_leave_screen.dart';
import 'staff_timetable_screen.dart';
import 'subjects_screen.dart';

/// Staff home: today's lessons and shortcuts.
class StaffHomeScreen extends StatefulWidget {
  const StaffHomeScreen({super.key});

  @override
  State<StaffHomeScreen> createState() => _StaffHomeScreenState();
}

class _StaffHomeScreenState extends LoadState<StaffHomeScreen, Map<String, dynamic>> {
  Timer? _tick;

  @override
  Future<Map<String, dynamic>> fetch() => StaffRepository.home();

  @override
  void initState() {
    super.initState();
    // Keep "next class" up to date; reload when a lesson ends.
    _tick = Timer.periodic(const Duration(minutes: 1), (_) {
      if (!mounted) return;
      final next = asMap((data ?? const <String, dynamic>{})['next_lesson']);
      final end = asString(next['end_time']);
      if (end != null && _nowHm().compareTo(end) >= 0) {
        reload();
      } else {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  static String _nowHm() {
    final n = DateTime.now();
    return '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final auth = AuthController.to;
    final u = auth.user.value;
    final h = data ?? const <String, dynamic>{};
    final current = asMap(h['current']);
    final lessons = StaffRepository.todayLessons(h);

    final can = (String a) => u?.can(a) ?? false;
    final menu = <MenuItem>[
      if (can('scores.enter')) MenuItem('Enter scores', AppIcons.scores, AppColors.blue, () => Get.to(() => const SubjectsScreen(standalone: true))),
      if (can('scores.enter')) MenuItem('Past results', AppIcons.history, const Color(0xFF7C3AED), () => Get.to(() => const SubjectsScreen(standalone: true, history: true))),
      if (can('attendance.mark')) MenuItem('Attendance', AppIcons.register, AppColors.success, () => Get.to(() => const ClassesScreen(standalone: true))),
      if (can('results.board')) MenuItem('Broadsheets', AppIcons.results, const Color(0xFFDB2777), () => Get.to(() => const ResultsBoardScreen())),
      MenuItem('Timetable', AppIcons.timetable, AppColors.warning, () => Get.to(() => const StaffTimetableScreen())),
      MenuItem('My leave', AppIcons.leave, AppColors.info, () => Get.to(() => const StaffLeaveScreen()), badge: asInt(h['pending_leave'])),
      if (u?.module('payroll') ?? true) MenuItem('Payslips', AppIcons.payslip, const Color(0xFF0D9488), () => Get.to(() => const PayslipsScreen())),
      MenuItem('Calendar', AppIcons.calendar, const Color(0xFFEA580C), () => Get.to(() => const CalendarScreen(standalone: true))),
      MenuItem('Notices', AppIcons.inbox, AppColors.navy, () => Get.to(() => const InboxScreen(standalone: true))),
      MenuItem('Reminders', AppIcons.bell, const Color(0xFF4F46E5), () => Get.to(() => const NotificationSettingsScreen())),
      if (can('leave.approve') || can('student_leave.approve'))
        MenuItem('Approvals', AppIcons.approvals, AppColors.danger, () => Get.to(() => const ApprovalsScreen())),
      if (can('students.view')) MenuItem('Find student', AppIcons.search, const Color(0xFF0891B2), () => Get.to(() => const StudentSearchScreen())),
      if (can('management.dashboard')) MenuItem('School overview', AppIcons.overview, const Color(0xFF334155), () => Get.to(() => const AdminDashboardScreen())),
    ];

    return Scaffold(
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            HeroHeader(
              child: SafeArea(
                bottom: false,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Hero(tag: 'me-avatar', child: PersonAvatar(name: u?.name ?? '', url: u?.avatarUrl, size: 48)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${greeting()},', style: TextStyle(color: Colors.white.withValues(alpha: 0.75))),
                              Text(u?.name ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800)),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => Get.to(() => const InboxScreen(standalone: true)),
                          icon: const Icon(AppIcons.bell, color: Colors.white),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
                      child: Text(
                        '${asString(current['term']) ?? ''} · ${asString(current['session']) ?? ''} · ${lessons.length} lesson${lessons.length == 1 ? '' : 's'} today',
                        style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ...FadeSlideIn.staggered([
                    Row(
                      children: [
                        Expanded(
                          child: StatTile(
                            label: 'Subjects',
                            value: '${asInt(h['subject_count']) ?? 0}',
                            icon: AppIcons.book,
                            color: AppColors.blue,
                            onTap: can('scores.enter') ? () => Get.to(() => const SubjectsScreen(standalone: true)) : null,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: StatTile(
                            label: 'My classes',
                            value: '${asInt(h['class_count']) ?? 0}',
                            icon: AppIcons.register,
                            color: AppColors.success,
                            onTap: can('attendance.mark') ? () => Get.to(() => const ClassesScreen(standalone: true)) : null,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: StatTile(
                            label: 'Leave pending',
                            value: '${asInt(h['pending_leave']) ?? 0}',
                            icon: AppIcons.leave,
                            color: AppColors.warning,
                            onTap: () => Get.to(() => const StaffLeaveScreen()),
                          ),
                        ),
                      ],
                    ),
                    if (h['next_lesson'] is Map) Padding(padding: const EdgeInsets.only(top: 14), child: _NextLesson(lesson: asMap(h['next_lesson']))),
                  ]),
                  const SectionTitle('Quick menu'),
                  MenuGrid(items: menu),
                  SectionTitle(
                    "Today's lessons",
                    trailing: TextButton(onPressed: () => Get.to(() => const StaffTimetableScreen()), child: const Text('Week')),
                  ),
                  if (lessons.isEmpty)
                    const AppCard(
                      child: Row(
                        children: [
                          Icon(AppIcons.timetable, color: AppColors.textMuted),
                          SizedBox(width: 12),
                          Expanded(child: Text('No lessons on your timetable today.')),
                        ],
                      ),
                    ),
                  ...FadeSlideIn.staggered([
                    for (final l in lessons) Padding(padding: const EdgeInsets.only(bottom: 8), child: _LessonTile(l)),
                  ], startMs: 200),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LessonTile extends StatelessWidget {
  const _LessonTile(this.l);
  final Lesson l;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final hm = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final live = (l.start ?? '99') .compareTo(hm) <= 0 && (l.end ?? '00').compareTo(hm) > 0;
    final past = (l.end ?? '99').compareTo(hm) <= 0;
    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      color: live ? AppColors.sky : null,
      child: Row(
        children: [
          Container(
            width: 4,
            height: 38,
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: live ? AppColors.success : (past ? AppColors.border : AppColors.blue),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          SizedBox(
            width: 64,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l.start ?? '', style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(l.end ?? '', style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l.subject ?? l.period ?? '', style: const TextStyle(fontWeight: FontWeight.w800)),
                Text([l.className, l.room].whereType<String>().join(' · '), style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
              ],
            ),
          ),
          if (live) const StatusPill('Now', color: AppColors.success) else if (past) const Icon(AppIcons.check, size: 18, color: AppColors.textMuted),
        ],
      ),
    );
  }
}

/// The next (or current) lesson, with a live countdown.
class _NextLesson extends StatelessWidget {
  const _NextLesson({required this.lesson});
  final Map<String, dynamic> lesson;

  @override
  Widget build(BuildContext context) {
    final start = asString(lesson['start_time']) ?? '';
    final end = asString(lesson['end_time']) ?? '';
    final now = DateTime.now();
    DateTime? at(String hm) {
      final p = hm.split(':');
      if (p.length < 2) return null;
      return DateTime(now.year, now.month, now.day, int.tryParse(p[0]) ?? 0, int.tryParse(p[1]) ?? 0);
    }

    final s = at(start);
    final mins = s == null ? null : s.difference(now).inMinutes;
    final inProgress = mins != null && mins <= 0;
    final when = s == null
        ? ''
        : inProgress
            ? 'In progress · ends $end'
            : mins! < 60
                ? 'Starts in $mins min'
                : 'Starts at $start';

    return AppCard(
      color: inProgress ? AppColors.success : AppColors.blue,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(14)),
            child: inProgress ? const PulseDot(size: 12) : const Icon(AppIcons.timetable, color: Colors.white),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(inProgress ? 'Now' : 'Next class', style: TextStyle(color: Colors.white.withValues(alpha: 0.8), fontSize: 12.5)),
                Text(
                  '${asString(lesson['subject']) ?? asString(lesson['period']) ?? 'Lesson'} · ${asString(lesson['class_name']) ?? ''}',
                  style: const TextStyle(color: Colors.white, fontSize: 16.5, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                Text(
                  [when, '$start – $end', asString(lesson['room'])].whereType<String>().where((x) => x.isNotEmpty).join(' · '),
                  style: TextStyle(color: Colors.white.withValues(alpha: 0.9), fontSize: 12.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
