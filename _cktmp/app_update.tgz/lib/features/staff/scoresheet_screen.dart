import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../core/network/api_exception.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/pdf_opener.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../core/widgets/motion.dart';
import '../../data/models/staff.dart';
import '../../data/repositories/school_repository.dart';
import '../student/period_picker.dart';

/// Score entry for one subject class, one column at a time: an assessment
/// (CA 1, CA 2…) or, for assessments split into parts, one part (e.g. Exam →
/// Theory / Objective). Totals, grades and positions are worked out by the
/// server with the same code as the portal and come back after each save.
class ScoresheetScreen extends StatefulWidget {
  const ScoresheetScreen({super.key, required this.assignment});

  final SubjectAssignment assignment;

  @override
  State<ScoresheetScreen> createState() => _ScoresheetScreenState();
}

class _ScoresheetScreenState extends LoadState<ScoresheetScreen, Scoresheet> {
  Assessment? _assessment;
  Assessment? _sub; // part of _assessment, when it has parts
  String _filter = '';
  bool _saving = false;

  /// Whole assessments: broadsheet id → (assessment id → score)
  final Map<int, Map<int, double>> _changes = {};

  /// Parts: assessment id → (broadsheet id → (sub-assessment id → score))
  final Map<int, Map<int, Map<int, double>>> _subChanges = {};

  final Map<String, TextEditingController> _ctrl = {};

  @override
  Future<Scoresheet> fetch() async {
    final s = await StaffRepository.scoresheet(
      widget.assignment.subjectclassId!,
      termId: widget.assignment.termId,
      sessionId: widget.assignment.sessionId,
    );
    _resetControllers();
    _pickColumn(s);
    return s;
  }

  /// Keep the chosen column after a reload if it still exists.
  void _pickColumn(Scoresheet s) {
    Assessment? a;
    for (final x in s.assessments) {
      if (x.id == _assessment?.id) a = x;
    }
    a ??= s.assessments.isNotEmpty ? s.assessments.first : null;
    _assessment = a;
    Assessment? sub;
    if (a != null && a.hasSubs) {
      for (final x in a.subs) {
        if (x.id == _sub?.id) sub = x;
      }
      sub ??= a.subs.first;
    }
    _sub = sub;
  }

  void _resetControllers() {
    // Dispose after the next frame: the fields still hold them until then.
    final old = _ctrl.values.toList();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final c in old) {
        c.dispose();
      }
    });
    _ctrl.clear();
    _changes.clear();
    _subChanges.clear();
  }

  @override
  void dispose() {
    for (final c in _ctrl.values) {
      c.dispose();
    }
    super.dispose();
  }

  // ── the current column ──────────────────────────────────────────────

  double get _max => (_sub ?? _assessment)?.maxScore ?? 0;

  String _key(ScoreRow r) => _sub != null ? '${r.broadsheetId}:${_assessment!.id}:${_sub!.id}' : '${r.broadsheetId}:${_assessment!.id}';

  double? _saved(ScoreRow r) => _sub != null ? r.subScores[_sub!.id] : r.scores[_assessment!.id];

  double? _pending(ScoreRow r) {
    if (_sub != null) {
      final byRow = _subChanges[_assessment!.id];
      final row = byRow == null ? null : byRow[r.broadsheetId];
      return row == null ? null : row[_sub!.id];
    }
    final row = _changes[r.broadsheetId];
    return row == null ? null : row[_assessment!.id];
  }

  bool _changed(ScoreRow r) => _pending(r) != null;

  TextEditingController _controllerFor(ScoreRow r) {
    return _ctrl.putIfAbsent(_key(r), () {
      final v = _pending(r) ?? _saved(r);
      return TextEditingController(text: v == null ? '' : Fmt.number(v));
    });
  }

  String? _errorFor(String text) {
    if (text.isEmpty) return null;
    final v = double.tryParse(text);
    if (v == null) return 'Number';
    if (v < 0 || v > _max) return 'Max ${Fmt.number(_max)}';
    return null;
  }

  void _onEdit(ScoreRow r, String text) {
    final v = double.tryParse(text);
    final valid = v != null && v >= 0 && v <= _max && v != _saved(r);
    final a = _assessment!.id;
    setState(() {
      if (_sub != null) {
        final byRow = _subChanges.putIfAbsent(a, () => {});
        final row = byRow.putIfAbsent(r.broadsheetId, () => {});
        if (valid) {
          row[_sub!.id] = v!;
        } else {
          row.remove(_sub!.id);
        }
        if (row.isEmpty) byRow.remove(r.broadsheetId);
        if (byRow.isEmpty) _subChanges.remove(a);
      } else {
        final row = _changes.putIfAbsent(r.broadsheetId, () => {});
        if (valid) {
          row[a] = v!;
        } else {
          row.remove(a);
        }
        if (row.isEmpty) _changes.remove(r.broadsheetId);
      }
    });
  }

  int get _changeCount {
    var n = _changes.values.fold<int>(0, (t, m) => t + m.length);
    for (final byRow in _subChanges.values) {
      n += byRow.values.fold<int>(0, (t, m) => t + m.length);
    }
    return n;
  }

  bool get _dirty => _changeCount > 0;

  Future<void> _save() async {
    final sheet = data;
    if (sheet == null || !_dirty) return;
    setState(() => _saving = true);
    try {
      Scoresheet latest = sheet;
      String? message;
      if (_changes.isNotEmpty) {
        (latest, message) = await StaffRepository.saveScores(sheet, Map.of(_changes));
      }
      for (final entry in _subChanges.entries) {
        (latest, message) = await StaffRepository.saveScores(sheet, Map.of(entry.value), subOf: entry.key);
      }
      _resetControllers();
      _pickColumn(latest);
      setState(() => data = latest);
      Toast.success(message ?? 'Scores saved.');
    } catch (e) {
      Toast.error(e);
      reload(); // show what was saved before the error
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<bool> _confirmDiscard() async {
    if (!_dirty) return true;
    return confirmDialog('Unsaved scores', 'You have $_changeCount unsaved score(s). Leave without saving?', confirm: 'Leave', danger: true);
  }

  // ── spreadsheet & printing ─────────────────────────────────────────

  String get _fileStem {
    final a = widget.assignment;
    return '${a.subject}_${a.className ?? ''}_${a.term ?? ''}_${a.session ?? ''}'.replaceAll(RegExp(r'[^A-Za-z0-9]+'), '_');
  }

  Future<void> _downloadExcel() async {
    final s = data;
    if (s == null) return;
    await FileOpener.open(StaffRepository.scoresheetExcelUrl(s), '${_fileStem}_scoresheet.xlsx',
        mime: FileOpener.xlsx, busyLabel: 'Preparing spreadsheet…');
  }

  Future<void> _shareExcel() async {
    final s = data;
    if (s == null) return;
    await FileOpener.share(StaffRepository.scoresheetExcelUrl(s), '${_fileStem}_scoresheet.xlsx', mime: FileOpener.xlsx);
  }

  Future<void> _uploadExcel() async {
    final s = data;
    if (s == null) return;
    if (_dirty && !await confirmDialog('Unsaved scores', 'Uploading a spreadsheet will discard your $_changeCount unsaved score(s). Continue?', confirm: 'Continue', danger: true)) {
      return;
    }
    final picked = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const ['xlsx', 'xls']);
    final path = picked?.files.single.path;
    if (path == null) return;

    setState(() => _saving = true);
    try {
      final (sheet, message, warnings) = await StaffRepository.importScoresheet(s, path);
      _resetControllers();
      _pickColumn(sheet);
      setState(() => data = sheet);
      if (warnings.isEmpty) {
        Toast.success(message ?? 'Spreadsheet imported.');
      } else {
        _showWarnings(message ?? 'Imported with warnings', warnings);
      }
    } catch (e) {
      final rows = _rowErrors(e);
      if (rows.isNotEmpty) {
        _showWarnings(e is ApiException ? e.message : '$e', rows, failed: true);
      } else {
        Toast.error(e);
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  List<String> _rowErrors(Object e) => e is ApiException ? (e.errors['rows'] ?? const <String>[]) : const <String>[];

  void _showWarnings(String title, List<String> lines, {bool failed = false}) {
    Get.bottomSheet(
      Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.7),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(failed ? AppIcons.close : AppIcons.warning, color: failed ? AppColors.danger : AppColors.warning),
                const SizedBox(width: 10),
                Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
              ],
            ),
            const SizedBox(height: 6),
            Text(failed ? 'Fix these rows in the spreadsheet and upload it again.' : 'These rows were skipped; everything else was saved.',
                style: const TextStyle(color: AppColors.textMuted)),
            const SizedBox(height: 12),
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: lines.length,
                separatorBuilder: (_, __) => const Divider(height: 14),
                itemBuilder: (_, i) => Text(lines[i], style: const TextStyle(fontSize: 13.5)),
              ),
            ),
          ],
        ),
      ),
      isScrollControlled: true,
    );
  }

  void _openTools() {
    final s = data;
    if (s == null) return;
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: FadeSlideIn.staggered([
              Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4))),
              _tool(AppIcons.download, AppColors.success, 'Download Excel sheet', 'Fill scores offline in Excel or Google Sheets', () {
                Get.back();
                _downloadExcel();
              }),
              _tool(AppIcons.upload, AppColors.blue, 'Upload filled Excel sheet',
                  s.editable ? 'Import the scores from the downloaded template' : (s.lockMessage ?? 'This score sheet is locked'),
                  s.editable
                      ? () {
                          Get.back();
                          _uploadExcel();
                        }
                      : null),
              _tool(AppIcons.message, AppColors.info, 'Share the Excel sheet', 'Send the template to your computer or e-mail', () {
                Get.back();
                _shareExcel();
              }),
              _tool(AppIcons.printer, AppColors.navy, 'Marks sheet (PDF)', 'Printable list of all scores', () {
                Get.back();
                PdfOpener.open(StaffRepository.marksheetUrl(s), '${_fileStem}_marksheet.pdf');
              }),
              _tool(AppIcons.refresh, AppColors.warning, 'Recalculate positions', 'Refresh totals, grades and positions', () async {
                Get.back();
                try {
                  final fresh = await StaffRepository.scoresheet(s.subjectclassId, termId: s.termId, sessionId: s.sessionId, recalculate: true);
                  _resetControllers();
                  _pickColumn(fresh);
                  setState(() => data = fresh);
                  Toast.success('Positions recalculated.');
                } catch (e) {
                  Toast.error(e);
                }
              }),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _tool(IconData icon, Color color, String title, String subtitle, VoidCallback? onTap) {
    return ListTile(
      enabled: onTap != null,
      onTap: onTap,
      leading: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: color.withValues(alpha: onTap == null ? 0.05 : 0.12), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: onTap == null ? AppColors.textMuted : color, size: 20),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12.5)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = data;
    final a = _assessment;
    final rows = (s?.rows ?? const <ScoreRow>[])
        .where((r) => _filter.isEmpty || r.name.toLowerCase().contains(_filter) || (r.admissionNo ?? '').toLowerCase().contains(_filter))
        .toList();

    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final nav = Navigator.of(context);
        if (await _confirmDiscard()) {
          _changes.clear();
          _subChanges.clear();
          nav.pop();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.assignment.subject, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              Text('${widget.assignment.className ?? ''} · ${widget.assignment.term ?? ''}',
                  style: TextStyle(fontSize: 12.5, color: Colors.white.withValues(alpha: 0.8))),
            ],
          ),
          actions: [
            if (s != null)
              IconButton(tooltip: 'Excel & printing', onPressed: _saving ? null : _openTools, icon: const Icon(AppIcons.excel)),
          ],
        ),
        bottomNavigationBar: (s != null && s.editable)
            ? SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: BusyButton(
                    label: !_dirty ? 'No changes' : 'Save $_changeCount score${_changeCount == 1 ? '' : 's'}',
                    busy: _saving,
                    icon: AppIcons.save,
                    onPressed: _dirty ? _save : null,
                  ),
                ),
              )
            : null,
        body: AsyncBody(
          loading: loading,
          error: error,
          onRetry: load,
          isEmpty: s != null && s.rows.isEmpty,
          emptyIcon: AppIcons.scores,
          emptyTitle: 'No students on this score sheet',
          emptyMessage: 'Students appear here once they are registered for the subject.',
          child: (s == null)
              ? const SizedBox()
              : Column(
                  children: [
                    Container(
                      color: Colors.white,
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (!s.editable)
                            Container(
                              margin: const EdgeInsets.only(bottom: 10),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(color: AppColors.warning.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                              child: Row(
                                children: [
                                  const Icon(AppIcons.lock, color: AppColors.warning, size: 18),
                                  const SizedBox(width: 8),
                                  Expanded(child: Text(s.lockMessage ?? 'This score sheet is locked.')),
                                ],
                              ),
                            ),
                          ChoiceRow<Assessment>(
                            items: s.assessments,
                            selected: a,
                            label: (x) => '${x.name} (${Fmt.number(x.maxScore)})',
                            same: (x, y) => x.id == y.id,
                            onSelected: (x) => setState(() {
                              _assessment = x;
                              _sub = x.hasSubs ? x.subs.first : null;
                            }),
                          ),
                          if (a != null && a.hasSubs) ...[
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Text('Part:', style: TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w600)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: ChoiceRow<Assessment>(
                                    items: a.subs,
                                    selected: _sub,
                                    label: (x) => '${x.name} (${Fmt.number(x.maxScore)})',
                                    same: (x, y) => x.id == y.id,
                                    onSelected: (x) => setState(() => _sub = x),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${a.name} is worked out from its parts and scaled to ${Fmt.number(a.maxScore)}.',
                              style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                            ),
                          ],
                          const SizedBox(height: 10),
                          _Summary(sheet: s, assessment: a, sub: _sub, onExcel: _openTools),
                          const SizedBox(height: 10),
                          TextField(
                            onChanged: (v) => setState(() => _filter = v.trim().toLowerCase()),
                            decoration: const InputDecoration(hintText: 'Find a student', prefixIcon: Icon(AppIcons.search), isDense: true),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                        itemCount: rows.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, i) => i < 14 ? FadeSlideIn(delay: Duration(milliseconds: 30 * i), child: _row(rows[i], s.editable)) : _row(rows[i], s.editable),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _row(ScoreRow r, bool sheetEditable) {
    final a = _assessment;
    final editable = sheetEditable && !r.locked && a != null;
    final ctrl = a == null ? null : _controllerFor(r);
    final changed = a != null && _changed(r);

    // For a part, also show the whole assessment's current (scaled) score.
    final whole = (a != null && a.hasSubs) ? r.scores[a.id] : null;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      color: changed ? AppColors.sky : Colors.white,
      child: Row(
        children: [
          PersonAvatar(name: r.name, url: r.photoUrl, size: 38),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                Text(
                  'Total ${Fmt.number(r.total)} · ${r.grade ?? '—'}${r.position != null ? ' · ${Fmt.ordinal(r.position)}' : ''}'
                  '${whole != null ? ' · ${a!.name} ${Fmt.number(whole)}' : ''}',
                  style: TextStyle(color: AppColors.grade(r.grade), fontSize: 12.5, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 86,
            child: ctrl == null
                ? const SizedBox()
                : TextField(
                    key: ValueKey(_key(r)),
                    controller: ctrl,
                    enabled: editable,
                    textAlign: TextAlign.center,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    textInputAction: TextInputAction.next,
                    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                    onChanged: (t) => _onEdit(r, t),
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: '—',
                      errorText: _errorFor(ctrl.text),
                      errorStyle: const TextStyle(fontSize: 10.5),
                      contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

/// Entry progress for the selected column, with a shortcut to Excel tools.
class _Summary extends StatelessWidget {
  const _Summary({required this.sheet, required this.assessment, required this.sub, required this.onExcel});

  final Scoresheet sheet;
  final Assessment? assessment;
  final Assessment? sub;
  final VoidCallback onExcel;

  @override
  Widget build(BuildContext context) {
    final a = assessment;
    final total = sheet.rows.length;
    final entered = a == null
        ? 0
        : sheet.rows.where((r) => sub != null ? r.subScores[sub!.id] != null : r.scores[a.id] != null).length;
    final totals = sheet.rows.map((r) => r.total).whereType<double>().where((t) => t > 0).toList();
    final avg = totals.isEmpty ? null : totals.reduce((x, y) => x + y) / totals.length;
    final ratio = total == 0 ? 0.0 : entered / total;

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$entered of $total entered${avg == null ? '' : ' · class avg ${Fmt.number(avg)}'}',
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.textMuted)),
              const SizedBox(height: 6),
              AnimatedBar(value: ratio, color: ratio >= 1 ? AppColors.success : AppColors.blue, height: 6),
            ],
          ),
        ),
        const SizedBox(width: 12),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(minimumSize: const Size(0, 36), padding: const EdgeInsets.symmetric(horizontal: 12)),
          onPressed: onExcel,
          icon: const Icon(AppIcons.excel, size: 18),
          label: const Text('Excel'),
        ),
      ],
    );
  }
}
