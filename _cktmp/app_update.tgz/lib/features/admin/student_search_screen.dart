import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/json.dart';
import '../../core/widgets/common.dart';
import '../../data/repositories/school_repository.dart';
import '../student/student_hub_screen.dart';

/// Find a student by name or admission number and open their page.
class StudentSearchScreen extends StatefulWidget {
  const StudentSearchScreen({super.key});

  @override
  State<StudentSearchScreen> createState() => _StudentSearchScreenState();
}

class _StudentSearchScreenState extends State<StudentSearchScreen> {
  final _q = TextEditingController();
  Timer? _debounce;
  List<Map<String, dynamic>> _results = [];
  bool _busy = false;
  Object? _error;

  @override
  void dispose() {
    _debounce?.cancel();
    _q.dispose();
    super.dispose();
  }

  void _changed(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () => _search(v.trim()));
  }

  Future<void> _search(String q) async {
    if (q.length < 2) {
      setState(() => _results = []);
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final r = await AdminRepository.searchStudents(q);
      if (mounted && _q.text.trim() == q) setState(() => _results = r);
    } catch (e) {
      if (mounted) setState(() => _error = e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Students')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _q,
              autofocus: false,
              onChanged: _changed,
              decoration: InputDecoration(
                hintText: 'Name or admission number',
                prefixIcon: const Icon(AppIcons.search),
                suffixIcon: _busy ? const Padding(padding: EdgeInsets.all(14), child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))) : null,
              ),
            ),
          ),
          Expanded(
            child: _error != null
                ? ErrorState(error: _error!, onRetry: () => _search(_q.text.trim()))
                : _results.isEmpty
                    ? EmptyState(
                        icon: AppIcons.people,
                        title: _q.text.trim().length < 2 ? 'Search for a student' : 'No student found',
                        message: _q.text.trim().length < 2 ? 'Type at least two letters of a name or admission number.' : null,
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        itemCount: _results.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final s = _results[i];
                          final name = asString(s['full_name']) ?? '';
                          return AppCard(
                            padding: const EdgeInsets.all(12),
                            onTap: () => Get.to(() => StudentHubScreen(studentId: asInt(s['id']) ?? 0)),
                            child: Row(
                              children: [
                                PersonAvatar(name: name, url: asString(s['photo_url'])),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
                                      Text([asString(s['class_name']), asString(s['admission_no'])].whereType<String>().join(' · '),
                                          style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                                    ],
                                  ),
                                ),
                                const Icon(AppIcons.arrow, size: 18, color: AppColors.textMuted),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
