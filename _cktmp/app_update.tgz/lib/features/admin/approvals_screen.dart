import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/staff.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import '../auth/auth_controller.dart';

class _Queues {
  _Queues(this.staff, this.students);
  final List<StaffLeave> staff;
  final List<StudentLeave> students;
}

/// Leave requests waiting for this user: staff leave and student leave.
class ApprovalsScreen extends StatefulWidget {
  const ApprovalsScreen({super.key});

  @override
  State<ApprovalsScreen> createState() => _ApprovalsScreenState();
}

class _ApprovalsScreenState extends LoadState<ApprovalsScreen, _Queues> {
  @override
  Future<_Queues> fetch() async {
    final u = AuthController.to.user.value;
    final staff = (u?.can('leave.approve') ?? false) ? await AdminRepository.pendingStaffLeave() : <StaffLeave>[];
    final students = (u?.can('student_leave.approve') ?? false) ? await AdminRepository.pendingStudentLeave() : <StudentLeave>[];
    return _Queues(staff, students);
  }

  Future<void> _decide({required bool approve, required Future<String> Function(String? note) send}) async {
    final note = await _askNote(approve);
    if (note == null) return; // cancelled
    try {
      Toast.success(await send(note.isEmpty ? null : note));
      reload();
    } catch (e) {
      Toast.error(e);
    }
  }

  /// Returns the note ('' for none), or null if cancelled.
  Future<String?> _askNote(bool approve) async {
    final c = TextEditingController();
    final res = await Get.dialog<String>(AlertDialog(
      title: Text(approve ? 'Approve request' : 'Decline request'),
      content: TextField(
        controller: c,
        minLines: 2,
        maxLines: 4,
        decoration: InputDecoration(labelText: approve ? 'Note (optional)' : 'Reason for declining'),
      ),
      actions: [
        TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
        TextButton(
          onPressed: () {
            if (!approve && c.text.trim().isEmpty) {
              Toast.error('Please give a reason when declining.');
              return;
            }
            Get.back(result: c.text.trim());
          },
          child: Text(approve ? 'Approve' : 'Decline', style: TextStyle(color: approve ? AppColors.success : AppColors.danger, fontWeight: FontWeight.w800)),
        ),
      ],
    ));
    WidgetsBinding.instance.addPostFrameCallback((_) => c.dispose());
    return res;
  }

  @override
  Widget build(BuildContext context) {
    final q = data;
    final empty = q != null && q.staff.isEmpty && q.students.isEmpty;
    return Scaffold(
      appBar: AppBar(title: const Text('Approvals')),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: empty,
        emptyIcon: AppIcons.approvals,
        emptyTitle: 'Nothing waiting for you',
        emptyMessage: 'Leave requests that need your decision will show here.',
        child: q == null
            ? const SizedBox()
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (q.staff.isNotEmpty) const SectionTitle('Staff leave'),
                  for (final l in q.staff) ...[
                    _Card(
                      title: l.staffName ?? 'Staff',
                      subtitle: '${l.type ?? ''} · ${Fmt.dateStr(l.startDate)} – ${Fmt.dateStr(l.endDate)} · ${Fmt.number(l.days)} day(s)',
                      body: l.reason,
                      extra: [
                        if (l.department != null) 'Dept: ${l.department}',
                        if (l.remaining != null) '${Fmt.number(l.remaining)} day(s) left',
                      ].join(' · '),
                      stage: l.stage == 'recommend' ? 'Recommend' : 'Approve',
                      onApprove: () => _decide(approve: true, send: (n) => AdminRepository.decideStaffLeave(l.id, true, n)),
                      onDecline: () => _decide(approve: false, send: (n) => AdminRepository.decideStaffLeave(l.id, false, n)),
                    ),
                    const SizedBox(height: 10),
                  ],
                  if (q.students.isNotEmpty) const SectionTitle('Student leave'),
                  for (final l in q.students) ...[
                    _Card(
                      title: l.studentName ?? 'Student',
                      subtitle: '${l.reasonLabel ?? ''} · ${Fmt.dateStr(l.startDate)} – ${Fmt.dateStr(l.endDate)} · ${l.days} day(s)',
                      body: l.reason,
                      extra: l.className ?? '',
                      stage: l.stage == 'recommend' ? 'Recommend' : 'Approve',
                      onApprove: () => _decide(approve: true, send: (n) => AdminRepository.decideStudentLeave(l.id, true, n)),
                      onDecline: () => _decide(approve: false, send: (n) => AdminRepository.decideStudentLeave(l.id, false, n)),
                    ),
                    const SizedBox(height: 10),
                  ],
                ],
              ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.title, required this.subtitle, this.body, required this.extra, required this.stage, required this.onApprove, required this.onDecline});

  final String title;
  final String subtitle;
  final String? body;
  final String extra;
  final String stage;
  final VoidCallback onApprove;
  final VoidCallback onDecline;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5))),
              StatusPill('To ${stage.toLowerCase()}', color: AppColors.warning),
            ],
          ),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
          if (extra.isNotEmpty) Text(extra, style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
          if (body != null) ...[const SizedBox(height: 8), Text(body!)],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: onDecline,
                  style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger, minimumSize: const Size.fromHeight(42)),
                  child: const Text('Decline'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: onApprove,
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, minimumSize: const Size.fromHeight(42)),
                  child: Text(stage),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
