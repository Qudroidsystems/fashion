import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/json.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/repositories/school_repository.dart';
import '../auth/auth_controller.dart';
import '../common/inbox_screen.dart';

/// Management overview: enrolment, today's attendance, fees, results and
/// things that need attention (same figures as the portal's dashboard).
class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends LoadState<AdminDashboardScreen, Map<String, dynamic>> {
  bool _refresh = false;

  @override
  Future<Map<String, dynamic>> fetch() async {
    final d = await AdminRepository.dashboard(refresh: _refresh);
    _refresh = false;
    // The fee figures are worked out in the background the first time.
    if (!asBool(d['fees_ready'])) {
      Future<void>.delayed(const Duration(seconds: 20), () {
        if (mounted) reload();
      });
    }
    return d;
  }

  @override
  Widget build(BuildContext context) {
    final d = data ?? const <String, dynamic>{};
    final enrol = asMap(d['enrolment']);
    final att = asMap(d['attendance']);
    final fees = asMap(asMap(d['fees'])['totals']);
    final res = asMap(d['results']);
    final msg = asMap(d['messaging']);
    final actions = asMapList(d['actions']);
    final collections = asMapList(d['collections']);
    final school = AuthController.to.school.value;

    return Scaffold(
      appBar: AppBar(
        title: const Text('School overview'),
        actions: [
          IconButton(onPressed: () => Get.to(() => const InboxScreen(standalone: true)), icon: const Icon(AppIcons.bell)),
        ],
      ),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (school?.currentTerm != null)
              Text('${school!.currentTerm} · ${school.currentSession ?? ''}', style: const TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w600)),
            if (actions.isNotEmpty) ...[
              const SectionTitle('Needs attention'),
              for (final a in actions)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: AppCard(
                    padding: const EdgeInsets.all(12),
                    color: _levelColor(asString(a['level'])).withValues(alpha: 0.06),
                    child: Row(
                      children: [
                        Icon(AppIcons.warning, color: _levelColor(asString(a['level']))),
                        const SizedBox(width: 10),
                        Expanded(child: Text(asString(a['text']) ?? '', style: const TextStyle(fontWeight: FontWeight.w600))),
                      ],
                    ),
                  ),
                ),
            ],
            const SectionTitle('Students'),
            _grid([
              StatTile(label: 'Active students', value: Fmt.number(asInt(enrol['active'])), icon: AppIcons.people, color: AppColors.navy),
              StatTile(label: 'New (30 days)', value: Fmt.number(asInt(enrol['new30'])), icon: AppIcons.add, color: AppColors.blue),
              StatTile(label: 'Boys / Girls', value: '${asInt(enrol['male']) ?? 0} / ${asInt(enrol['female']) ?? 0}', icon: AppIcons.user, color: AppColors.info),
              StatTile(label: 'Staff', value: Fmt.number(asInt(enrol['staff'])), icon: AppIcons.leave, color: AppColors.warning),
            ]),
            const SectionTitle("Today's attendance"),
            _grid([
              StatTile(label: 'Attendance rate', value: Fmt.percent(asDouble(att['rate'])), icon: AppIcons.attendance, color: AppColors.success),
              StatTile(label: 'Classes marked', value: '${asInt(att['marked_classes']) ?? 0} / ${asInt(att['classes']) ?? 0}', icon: AppIcons.register, color: AppColors.navy),
              StatTile(label: 'Absent', value: Fmt.number(asInt(att['absent'])), icon: AppIcons.close, color: AppColors.danger),
              StatTile(
                label: 'Staff present',
                value: att['staff_total'] == null ? '—' : '${asInt(att['staff_present']) ?? 0} / ${asInt(att['staff_total'])}',
                icon: AppIcons.leave,
                color: AppColors.info,
              ),
            ]),
            SectionTitle(
              'Fees this term',
              trailing: asBool(d['fees_ready'])
                  ? TextButton(
                      onPressed: () {
                        _refresh = true;
                        reload();
                        Toast.info('Recalculating fee figures — this can take a minute.');
                      },
                      child: const Text('Recalculate'),
                    )
                  : null,
            ),
            if (!asBool(d['fees_ready']))
              const AppCard(
                child: Row(
                  children: [
                    SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                    SizedBox(width: 12),
                    Expanded(child: Text('Working out the fee figures… they will appear shortly.')),
                  ],
                ),
              )
            else
              _grid([
                StatTile(label: 'Expected', value: Fmt.nairaShort(asDouble(fees['payable'])), icon: AppIcons.fees, color: AppColors.navy),
                StatTile(label: 'Collected', value: Fmt.nairaShort(asDouble(fees['paid'])), icon: AppIcons.check, color: AppColors.success),
                StatTile(label: 'Outstanding', value: Fmt.nairaShort(asDouble(fees['outstanding'])), icon: AppIcons.warning, color: AppColors.danger),
                StatTile(label: 'Students owing', value: Fmt.number(asInt(fees['debtors'])), icon: AppIcons.people, color: AppColors.warning),
              ]),
            if (collections.isNotEmpty) ...[
              const SectionTitle('Collections — last 14 days'),
              AppCard(child: _Bars(collections)),
            ],
            const SectionTitle('Results'),
            _grid([
              StatTile(label: 'Scores vetted', value: '${asInt(res['pct']) ?? 0}%', icon: AppIcons.results, color: AppColors.blue),
              StatTile(label: 'Classes approved', value: Fmt.number(asInt(res['approved'])), icon: AppIcons.approvals, color: AppColors.success),
              StatTile(label: 'Awaiting approval', value: Fmt.number(asInt(res['submitted'])), icon: AppIcons.info, color: AppColors.warning),
              StatTile(label: 'Returned', value: Fmt.number(asInt(res['returned'])), icon: AppIcons.refresh, color: AppColors.danger),
            ]),
            const SectionTitle('Messages (7 days)'),
            _grid([
              StatTile(label: 'Sent', value: Fmt.number(asInt(msg['sent'])), icon: AppIcons.sms, color: AppColors.success),
              StatTile(label: 'Failed', value: Fmt.number(asInt(msg['failed'])), icon: AppIcons.warning, color: AppColors.danger),
            ]),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  static Color _levelColor(String? level) {
    switch (level) {
      case 'danger':
        return AppColors.danger;
      case 'warning':
        return AppColors.warning;
      case 'success':
        return AppColors.success;
      default:
        return AppColors.info;
    }
  }

  Widget _grid(List<Widget> tiles) => GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.45,
        children: tiles,
      );
}

/// Small bar chart of daily collections.
class _Bars extends StatelessWidget {
  const _Bars(this.days);
  final List<Map<String, dynamic>> days;

  @override
  Widget build(BuildContext context) {
    final values = days.map((d) => asDouble(d['amount']) ?? 0).toList();
    final maxV = values.fold<double>(0, math.max);
    final total = values.fold<double>(0, (a, b) => a + b);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Total ${Fmt.naira(total)}', style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        SizedBox(
          height: 110,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < days.length; i++)
                Expanded(
                  child: Tooltip(
                    message: '${asString(days[i]['label']) ?? ''}: ${Fmt.naira(values[i])}',
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      height: maxV <= 0 ? 2.0 : math.max(2.0, 100 * values[i] / maxV),
                      decoration: BoxDecoration(color: AppColors.blue, borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(asString(days.first['label']) ?? '', style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
            Text(asString(days.last['label']) ?? '', style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
          ],
        ),
      ],
    );
  }
}
