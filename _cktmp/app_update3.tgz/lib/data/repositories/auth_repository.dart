import 'dart:io';

import 'package:package_info_plus/package_info_plus.dart';

import '../../core/config/app_config.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_exception.dart';
import '../../core/storage/session_store.dart';
import '../../core/utils/json.dart';
import '../models/user.dart';

class AuthRepository {
  AuthRepository._();

  static const _notPortal = 'That address is not a Vite Schools portal, or the school has not switched the app on yet. Check the address with the school.';

  /// Checks a school's portal address typed by the user and returns the
  /// working base URL with the school's details. Nothing is saved yet.
  static Future<(String, SchoolInfo, Map<String, dynamic>)> findSchool(String input) async {
    final base = AppConfig.normalize(input);
    if (base.isEmpty || (!base.contains('.') && !base.contains('localhost'))) {
      throw const ApiException("Enter your school's portal address, for example portal.myschool.com");
    }
    final candidates = <String>[base];
    // Typed without http(s)://: also try plain http (e.g. a school's local server).
    if (!input.trim().toLowerCase().startsWith('http')) candidates.add(base.replaceFirst('https://', 'http://'));

    ApiException? last;
    for (final c in candidates) {
      try {
        final res = await ApiClient.getUrl(Uri.parse('$c/api/v1/school'));
        final map = res.map;
        if (map['api_version'] == null || map['name'] == null) throw const ApiException(_notPortal);
        // Portals made before score_model existed are CSS Kabba-type ('dynamic').
        if ((asString(map['score_model']) ?? 'dynamic') != AppConfig.scoreModel) {
          throw ApiException(AppConfig.wrongPortalMessage(asString(map['name'])), code: 'wrong_app');
        }
        return (c, SchoolInfo.fromJson(map), map);
      } on ApiException catch (e) {
        last = (e.statusCode == 404 || e.statusCode == 405) ? const ApiException(_notPortal, code: 'not_portal') : e;
      } on FormatException {
        last = const ApiException(_notPortal, code: 'not_portal');
      }
    }
    throw last ?? const ApiException(_notPortal);
  }

  /// Saves the chosen school; the app talks to it from now on.
  static Future<void> useSchool(String url, Map<String, dynamic> info) async {
    await SessionStore.clear();
    await SessionStore.setSchoolUrl(url);
    await SessionStore.setSchool(info);
    await SessionStore.rememberSchool(url, asString(info['name']) ?? url, asString(info['logo_url']));
  }

  static Future<SchoolInfo> school() async {
    final map = (await ApiClient.get('/school')).map;
    await SessionStore.setSchool(map);
    return SchoolInfo.fromJson(map);
  }

  /// E-mail or phone number + password. Saves the token on success.
  static Future<AppUser> login(String login, String password) async {
    String? version;
    try {
      version = (await PackageInfo.fromPlatform()).version;
    } catch (_) {}

    final res = await ApiClient.post('/auth/login', body: {
      'login': login.trim(),
      'password': password,
      'device_name': _deviceName(),
      'platform': Platform.isIOS ? 'ios' : 'android',
      if (version != null) 'app_version': version,
    });
    return _saveSession(res.map);
  }

  static Future<AppUser> me() async {
    final user = AppUser.fromJson((await ApiClient.get('/auth/me')).map);
    await SessionStore.setUser(user.raw);
    return user;
  }

  static Future<void> logout() async {
    try {
      await ApiClient.post('/auth/logout');
    } catch (_) {
      // Signing out locally is enough if the server cannot be reached.
    }
    await SessionStore.clear();
  }

  static Future<AppUser> changePassword({String? current, required String password, required String confirm}) async {
    final res = await ApiClient.put('/auth/password', body: {
      if (current != null && current.isNotEmpty) 'current_password': current,
      'password': password,
      'password_confirmation': confirm,
    });
    final user = AppUser.fromJson(res.map);
    await SessionStore.setUser(user.raw);
    return user;
  }

  static Future<String> forgotPassword(String phone) async {
    final res = await ApiClient.post('/auth/forgot-password', body: {'phone': phone.trim()});
    return res.message ?? 'If that number belongs to a parent account, a reset code has been sent to it.';
  }

  static Future<AppUser> resetPassword({required String phone, required String code, required String password, required String confirm}) async {
    final res = await ApiClient.post('/auth/reset-password', body: {
      'phone': phone.trim(),
      'code': code.trim(),
      'password': password,
      'password_confirmation': confirm,
      'device_name': _deviceName(),
    });
    return _saveSession(res.map);
  }

  static Future<AppUser> _saveSession(Map<String, dynamic> data) async {
    await SessionStore.setToken(asString(data['token']));
    final user = AppUser.fromJson(asMap(data['user']));
    await SessionStore.setUser(user.raw);
    return user;
  }

  static String _deviceName() {
    try {
      final name = '${Platform.operatingSystem} ${Platform.operatingSystemVersion}';
      return name.length > 60 ? name.substring(0, 60) : name;
    } catch (_) {
      return 'Mobile app';
    }
  }
}
