import '../../core/utils/formatters.dart';
import '../../core/utils/json.dart';
import 'user.dart';

/// A child (parent view) or the student themself (GET /students).
class StudentCard {
  StudentCard({
    required this.id,
    required this.fullName,
    required this.firstName,
    this.admissionNo,
    this.relationship,
    this.classId,
    this.className,
    this.termId,
    this.sessionId,
    this.photoUrl,
    this.feeBalance,
    this.attendanceRate,
    this.daysAbsent = 0,
    this.latestResultLabel,
    this.profile = const {},
  });

  final int id;
  final String fullName;
  final String firstName;
  final String? admissionNo;
  final String? relationship;
  final int? classId;
  final String? className;
  final int? termId;
  final int? sessionId;
  final String? photoUrl;
  final double? feeBalance;
  final double? attendanceRate;
  final int daysAbsent;
  final String? latestResultLabel;
  final Map<String, dynamic> profile;

  bool get isSelf => relationship == 'self';

  factory StudentCard.fromJson(Map<String, dynamic> j) {
    final s = asMap(j['summary']);
    final latest = asMap(s['latest_result']);
    return StudentCard(
      id: asInt(j['id']) ?? 0,
      fullName: asString(j['full_name']) ?? '${j['first_name'] ?? ''} ${j['last_name'] ?? ''}'.trim(),
      firstName: asString(j['first_name']) ?? '',
      admissionNo: asString(j['admission_no']),
      relationship: asString(j['relationship']),
      classId: asInt(j['class_id']),
      className: asString(j['class_name']),
      termId: asInt(j['term_id']),
      sessionId: asInt(j['session_id']),
      photoUrl: asString(j['photo_url']),
      feeBalance: asDouble(s['fee_balance']),
      attendanceRate: asDouble(s['attendance_rate']),
      daysAbsent: asInt(s['days_absent']) ?? 0,
      latestResultLabel: asString(latest['label']),
      profile: asMap(j['profile']),
    );
  }
}

// ── Results ───────────────────────────────────────────────────────────────

class ResultTerm {
  ResultTerm({
    required this.sessionId,
    required this.session,
    required this.termId,
    required this.term,
    required this.classId,
    this.className,
    this.subjects = 0,
    this.average,
    this.ready = false,
    this.allowed = false,
    this.notReleased = false,
    this.holdMessage,
    this.amountOwed = 0,
  });

  final int sessionId;
  final String session;
  final int termId;
  final String term;
  final int classId;
  final String? className;
  final int subjects;
  final double? average;
  final bool ready;
  final bool allowed;
  final bool notReleased;
  final String? holdMessage;
  final double amountOwed;

  String get label => '$term · $session';

  bool sameAs(ResultTerm o) => o.termId == termId && o.sessionId == sessionId;

  factory ResultTerm.fromJson(Map<String, dynamic> j) => ResultTerm(
        sessionId: asInt(j['session_id']) ?? 0,
        session: asString(j['session']) ?? '',
        termId: asInt(j['term_id']) ?? 0,
        term: asString(j['term']) ?? '',
        classId: asInt(j['class_id']) ?? 0,
        className: asString(j['class_name']),
        subjects: asInt(j['subjects']) ?? 0,
        average: asDouble(j['average']),
        ready: asBool(j['ready']),
        allowed: asBool(j['allowed']),
        notReleased: asBool(j['not_released']),
        holdMessage: asString(j['hold_message']),
        amountOwed: asDouble(j['amount_owed']) ?? 0,
      );
}

class SubjectScore {
  SubjectScore({
    required this.subject,
    this.code,
    this.parts = const [],
    this.total,
    this.bf,
    this.cum,
    this.cumAverage,
    this.grade,
    this.remark,
    this.position,
    this.positionTotal,
    this.armPosition,
    this.armPositionCum,
    this.classAverage,
    this.highest,
    this.lowest,
  });

  final String subject;
  final String? code;
  final List<ScorePart> parts;
  final double? total;
  final double? bf;
  final double? cum;
  final double? cumAverage;
  final String? grade;
  final String? remark;

  /// Subject position in the class (all arms), e.g. "2nd".
  final String? position;
  final String? positionTotal;
  final String? armPosition;
  final String? armPositionCum;
  final double? classAverage;
  final double? highest;
  final double? lowest;

  factory SubjectScore.fromJson(Map<String, dynamic> j) => SubjectScore(
        subject: asString(j['subject']) ?? '',
        code: asString(j['subject_code']),
        parts: asMapList(j['assessments'])
            .map((p) => ScorePart(asString(p['name']) ?? '', asDouble(p['score']), asDouble(p['max_score'])))
            .toList(),
        total: asDouble(j['total']),
        bf: asDouble(j['bf']),
        cum: asDouble(j['cum']),
        cumAverage: asDouble(j['cum_average']),
        grade: asString(j['grade']),
        remark: asString(j['remark']),
        position: asString(j['position_label']) ?? (j['position'] == null ? null : Fmt.ordinal(j['position'])),
        positionTotal: asString(j['position_total']),
        armPosition: asString(j['arm_position']),
        armPositionCum: asString(j['arm_position_cum']),
        classAverage: asDouble(j['class_average']),
        highest: asDouble(j['highest']),
        lowest: asDouble(j['lowest']),
      );
}

class ScorePart {
  const ScorePart(this.name, this.score, this.max);
  final String name;
  final double? score;
  final double? max;
}

/// What the school shows parents and students (Admin → Result display on the portal).
/// Older portals don't send it: then everything the server sent is shown.
class ResultDisplay {
  const ResultDisplay({this.subject = const {}, this.summary = const {}, this.known = false, this.positionBasis = 'cum'});

  final Map<String, bool> subject;
  final Map<String, bool> summary;
  final bool known;
  final String positionBasis;

  bool sub(String key) => !known || (subject[key] ?? false);
  bool sum(String key) => !known || (summary[key] ?? false);

  factory ResultDisplay.fromJson(dynamic raw) {
    if (raw is! Map) return const ResultDisplay();
    final j = asMap(raw);
    Map<String, bool> flags(dynamic m) => asMap(m).map((k, v) => MapEntry(k, v == true || v == 1 || v == '1'));
    return ResultDisplay(
      subject: flags(j['subject']),
      summary: flags(j['summary']),
      known: true,
      positionBasis: asString(j['position_basis']) ?? 'cum',
    );
  }
}

/// Totals, averages and overall positions for one term.
class ResultSummary {
  const ResultSummary({
    this.termTotal,
    this.termAverage,
    this.cumAverage,
    this.gpa,
    this.classPosition,
    this.classSize,
    this.armPosition,
    this.armSize,
    this.className,
  });

  final double? termTotal;
  final double? termAverage;
  final double? cumAverage;
  final double? gpa;
  final String? classPosition;
  final int? classSize;
  final String? armPosition;
  final int? armSize;
  final String? className;

  factory ResultSummary.fromJson(Map<String, dynamic> j) => ResultSummary(
        termTotal: asDouble(j['term_total']),
        termAverage: asDouble(j['term_average']),
        cumAverage: asDouble(j['cum_average']),
        gpa: asDouble(j['gpa']),
        classPosition: asString(j['class_position_label']),
        classSize: asInt(j['class_size']),
        armPosition: asString(j['arm_position_label']),
        armSize: asInt(j['arm_size']),
        className: asString(j['class_name']),
      );
}

class TermResult {
  TermResult({
    this.subjects = const [],
    this.totalScore,
    this.average,
    this.summary = const ResultSummary(),
    this.display = const ResultDisplay(),
    this.timesAbsent,
    this.classTeacherComment,
    this.principalComment,
    this.reportCardUrl,
  });

  final List<SubjectScore> subjects;
  final double? totalScore;
  final double? average;
  final ResultSummary summary;
  final ResultDisplay display;
  final int? timesAbsent;
  final String? classTeacherComment;
  final String? principalComment;
  final String? reportCardUrl;

  factory TermResult.fromJson(Map<String, dynamic> j) => TermResult(
        subjects: asMapList(j['subjects']).map(SubjectScore.fromJson).toList(),
        totalScore: asDouble(j['total_score']),
        average: asDouble(j['average']),
        summary: j['summary'] is Map ? ResultSummary.fromJson(asMap(j['summary'])) : const ResultSummary(),
        display: ResultDisplay.fromJson(j['display']),
        timesAbsent: asInt(j['times_absent']),
        classTeacherComment: asString(j['class_teacher_comment']),
        principalComment: asString(j['principal_comment']),
        reportCardUrl: asString(j['report_card_url']),
      );
}

class ResultsPage {
  ResultsPage({this.terms = const [], this.selected, this.result});

  final List<ResultTerm> terms;
  final ResultTerm? selected;
  final TermResult? result;

  factory ResultsPage.fromJson(Map<String, dynamic> j) => ResultsPage(
        terms: asMapList(j['terms']).map(ResultTerm.fromJson).toList(),
        selected: j['selected'] is Map ? ResultTerm.fromJson(asMap(j['selected'])) : null,
        result: j['result'] is Map ? TermResult.fromJson(asMap(j['result'])) : null,
      );
}

// ── Fees ──────────────────────────────────────────────────────────────────

class FeeBill {
  FeeBill({
    required this.id,
    required this.title,
    this.description,
    this.dueDate,
    this.isOverdue = false,
    this.original = 0,
    this.payable = 0,
    this.savings = 0,
    this.savingsLabels = const [],
    this.paid = 0,
    this.balance = 0,
    this.progress = 0,
    this.status = '',
  });

  final int id;
  final String title;
  final String? description;
  final String? dueDate;
  final bool isOverdue;
  final double original;
  final double payable;
  final double savings;
  final List<String> savingsLabels;
  final double paid;
  final double balance;
  final double progress;
  final String status;

  factory FeeBill.fromJson(Map<String, dynamic> j) => FeeBill(
        id: asInt(j['id']) ?? 0,
        title: asString(j['title']) ?? 'Bill',
        description: asString(j['description']),
        dueDate: asString(j['due_date']),
        isOverdue: asBool(j['is_overdue']),
        original: asDouble(j['original_amount']) ?? 0,
        payable: asDouble(j['amount_payable']) ?? 0,
        savings: asDouble(j['savings']) ?? 0,
        savingsLabels: asStringList(j['savings_labels']),
        paid: asDouble(j['amount_paid']) ?? 0,
        balance: asDouble(j['balance']) ?? 0,
        progress: asDouble(j['progress']) ?? 0,
        status: asString(j['status']) ?? '',
      );
}

class FeePayment {
  FeePayment({this.paidAt, this.bill, this.amount = 0, this.method, this.reference, this.status});

  final DateTime? paidAt;
  final String? bill;
  final double amount;
  final String? method;
  final String? reference;
  final String? status;

  factory FeePayment.fromJson(Map<String, dynamic> j) => FeePayment(
        paidAt: asDate(j['paid_at']),
        bill: asString(j['bill']),
        amount: asDouble(j['amount']) ?? 0,
        method: asString(j['method']),
        reference: asString(j['reference']),
        status: asString(j['status']),
      );
}

class FeeStatement {
  FeeStatement({
    required this.sessionId,
    required this.termId,
    this.sessions = const [],
    this.terms = const [],
    this.className,
    this.message,
    this.totals = const {},
    this.arrears = 0,
    this.bills = const [],
    this.payments = const [],
  });

  final int sessionId;
  final int termId;
  final List<IdName> sessions;
  final List<IdName> terms;
  final String? className;
  final String? message;
  final Map<String, double> totals;
  final double arrears;
  final List<FeeBill> bills;
  final List<FeePayment> payments;

  double get payable => totals['adjusted'] ?? 0;
  double get paid => totals['paid'] ?? 0;
  double get outstanding => totals['outstanding'] ?? 0;
  double get savings => totals['savings'] ?? 0;

  factory FeeStatement.fromJson(Map<String, dynamic> j) => FeeStatement(
        sessionId: asInt(j['session_id']) ?? 0,
        termId: asInt(j['term_id']) ?? 0,
        sessions: IdName.sessions(j['sessions']),
        terms: IdName.terms(j['terms']),
        className: asString(asMap(j['class'])['name']),
        message: asString(j['message']),
        totals: asMap(j['totals']).map((k, v) => MapEntry(k, asDouble(v) ?? 0)),
        arrears: asDouble(asMap(j['arrears'])['total_arrears']) ?? 0,
        bills: asMapList(j['bills']).map(FeeBill.fromJson).toList(),
        payments: asMapList(j['payments']).map(FeePayment.fromJson).toList(),
      );
}

/// A bill line that can be paid online (GET students/{id}/payment-quote).
class QuoteLine {
  QuoteLine({required this.key, required this.title, this.isArrear = false, this.term, this.session, this.payable = 0, this.paid = 0, this.balance = 0});

  final String key;
  final String title;
  final bool isArrear;
  final String? term;
  final String? session;
  final double payable;
  final double paid;
  final double balance;

  factory QuoteLine.fromJson(Map<String, dynamic> j) => QuoteLine(
        key: asString(j['key']) ?? '',
        title: asString(j['title']) ?? 'Bill',
        isArrear: asBool(j['is_arrear']),
        term: asString(j['term']),
        session: asString(j['session']),
        payable: asDouble(j['payable']) ?? 0,
        paid: asDouble(j['paid']) ?? 0,
        balance: asDouble(j['balance']) ?? 0,
      );
}

class PaymentQuote {
  PaymentQuote({required this.studentId, required this.sessionId, required this.termId, this.message, this.lines = const [], this.gatewayReady = false, this.gateways = const [], this.minTotal = 100, this.recent = const []});

  final int studentId;
  final int sessionId;
  final int termId;
  final String? message;
  final List<QuoteLine> lines;
  final bool gatewayReady;
  final List<String> gateways;
  final double minTotal;
  final List<OnlinePayment> recent;

  List<QuoteLine> get payable => lines.where((l) => l.balance > 0).toList();

  factory PaymentQuote.fromJson(Map<String, dynamic> j) => PaymentQuote(
        studentId: asInt(j['student_id']) ?? 0,
        sessionId: asInt(j['session_id']) ?? 0,
        termId: asInt(j['term_id']) ?? 0,
        message: asString(j['message']),
        lines: [
          ...asMapList(j['arrears']).map(QuoteLine.fromJson),
          ...asMapList(j['current']).map(QuoteLine.fromJson),
        ],
        gatewayReady: asBool(j['gateway_ready']),
        gateways: asStringList(j['gateways']),
        minTotal: asDouble(j['min_total']) ?? 100,
        recent: asMapList(j['recent']).map(OnlinePayment.fromJson).toList(),
      );
}

class OnlinePayment {
  OnlinePayment({required this.reference, required this.status, required this.statusLabel, this.amount = 0, this.term, this.session, this.createdAt, this.posted = false, this.items = const []});

  final String reference;
  final String status;
  final String statusLabel;
  final double amount;
  final String? term;
  final String? session;
  final DateTime? createdAt;
  final bool posted;
  final List<Map<String, dynamic>> items;

  bool get isFinal => status != 'pending';

  factory OnlinePayment.fromJson(Map<String, dynamic> j) => OnlinePayment(
        reference: asString(j['reference']) ?? '',
        status: asString(j['status']) ?? 'pending',
        statusLabel: asString(j['status_label']) ?? '',
        amount: asDouble(j['amount']) ?? 0,
        term: asString(j['term']),
        session: asString(j['session']),
        createdAt: asDate(j['created_at']),
        posted: asBool(j['posted']),
        items: asMapList(j['items']),
      );
}

// ── Attendance ────────────────────────────────────────────────────────────

class AttendanceDay {
  AttendanceDay(this.date, this.periods);
  final DateTime? date;
  final List<Map<String, dynamic>> periods;

  String get status => periods.isEmpty ? '' : (asString(periods.first['status']) ?? '');
}

class AttendancePage {
  AttendancePage({required this.sessionId, required this.termId, this.sessions = const [], this.terms = const [], this.summary = const {}, this.days = const []});

  final int sessionId;
  final int termId;
  final List<IdName> sessions;
  final List<IdName> terms;
  final Map<String, dynamic> summary;
  final List<AttendanceDay> days;

  factory AttendancePage.fromJson(Map<String, dynamic> j) => AttendancePage(
        sessionId: asInt(j['session_id']) ?? 0,
        termId: asInt(j['term_id']) ?? 0,
        sessions: IdName.sessions(j['sessions']),
        terms: IdName.terms(j['terms']),
        summary: asMap(j['summary']),
        days: asMapList(j['days']).map((d) => AttendanceDay(asDate(d['date']), asMapList(d['periods']))).toList(),
      );
}

// ── Timetable ─────────────────────────────────────────────────────────────

class ClassTimetable {
  ClassTimetable({this.published = false, this.days = const [], this.periods = const [], this.slots = const []});

  final bool published;
  final List<String> days;
  final List<Map<String, dynamic>> periods;
  final List<Map<String, dynamic>> slots;

  Map<String, dynamic>? slot(String day, int periodId) {
    for (final s in slots) {
      if (s['day'] == day && asInt(s['period_id']) == periodId) return s;
    }
    return null;
  }

  factory ClassTimetable.fromJson(Map<String, dynamic> j) => ClassTimetable(
        published: asBool(j['published']),
        days: asStringList(j['days']),
        periods: asMapList(j['periods']),
        slots: asMapList(j['slots']),
      );
}

// ── Student leave ─────────────────────────────────────────────────────────

class StudentLeave {
  StudentLeave({required this.id, required this.studentId, this.studentName, this.reasonLabel, this.reason, this.startDate, this.endDate, this.days = 0, this.status = '', this.statusLabel = '', this.isOpen = false, this.note, this.className, this.stage});

  final int id;
  final int studentId;
  final String? studentName;
  final String? reasonLabel;
  final String? reason;
  final String? startDate;
  final String? endDate;
  final int days;
  final String status;
  final String statusLabel;
  final bool isOpen;
  final String? note;
  final String? className;
  final String? stage;

  factory StudentLeave.fromJson(Map<String, dynamic> j) => StudentLeave(
        id: asInt(j['id']) ?? 0,
        studentId: asInt(j['student_id']) ?? 0,
        studentName: asString(j['student_name']),
        reasonLabel: asString(j['reason_label']),
        reason: asString(j['reason']),
        startDate: asString(j['start_date']),
        endDate: asString(j['end_date']),
        days: asInt(j['days']) ?? 0,
        status: asString(j['status']) ?? '',
        statusLabel: asString(j['status_label']) ?? '',
        isOpen: asBool(j['is_open']),
        note: asString(j['approver_note']) ?? asString(j['teacher_note']),
        className: asString(j['class_name']),
        stage: asString(j['stage']),
      );
}
