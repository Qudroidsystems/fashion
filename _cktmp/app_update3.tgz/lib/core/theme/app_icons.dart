import 'package:flutter/widgets.dart';
import 'package:iconsax/iconsax.dart';

/// Every icon the app uses, in one place.
class AppIcons {
  AppIcons._();

  static const IconData home = Iconsax.home;
  static const IconData trophy = Iconsax.medal_star;
  static const IconData star = Iconsax.award;
  static const IconData homeActive = Iconsax.home5;
  static const IconData user = Iconsax.user;
  static const IconData userActive = Iconsax.user5;
  static const IconData people = Iconsax.profile_2user;
  static const IconData inbox = Iconsax.notification;
  static const IconData bell = Iconsax.notification_bing;
  static const IconData calendar = Iconsax.calendar_1;
  static const IconData calendarDay = Iconsax.calendar;
  static const IconData scores = Iconsax.edit;
  static const IconData register = Iconsax.task_square;
  static const IconData overview = Iconsax.chart_2;
  static const IconData approvals = Iconsax.tick_square;
  static const IconData search = Iconsax.search_normal;

  static const IconData results = Iconsax.award;
  static const IconData fees = Iconsax.wallet;
  static const IconData pay = Iconsax.card;
  static const IconData attendance = Iconsax.tick_circle;
  static const IconData timetable = Iconsax.clock;
  static const IconData leave = Iconsax.briefcase;
  static const IconData payslip = Iconsax.document_text;
  static const IconData document = Iconsax.document_text;
  static const IconData download = Iconsax.document_download;
  static const IconData school = Iconsax.building;
  static const IconData lock = Iconsax.lock;
  static const IconData logout = Iconsax.logout;
  static const IconData swap = Iconsax.refresh;
  static const IconData refresh = Iconsax.refresh;
  static const IconData arrow = Iconsax.arrow_right_3;
  static const IconData add = Iconsax.add;
  static const IconData close = Iconsax.close_circle;
  static const IconData check = Iconsax.tick_circle;
  static const IconData warning = Iconsax.warning_2;
  static const IconData info = Iconsax.info_circle;
  static const IconData call = Iconsax.call;
  static const IconData sms = Iconsax.sms;
  static const IconData security = Iconsax.security_user;
  static const IconData save = Iconsax.save_2;
  static const IconData teacher = Iconsax.teacher;
  static const IconData chart = Iconsax.chart_21;
  static const IconData trendUp = Iconsax.trend_up;
  static const IconData trendDown = Iconsax.trend_down;
  static const IconData book = Iconsax.book_1;
  static const IconData receipt = Iconsax.receipt_2;
  static const IconData upload = Iconsax.document_upload;
  static const IconData excel = Iconsax.document_text_1;
  static const IconData printer = Iconsax.printer;
  static const IconData history = Iconsax.archive_book;
  static const IconData profile = Iconsax.personalcard;
  static const IconData message = Iconsax.message;
  static const IconData task = Iconsax.task;
  static const IconData medal = Iconsax.medal_star;
  static const IconData settings = Iconsax.setting_2;
  static const IconData health = Iconsax.health;
  static const IconData more = Iconsax.more;
}
