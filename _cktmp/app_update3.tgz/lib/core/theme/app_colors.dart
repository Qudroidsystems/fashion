import 'package:flutter/material.dart';

/// Colours shared with the web portal (navy + blue).
class AppColors {
  AppColors._();

  static const Color navy = Color(0xFF1E3A5F);
  static const Color navyDark = Color(0xFF142943);
  static const Color blue = Color(0xFF2563EB);
  static const Color sky = Color(0xFFE8F0FE);

  static const Color background = Color(0xFFF5F7FB);
  static const Color surface = Colors.white;
  static const Color border = Color(0xFFE3E8F0);
  static const Color text = Color(0xFF0F172A);
  static const Color textMuted = Color(0xFF64748B);

  static const Color success = Color(0xFF16A34A);
  static const Color warning = Color(0xFFD97706);
  static const Color danger = Color(0xFFDC2626);
  static const Color info = Color(0xFF0891B2);
  static const Color purple = Color(0xFF7C3AED);
  static const Color teal = Color(0xFF0D9488);

  /// Colour for a grade letter (A best … F fail).
  static Color grade(String? g) {
    final s = (g ?? '').toUpperCase();
    if (s.startsWith('A')) return success;
    if (s.startsWith('B')) return blue;
    if (s.startsWith('C')) return info;
    if (s.startsWith('D') || s.startsWith('E')) return warning;
    if (s.startsWith('F')) return danger;
    return textMuted;
  }

  /// Colour for an attendance status.
  static Color attendance(String? status) {
    switch (status) {
      case 'present':
        return success;
      case 'late':
        return warning;
      case 'absent':
        return danger;
      case 'excused':
      case 'sick_leave':
        return info;
      default:
        return textMuted;
    }
  }

  /// Colour for a request / payment status word.
  static Color status(String? status) {
    final s = (status ?? '').toLowerCase();
    if (s.contains('approved') || s == 'paid' || s == 'success' || s == 'complete' || s == 'covered') return success;
    if (s.contains('pending') || s.contains('waiting') || s == 'partial' || s == 'in_progress') return warning;
    if (s.contains('reject') || s.contains('declin') || s == 'failed' || s == 'unpaid' || s.contains('overdue')) return danger;
    return textMuted;
  }
}
