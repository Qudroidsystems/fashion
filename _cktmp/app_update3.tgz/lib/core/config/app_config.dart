import '../storage/session_store.dart';

/// App-wide settings.
///
/// Vite Schools is one app for many schools: on first launch the user enters
/// their school's portal address (e.g. portal.myschool.com) and the app talks
/// to `<that address>/api/v1` from then on.
///
/// A build for a single school can skip that step:
///   flutter build apk --dart-define=SCHOOL_URL=https://portal.csskabba.ng
class AppConfig {
  AppConfig._();

  static const String appName = 'Vite Schools';

  /// The kind of portal this app works with (GET /school → score_model):
  /// 'dynamic' = assessments set per class category (CSS Kabba-type portals),
  /// 'fixed' = CA1, CA2, CA3 and Exam (TopClass-type portals, TopClass Schools app).
  static const String scoreModel = 'dynamic';

  /// The sister app for the other kind of portal.
  static const String otherAppName = 'TopClass Schools';

  static String wrongPortalMessage(String? school) =>
      '${school ?? 'This school'} uses the $otherAppName app. Please install $otherAppName to sign in to this school.';

  /// Fixed school for a white-label build (empty = ask the user).
  static const String lockedSchoolUrl = String.fromEnvironment('SCHOOL_URL');

  static bool get schoolLocked => lockedSchoolUrl.isNotEmpty;

  /// The school's portal address, e.g. https://portal.csskabba.ng (no trailing slash).
  static String? get schoolUrl => schoolLocked ? normalize(lockedSchoolUrl) : SessionStore.schoolUrl;

  static bool get hasSchool => (schoolUrl ?? '').isNotEmpty;

  /// Base URL of the mobile API (routes/api_v1.php on the school's portal).
  static String get apiBaseUrl => '${schoolUrl ?? ''}/api/v1';

  /// The gateway sends the payer back to this path when a payment ends.
  static const String paymentCallbackPath = '/api/v1/payments/callback';

  static const Duration requestTimeout = Duration(seconds: 45);

  /// "portal.school.com/", "https://portal.school.com/api/v1" → "https://portal.school.com".
  static String normalize(String input) {
    var s = input.trim().replaceAll(' ', '');
    if (s.isEmpty) return s;
    if (!s.startsWith('http://') && !s.startsWith('https://')) s = 'https://$s';
    s = s.replaceAll(RegExp(r'/+$'), '');
    s = s.replaceAll(RegExp(r'/api(/v1)?(/school)?$'), '');
    s = s.replaceAll(RegExp(r'/(login|home|dashboard)$'), '');
    return s.replaceAll(RegExp(r'/+$'), '');
  }
}
