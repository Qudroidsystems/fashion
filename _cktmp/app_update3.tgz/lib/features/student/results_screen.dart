import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/pdf_opener.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import 'period_picker.dart';

/// Term results: overall figures (total, averages, positions, GPA), every
/// subject's scores, comments and the printable report card. What appears
/// is chosen by the school (Admin → Result display on the portal).
/// Results held back for unpaid fees show the school's message instead.
class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends LoadState<ResultsScreen, ResultsPage> {
  int? _termId;
  int? _sessionId;
  bool _table = false;

  @override
  Future<ResultsPage> fetch() => StudentRepository.results(widget.student.id, termId: _termId, sessionId: _sessionId);

  void _pick(ResultTerm t) {
    _termId = t.termId;
    _sessionId = t.sessionId;
    reload();
  }

  @override
  Widget build(BuildContext context) {
    final page = data;
    final r = page?.result;
    return Scaffold(
      appBar: AppBar(
        title: Text('Results — ${widget.student.firstName}'),
        actions: [
          if (r != null && r.subjects.isNotEmpty)
            IconButton(
              tooltip: _table ? 'Show as cards' : 'Show as table',
              onPressed: () => setState(() => _table = !_table),
              icon: Icon(_table ? Icons.view_agenda_outlined : Icons.grid_on_outlined),
            ),
        ],
      ),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: page != null && page.terms.isEmpty,
        emptyIcon: AppIcons.results,
        emptyTitle: 'No results yet',
        emptyMessage: 'Results will show here once the school publishes them.',
        child: page == null
            ? const SizedBox()
            : RefreshIndicator(
                onRefresh: () async => reload(),
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    ChoiceRow<ResultTerm>(
                      items: page.terms,
                      selected: page.selected,
                      label: (t) => t.label,
                      same: (a, b) => a.sameAs(b),
                      onSelected: _pick,
                    ),
                    const SizedBox(height: 12),
                    if (page.selected != null && !page.selected!.allowed) _Hold(term: page.selected!),
                    if (page.selected != null && page.selected!.allowed && r != null) ...[
                      _Overview(term: page.selected!, result: r),
                      SectionTitle('Subjects (${r.subjects.length})'),
                      if (_table)
                        _ResultTable(result: r)
                      else
                        for (final s in r.subjects) ...[
                          _SubjectCard(s, r.display),
                          const SizedBox(height: 10),
                        ],
                      if (r.display.sum('comments') && (r.classTeacherComment != null || r.principalComment != null)) ...[
                        const SectionTitle('Comments'),
                        _Comments(result: r),
                      ],
                      const SizedBox(height: 18),
                      if (r.display.sum('report_card') && r.reportCardUrl != null)
                        ElevatedButton.icon(
                          onPressed: () => PdfOpener.open(
                            r.reportCardUrl!,
                            'Report_Card_${widget.student.fullName}_${page.selected?.term ?? ''}.pdf',
                          ),
                          icon: const Icon(AppIcons.download),
                          label: const Text('Report card (PDF)'),
                        ),
                      const SizedBox(height: 24),
                    ],
                  ],
                ),
              ),
      ),
    );
  }
}

/// The headline figures as tiles, two per row.
class _Overview extends StatelessWidget {
  const _Overview({required this.term, required this.result});

  final ResultTerm term;
  final TermResult result;

  @override
  Widget build(BuildContext context) {
    final d = result.display;
    final m = result.summary;
    String of(String? pos, int? size) => pos == null ? '—' : (d.sum('class_size') && size != null ? '$pos of $size' : pos);

    final tiles = <(String, String, IconData, Color)>[
      if (d.sum('class_position') && m.classPosition != null)
        ('Position in class', of(m.classPosition, m.classSize), AppIcons.trophy, AppColors.warning),
      if (d.sum('arm_position') && m.armPosition != null)
        ('Position in arm', of(m.armPosition, m.armSize), AppIcons.trophy, AppColors.purple),
      if (d.sum('average') && (m.termAverage ?? result.average) != null)
        ('Term average', '${Fmt.number(m.termAverage ?? result.average)}%', AppIcons.chart, AppColors.blue),
      if (d.sum('cum_overall') && m.cumAverage != null && m.cumAverage != (m.termAverage ?? result.average))
        ('Cumulative average', '${Fmt.number(m.cumAverage)}%', AppIcons.chart, AppColors.teal),
      if (d.sum('total_score') && (m.termTotal ?? result.totalScore) != null)
        ('Total obtained', Fmt.number(m.termTotal ?? result.totalScore), AppIcons.results, AppColors.success),
      if (d.sum('gpa') && m.gpa != null) ('GPA', m.gpa!.toStringAsFixed(2), AppIcons.star, AppColors.navy),
      ('Subjects', '${result.subjects.length}', AppIcons.book, AppColors.navy),
      if (d.sum('attendance') && result.timesAbsent != null)
        ('Times absent', '${result.timesAbsent}', AppIcons.calendar, AppColors.danger),
    ];

    return LayoutBuilder(builder: (context, c) {
      final w = (c.maxWidth - 10) / 2;
      return Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [
          for (final (label, value, icon, color) in tiles)
            SizedBox(width: w, child: StatTile(label: label, value: value, icon: icon, color: color)),
        ],
      );
    });
  }
}

class _Hold extends StatelessWidget {
  const _Hold({required this.term});
  final ResultTerm term;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: AppCard(
        color: AppColors.warning.withValues(alpha: 0.06),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(AppIcons.lock, color: AppColors.warning),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(term.notReleased ? 'Not released yet' : 'Result on hold', style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(term.holdMessage ?? 'This result is not available yet.'),
                  if (term.amountOwed > 0) ...[
                    const SizedBox(height: 6),
                    Text('Amount owed: ${Fmt.naira(term.amountOwed)}', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.danger)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// The figures one subject has, in the order a report card lists them.
List<(String, String, bool)> subjectFigures(SubjectScore s, ResultDisplay d) {
  String n(double? v) => Fmt.number(v);
  return [
    if (d.sub('total') && s.total != null) ('Total', n(s.total), true),
    if (d.sub('bf') && s.bf != null) ('B/F', n(s.bf), false),
    if (d.sub('cum') && s.cum != null) ('Cum', n(s.cum), false),
    if (d.sub('cum_average') && s.cumAverage != null) ('Cum. avg', n(s.cumAverage), false),
    if (d.sub('position') && s.position != null) ('Position', s.position!, true),
    if (d.sub('position_total') && s.positionTotal != null) ('Pos. (term)', s.positionTotal!, false),
    if (d.sub('arm_position') && s.armPosition != null) ('Arm pos.', s.armPosition!, false),
    if (d.sub('arm_position_cum') && s.armPositionCum != null) ('Arm pos. (cum)', s.armPositionCum!, false),
    if (d.sub('class_average') && s.classAverage != null) ('Class avg', n(s.classAverage), false),
    if (d.sub('highest_lowest') && s.highest != null) ('Highest', n(s.highest), false),
    if (d.sub('highest_lowest') && s.lowest != null) ('Lowest', n(s.lowest), false),
  ];
}

class _SubjectCard extends StatelessWidget {
  const _SubjectCard(this.s, this.d);
  final SubjectScore s;
  final ResultDisplay d;

  @override
  Widget build(BuildContext context) {
    final gc = AppColors.grade(s.grade);
    final figs = subjectFigures(s, d);
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(s.subject, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
              if (d.sub('grade'))
                Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: gc.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
                  child: Text(s.grade ?? '—', style: TextStyle(color: gc, fontWeight: FontWeight.w900, fontSize: 16)),
                ),
            ],
          ),
          if (d.sub('assessments') && s.parts.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final p in s.parts)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(8)),
                    child: Text('${p.name}: ${Fmt.number(p.score)}${p.max != null ? '/${Fmt.number(p.max)}' : ''}',
                        style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                  ),
              ],
            ),
          ],
          if (figs.isNotEmpty) ...[
            const SizedBox(height: 10),
            LayoutBuilder(builder: (context, c) {
              final w = (c.maxWidth - 16) / 3;
              return Wrap(
                spacing: 8,
                runSpacing: 10,
                children: [for (final (label, value, bold) in figs) SizedBox(width: w, child: _Fig(label, value, bold: bold))],
              );
            }),
          ],
          if (d.sub('remark') && s.remark != null) ...[
            const SizedBox(height: 8),
            Text(s.remark!, style: TextStyle(color: gc, fontWeight: FontWeight.w600, fontSize: 12.5)),
          ],
        ],
      ),
    );
  }
}

/// Every subject in one scrollable table, like the report card.
class _ResultTable extends StatelessWidget {
  const _ResultTable({required this.result});
  final TermResult result;

  @override
  Widget build(BuildContext context) {
    final d = result.display;
    final parts = <String>[
      if (d.sub('assessments'))
        for (final s in result.subjects)
          for (final p in s.parts) p.name,
    ].toSet().toList();
    // Column set = union of the figures any subject has.
    final labels = <String>[];
    for (final s in result.subjects) {
      for (final f in subjectFigures(s, d)) {
        if (!labels.contains(f.$1)) labels.add(f.$1);
      }
    }
    const head = TextStyle(fontWeight: FontWeight.w800, fontSize: 12);

    return AppCard(
      padding: EdgeInsets.zero,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowHeight: 38,
          dataRowMinHeight: 36,
          dataRowMaxHeight: 42,
          columnSpacing: 14,
          horizontalMargin: 10,
          headingRowColor: const WidgetStatePropertyAll(AppColors.sky),
          columns: [
            const DataColumn(label: Text('Subject', style: head)),
            for (final p in parts) DataColumn(label: Text(p, style: head), numeric: true),
            for (final l in labels) DataColumn(label: Text(l, style: head), numeric: true),
            if (d.sub('grade')) const DataColumn(label: Text('Grade', style: head)),
            if (d.sub('remark')) const DataColumn(label: Text('Remark', style: head)),
          ],
          rows: [
            for (final s in result.subjects)
              DataRow(cells: [
                DataCell(ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 150),
                  child: Text(s.subject, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                )),
                for (final p in parts)
                  DataCell(Text(Fmt.number(s.parts.where((x) => x.name == p).firstOrNull?.score))),
                for (final l in labels)
                  DataCell(Builder(builder: (_) {
                    final f = subjectFigures(s, d).where((x) => x.$1 == l).firstOrNull;
                    return Text(f?.$2 ?? '', style: TextStyle(fontWeight: (f?.$3 ?? false) ? FontWeight.w800 : FontWeight.w500));
                  })),
                if (d.sub('grade'))
                  DataCell(Text(s.grade ?? '—', style: TextStyle(color: AppColors.grade(s.grade), fontWeight: FontWeight.w900))),
                if (d.sub('remark')) DataCell(Text(s.remark ?? '', style: const TextStyle(fontSize: 12))),
              ]),
          ],
        ),
      ),
    );
  }
}

class _Comments extends StatelessWidget {
  const _Comments({required this.result});
  final TermResult result;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (result.classTeacherComment != null) ...[
            const Text('Class teacher', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
            const SizedBox(height: 2),
            Text(result.classTeacherComment!),
            const SizedBox(height: 12),
          ],
          if (result.principalComment != null) ...[
            const Text('Principal', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
            const SizedBox(height: 2),
            Text(result.principalComment!),
          ],
        ],
      ),
    );
  }
}

class _Fig extends StatelessWidget {
  const _Fig(this.label, this.value, {this.bold = false});
  final String label;
  final String value;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
        Text(value, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w700, fontSize: bold ? 16 : 14)),
      ],
    );
  }
}
