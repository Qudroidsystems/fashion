import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/pdf_opener.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/student.dart';
import '../../data/repositories/school_repository.dart';
import 'period_picker.dart';

/// Term results: subject scores, comments and the printable report card.
/// Results held back for unpaid fees show the school's message instead.
class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key, required this.student});

  final StudentCard student;

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends LoadState<ResultsScreen, ResultsPage> {
  int? _termId;
  int? _sessionId;

  @override
  Future<ResultsPage> fetch() => StudentRepository.results(widget.student.id, termId: _termId, sessionId: _sessionId);

  void _pick(ResultTerm t) {
    _termId = t.termId;
    _sessionId = t.sessionId;
    reload();
  }

  @override
  Widget build(BuildContext context) {
    final page = data;
    return Scaffold(
      appBar: AppBar(title: Text('Results — ${widget.student.firstName}')),
      body: AsyncBody(
        loading: loading,
        error: error,
        onRetry: load,
        isEmpty: page != null && page.terms.isEmpty,
        emptyIcon: AppIcons.results,
        emptyTitle: 'No results yet',
        emptyMessage: 'Results will show here once the school publishes them.',
        child: page == null
            ? const SizedBox()
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  ChoiceRow<ResultTerm>(
                    items: page.terms,
                    selected: page.selected,
                    label: (t) => t.label,
                    same: (a, b) => a.sameAs(b),
                    onSelected: _pick,
                  ),
                  const SizedBox(height: 12),
                  if (page.selected != null) _TermSummary(term: page.selected!, result: page.result),
                  if (page.selected != null && !page.selected!.allowed) _Hold(term: page.selected!),
                  if (page.result != null) ...[
                    const SectionTitle('Subjects'),
                    for (final s in page.result!.subjects) ...[
                      _SubjectCard(s),
                      const SizedBox(height: 10),
                    ],
                    if (page.result!.classTeacherComment != null || page.result!.principalComment != null) ...[
                      const SectionTitle('Comments'),
                      AppCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (page.result!.classTeacherComment != null) ...[
                              const Text('Class teacher', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                              const SizedBox(height: 2),
                              Text(page.result!.classTeacherComment!),
                              const SizedBox(height: 12),
                            ],
                            if (page.result!.principalComment != null) ...[
                              const Text('Principal', style: TextStyle(color: AppColors.textMuted, fontSize: 12.5)),
                              const SizedBox(height: 2),
                              Text(page.result!.principalComment!),
                            ],
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 18),
                    if (page.result!.reportCardUrl != null)
                      ElevatedButton.icon(
                        onPressed: () => PdfOpener.open(
                          page.result!.reportCardUrl!,
                          'Report_Card_${widget.student.fullName}_${page.selected?.term ?? ''}.pdf',
                        ),
                        icon: const Icon(AppIcons.download),
                        label: const Text('Report card (PDF)'),
                      ),
                    const SizedBox(height: 24),
                  ],
                ],
              ),
      ),
    );
  }
}

class _TermSummary extends StatelessWidget {
  const _TermSummary({required this.term, required this.result});

  final ResultTerm term;
  final TermResult? result;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: StatTile(label: 'Average', value: Fmt.number(result?.average ?? term.average), color: AppColors.blue)),
        const SizedBox(width: 10),
        Expanded(child: StatTile(label: 'Subjects', value: '${term.subjects}', color: AppColors.navy)),
        const SizedBox(width: 10),
        Expanded(child: StatTile(label: 'Total score', value: Fmt.number(result?.totalScore), color: AppColors.success)),
      ],
    );
  }
}

class _Hold extends StatelessWidget {
  const _Hold({required this.term});
  final ResultTerm term;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: AppCard(
        color: AppColors.warning.withValues(alpha: 0.06),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(AppIcons.lock, color: AppColors.warning),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(term.notReleased ? 'Not released yet' : 'Result on hold', style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(term.holdMessage ?? 'This result is not available yet.'),
                  if (term.amountOwed > 0) ...[
                    const SizedBox(height: 6),
                    Text('Amount owed: ${Fmt.naira(term.amountOwed)}', style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.danger)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SubjectCard extends StatelessWidget {
  const _SubjectCard(this.s);
  final SubjectScore s;

  @override
  Widget build(BuildContext context) {
    final gc = AppColors.grade(s.grade);
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(s.subject, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: gc.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
                child: Text(s.grade ?? '—', style: TextStyle(color: gc, fontWeight: FontWeight.w900, fontSize: 16)),
              ),
            ],
          ),
          if (s.parts.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final p in s.parts)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(8)),
                    child: Text('${p.name}: ${Fmt.number(p.score)}${p.max != null ? '/${Fmt.number(p.max)}' : ''}',
                        style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                  ),
              ],
            ),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              _Fig('Total', Fmt.number(s.total), bold: true),
              _Fig('Position', Fmt.ordinal(s.position)),
              _Fig('Class avg', Fmt.number(s.classAverage)),
              if (s.cumAverage != null && s.cumAverage != s.total) _Fig('Cum. avg', Fmt.number(s.cumAverage)),
            ],
          ),
          if (s.remark != null) ...[
            const SizedBox(height: 6),
            Text(s.remark!, style: TextStyle(color: gc, fontWeight: FontWeight.w600, fontSize: 12.5)),
          ],
        ],
      ),
    );
  }
}

class _Fig extends StatelessWidget {
  const _Fig(this.label, this.value, {this.bold = false});
  final String label;
  final String value;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
          Text(value, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w700, fontSize: bold ? 16 : 14)),
        ],
      ),
    );
  }
}
