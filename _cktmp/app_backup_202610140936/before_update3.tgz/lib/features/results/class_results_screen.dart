import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_icons.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/json.dart';
import '../../core/utils/pdf_opener.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/load_state.dart';
import '../../data/models/results_admin.dart';
import '../../data/repositories/school_repository.dart';
import '../student/period_picker.dart';

/// One class's results: the broadsheet, and the report-card approval.
class ClassResultsScreen extends StatelessWidget {
  const ClassResultsScreen({super.key, required this.classId, required this.className, required this.termId, required this.sessionId, this.term, this.approvals = true});

  final int classId;
  final String className;
  final int termId;
  final int sessionId;
  final String? term;

  /// Show the report-card approval tab (not every portal uses approval).
  final bool approvals;

  @override
  Widget build(BuildContext context) {
    if (!approvals) {
      return Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(className, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              if (term != null) Text(term!, style: TextStyle(fontSize: 12.5, color: Colors.white.withValues(alpha: 0.8))),
            ],
          ),
        ),
        body: BroadsheetView(classId: classId, termId: termId, sessionId: sessionId),
      );
    }
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(className, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              if (term != null) Text(term!, style: TextStyle(fontSize: 12.5, color: Colors.white.withValues(alpha: 0.8))),
            ],
          ),
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [Tab(text: 'Broadsheet'), Tab(text: 'Report cards')],
          ),
        ),
        body: TabBarView(
          children: [
            BroadsheetView(classId: classId, termId: termId, sessionId: sessionId),
            ApprovalView(classId: classId, termId: termId, sessionId: sessionId),
          ],
        ),
      ),
    );
  }
}

// ── Broadsheet ────────────────────────────────────────────────────────────

class BroadsheetView extends StatefulWidget {
  const BroadsheetView({super.key, required this.classId, required this.termId, required this.sessionId});

  final int classId;
  final int termId;
  final int sessionId;

  @override
  State<BroadsheetView> createState() => _BroadsheetViewState();
}

class _BroadsheetViewState extends LoadState<BroadsheetView, Broadsheet> with AutomaticKeepAliveClientMixin {
  String _basis = 'cum_ave';
  bool _table = false;

  @override
  bool get wantKeepAlive => true;

  @override
  Future<Broadsheet> fetch() =>
      ResultsRepository.broadsheet(widget.classId, termId: widget.termId, sessionId: widget.sessionId, basis: _basis);

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final b = data;
    return AsyncBody(
      loading: loading,
      error: error,
      onRetry: load,
      isEmpty: b != null && b.rows.isEmpty,
      emptyIcon: AppIcons.results,
      emptyTitle: 'No scores yet',
      emptyMessage: 'The broadsheet fills in as subject teachers enter scores.',
      child: b == null
          ? const SizedBox()
          : Column(
              children: [
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: ChoiceRow<String>(
                          items: const ['cum_ave', 'total'],
                          selected: _basis,
                          label: (x) => x == 'total' ? 'This term' : 'Cumulative',
                          onSelected: (x) {
                            _basis = x;
                            reload();
                          },
                        ),
                      ),
                      IconButton(
                        tooltip: _table ? 'Cards' : 'Table',
                        onPressed: () => setState(() => _table = !_table),
                        icon: Icon(_table ? Icons.view_agenda_outlined : Icons.grid_on_outlined, color: AppColors.navy),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                  child: Row(
                    children: [
                      Text('${b.rows.length} students · ${b.subjects.length} subjects',
                          style: const TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w600)),
                      const Spacer(),
                      Text('Class average ${Fmt.number(b.classAverage)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
                Expanded(child: _table ? _tableView(b) : _cards(b)),
              ],
            ),
    );
  }

  Widget _cards(Broadsheet b) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: b.rows.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final r = b.rows[i];
        final avg = b.byTotal ? r.termAverage : r.cumAverage;
        return AppCard(
          padding: EdgeInsets.zero,
          child: Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
              leading: _PositionBadge(r.position),
              title: Text(r.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('Average ${Fmt.number(avg)} · GPA ${Fmt.number(r.gpa)} · ${r.numSubjects} subjects',
                  style: const TextStyle(fontSize: 12.5, color: AppColors.textMuted)),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              children: [
                for (final s in b.subjects)
                  if (r.scores[s.id] != null) _subjectLine(s, r.scores[s.id]!, b.byTotal),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _subjectLine(BroadsheetSubject s, Map<String, dynamic> score, bool byTotal) {
    final grade = asString(score['grade']);
    final value = asDouble(byTotal ? score['total'] : score['cum_ave']);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(s.name)),
          Text(Fmt.number(value), style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(width: 10),
          SizedBox(
            width: 32,
            child: Text(grade ?? '—', textAlign: TextAlign.right, style: TextStyle(color: AppColors.grade(grade), fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }

  Widget _tableView(Broadsheet b) {
    const head = TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5);
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowHeight: 40,
          dataRowMinHeight: 38,
          dataRowMaxHeight: 44,
          columnSpacing: 14,
          horizontalMargin: 8,
          headingRowColor: const WidgetStatePropertyAll(AppColors.sky),
          border: TableBorder.all(color: AppColors.border, width: 0.6),
          columns: [
            const DataColumn(label: Text('Pos', style: head)),
            const DataColumn(label: Text('Student', style: head)),
            for (final s in b.subjects) DataColumn(label: Tooltip(message: s.name, child: Text(s.short, style: head)), numeric: true),
            const DataColumn(label: Text('Avg', style: head), numeric: true),
            const DataColumn(label: Text('GPA', style: head), numeric: true),
          ],
          rows: [
            for (final r in b.rows)
              DataRow(cells: [
                DataCell(Text(Fmt.ordinal(r.position), style: const TextStyle(fontWeight: FontWeight.w700))),
                DataCell(ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 150),
                  child: Text(r.name, overflow: TextOverflow.ellipsis),
                )),
                for (final s in b.subjects)
                  DataCell(Text(
                    r.scores[s.id] == null ? '' : Fmt.number(asDouble(b.byTotal ? r.scores[s.id]!['total'] : r.scores[s.id]!['cum_ave'])),
                    style: TextStyle(color: AppColors.grade(asString((r.scores[s.id] ?? const <String, dynamic>{})['grade'])), fontWeight: FontWeight.w600),
                  )),
                DataCell(Text(Fmt.number(b.byTotal ? r.termAverage : r.cumAverage), style: const TextStyle(fontWeight: FontWeight.w800))),
                DataCell(Text(Fmt.number(r.gpa))),
              ]),
          ],
        ),
      ),
    );
  }
}

class _PositionBadge extends StatelessWidget {
  const _PositionBadge(this.position);
  final int? position;

  @override
  Widget build(BuildContext context) {
    final top = position != null && position! <= 3;
    return Container(
      width: 38,
      height: 38,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: top ? AppColors.warning.withValues(alpha: 0.15) : AppColors.sky,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(Fmt.ordinal(position), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12.5, color: top ? AppColors.warning : AppColors.navy)),
    );
  }
}

// ── Report-card approval ──────────────────────────────────────────────────

class ApprovalView extends StatefulWidget {
  const ApprovalView({super.key, required this.classId, required this.termId, required this.sessionId});

  final int classId;
  final int termId;
  final int sessionId;

  @override
  State<ApprovalView> createState() => _ApprovalViewState();
}

class _ApprovalViewState extends LoadState<ApprovalView, ReportApproval> with AutomaticKeepAliveClientMixin {
  bool _busy = false;

  @override
  bool get wantKeepAlive => true;

  @override
  Future<ReportApproval> fetch() => ResultsRepository.approval(widget.classId, termId: widget.termId, sessionId: widget.sessionId);

  Future<void> _act(String action, {bool noteRequired = false}) async {
    final a = data;
    if (a == null) return;
    final note = await _askNote(action, noteRequired);
    if (note == null) return;
    setState(() => _busy = true);
    try {
      final (fresh, msg) = await ResultsRepository.act(a.id, action, note: note);
      setState(() => data = fresh);
      Toast.success(msg ?? 'Done.');
    } catch (e) {
      // Not all scores vetted: offer to submit anyway (same as the portal).
      if (action == 'submit' && '$e'.contains('not vetted')) {
        if (await confirmDialog('Submit anyway?', '$e', confirm: 'Submit anyway')) {
          try {
            final (fresh, msg) = await ResultsRepository.act(a.id, action, note: note, force: true);
            setState(() => data = fresh);
            Toast.success(msg ?? 'Submitted.');
          } catch (e2) {
            Toast.error(e2);
          }
        }
      } else {
        Toast.error(e);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// '' = no note; null = cancelled.
  Future<String?> _askNote(String action, bool required) async {
    final titles = {'submit': 'Submit for approval', 'approve': 'Approve & release', 'return': 'Return to class teacher', 'reopen': 'Withdraw approval'};
    final c = TextEditingController();
    final res = await Get.dialog<String>(AlertDialog(
      title: Text(titles[action] ?? 'Confirm'),
      content: TextField(
        controller: c,
        minLines: 2,
        maxLines: 4,
        decoration: InputDecoration(labelText: required ? 'What needs to change?' : 'Note (optional)'),
      ),
      actions: [
        TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
        TextButton(
          onPressed: () {
            if (required && c.text.trim().isEmpty) {
              Toast.error('Please write a note.');
              return;
            }
            Get.back(result: c.text.trim());
          },
          child: Text(titles[action]?.split(' ').first ?? 'OK', style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ],
    ));
    WidgetsBinding.instance.addPostFrameCallback((_) => c.dispose());
    return res;
  }

  Color _statusColor(String s) => switch (s) {
        'approved' => AppColors.success,
        'submitted' => AppColors.warning,
        'returned' => AppColors.danger,
        _ => AppColors.textMuted,
      };

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final a = data;
    final r = a?.readiness ?? const <String, dynamic>{};
    return AsyncBody(
      loading: loading,
      error: error,
      onRetry: load,
      child: a == null
          ? const SizedBox()
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                AppCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(child: Text('Status', style: TextStyle(color: AppColors.textMuted))),
                          StatusPill(a.statusLabel, color: _statusColor(a.status)),
                        ],
                      ),
                      if (a.status == 'returned' && a.reviewNote != null) ...[
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: AppColors.danger.withValues(alpha: 0.07), borderRadius: BorderRadius.circular(10)),
                          child: Text('${a.reviewedBy ?? 'Principal'}: ${a.reviewNote}'),
                        ),
                      ],
                      if (a.status == 'submitted' && a.submittedBy != null) ...[
                        const SizedBox(height: 8),
                        Text('Submitted by ${a.submittedBy}${a.submitNote != null ? ': "${a.submitNote}"' : ''}',
                            style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
                      ],
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: StatTile(label: 'Scores vetted', value: '${asInt(r['vetted_pct']) ?? 0}%', color: AppColors.blue)),
                          const SizedBox(width: 8),
                          Expanded(
                            child: StatTile(
                              label: 'Teacher comments',
                              value: '${asInt(r['teacher_comments']) ?? 0}/${asInt(r['students']) ?? 0}',
                              color: AppColors.navy,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: StatTile(
                              label: 'Principal comments',
                              value: '${asInt(r['principal_comments']) ?? 0}/${asInt(r['students']) ?? 0}',
                              color: AppColors.success,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                if (_busy) const LinearProgressIndicator(),
                if (a.canSubmit && (a.status == 'pending' || a.status == 'returned'))
                  ElevatedButton.icon(
                    onPressed: _busy ? null : () => _act('submit'),
                    icon: const Icon(AppIcons.approvals),
                    label: Text(a.status == 'returned' ? 'Resubmit for approval' : 'Submit for approval'),
                  ),
                if (a.canApprove && a.status != 'approved') ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _busy || a.status == 'pending' ? null : () => _act('return', noteRequired: true),
                          style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                          child: const Text('Return'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _busy ? null : () => _act('approve'),
                          style: ElevatedButton.styleFrom(backgroundColor: AppColors.success),
                          child: const Text('Approve & release'),
                        ),
                      ),
                    ],
                  ),
                ],
                if (a.canApprove && a.status == 'approved')
                  OutlinedButton(
                    onPressed: _busy ? null : () => _act('reopen'),
                    child: const Text('Withdraw approval'),
                  ),
                const SectionTitle('Students'),
                for (final s in a.students) ...[
                  AppCard(
                    padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 2),
                              Text(
                                'Average ${Fmt.number(s.average)} · ${s.vetted}/${s.entries} vetted',
                                style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5),
                              ),
                              const SizedBox(height: 4),
                              Wrap(
                                spacing: 6,
                                children: [
                                  StatusPill(s.teacherComment != null ? 'Teacher comment ✓' : 'No teacher comment',
                                      color: s.teacherComment != null ? AppColors.success : AppColors.warning),
                                  if (s.principalComment != null) const StatusPill('Principal comment ✓', color: AppColors.success),
                                ],
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          tooltip: 'Preview report card',
                          onPressed: () => PdfOpener.open(ResultsRepository.previewUrl(a.id, s.id), 'Report_Card_${s.name}.pdf'),
                          icon: const Icon(AppIcons.document, color: AppColors.navy),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                if (a.history.isNotEmpty) ...[
                  const SectionTitle('History'),
                  AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (final h in a.history)
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 5),
                            child: Text(
                              '${Fmt.dateTime(asDate(h['at']))} — ${asString(h['action']) ?? ''} by ${asString(h['by']) ?? '—'}'
                              '${asString(h['note']) != null ? ': "${h['note']}"' : ''}',
                              style: const TextStyle(fontSize: 13),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 24),
              ],
            ),
    );
  }
}
